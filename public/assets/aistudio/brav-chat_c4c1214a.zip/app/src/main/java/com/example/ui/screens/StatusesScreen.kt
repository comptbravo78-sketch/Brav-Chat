package com.example.ui.screens

import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayCircleFilled
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.BravReactionType
import com.example.model.StatusComment
import com.example.model.StatusPost
import com.example.ui.components.AnimatedReactionIcon
import com.example.ui.components.FloatingEmojiBurstOverlay
import com.example.ui.components.FuturisticEmojiStudioDock
import com.example.ui.components.MessageReactionsRow
import com.example.ui.components.UserAvatarWithStatus
import com.example.ui.components.formatShortDateTime
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravPurpleBright
import com.example.ui.theme.BravRed
import com.example.viewmodel.BravViewModel
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusesScreen(
    viewModel: BravViewModel,
    onOpenConversation: (String) -> Unit,
    onBack: (() -> Unit)? = null
) {
    if (onBack != null) {
        BackHandler { onBack() }
    }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val statuses by viewModel.statuses.collectAsStateWithLifecycle()
    val savedContacts by viewModel.savedContactUsers.collectAsStateWithLifecycle()

    var showCreateTextDialog by remember { mutableStateOf(false) }
    var activeViewingStatusId by remember { mutableStateOf<String?>(null) }
    var activeCommentsStatusId by remember { mutableStateOf<String?>(null) }
    var expandedEmojiCardId by remember { mutableStateOf<String?>(null) }
    var burstTrigger by remember { mutableStateOf<Pair<BravReactionType, Long>?>(null) }

    val viewingStatus = remember(statuses, activeViewingStatusId) {
        activeViewingStatusId?.let { id -> statuses.firstOrNull { it.id == id } }
    }
    val commentsStatus = remember(statuses, activeCommentsStatusId) {
        activeCommentsStatusId?.let { id -> statuses.firstOrNull { it.id == id } }
    }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val me = currentUser ?: return@rememberLauncherForActivityResult
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
            val isVid = mime.startsWith("video/")
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@launch
            viewModel.showMessage("Publication du statut...")
            val res = viewModel.socialRepository.createMediaStatus(
                user = me,
                bytes = bytes,
                mimeType = mime,
                isVideo = isVid,
                caption = ""
            )
            if (res.isSuccess) viewModel.showMessage("Statut publié pour 24h !")
            else viewModel.showMessage(res.exceptionOrNull()?.localizedMessage ?: "Échec de publication")
        }
    }

    fun triggerBurst(reaction: BravReactionType) {
        burstTrigger = reaction to System.currentTimeMillis()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                if (onBack != null) {
                    TopAppBar(
                        title = {
                            Column {
                                Text("Statuts 24h • Studio Pro", fontWeight = FontWeight.ExtraBold)
                                Text(
                                    "Likes, commentaires & émojis futuristes",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onBack) {
                                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
                            }
                        }
                    )
                }
            },
            floatingActionButton = {
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    FloatingActionButton(
                        onClick = {
                            mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                        },
                        containerColor = Color(0xFF0E172A),
                        contentColor = Color(0xFF22D3EE)
                    ) {
                        Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = "Statut photo ou vidéo")
                    }
                    FloatingActionButton(
                        onClick = { showCreateTextDialog = true },
                        containerColor = BravPurple,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("create_text_status_fab")
                    ) {
                        Icon(Icons.Rounded.Edit, contentDescription = "Statut texte")
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                if (onBack == null) {
                    Spacer(Modifier.height(8.dp))
                    Text("Statuts 24h • Studio Pro", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text(
                        "Partagez vos moments, commentez, likez et envoyez des émojis futuristes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                }

                // Story Rings Strip
                if (statuses.isNotEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(vertical = 6.dp)
                    ) {
                        items(statuses, key = { "ring_${it.id}" }) { st ->
                            val isViewed = viewModel.currentUserId in st.viewerIds
                            val ringBrush = if (isViewed) {
                                Brush.linearGradient(listOf(Color.Gray.copy(alpha = 0.5f), Color.Gray.copy(alpha = 0.3f)))
                            } else {
                                Brush.linearGradient(listOf(Color(0xFF22D3EE), BravPurpleBright, BravRed))
                            }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .width(68.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { activeViewingStatusId = st.id }
                                    .padding(vertical = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .border(2.5.dp, ringBrush, CircleShape)
                                        .padding(4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    UserAvatarWithStatus(
                                        name = st.userName,
                                        avatarUrl = st.userAvatar,
                                        size = 50.dp
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = if (st.userId == viewModel.currentUserId) "Vous" else st.userName.split(" ").firstOrNull().orEmpty(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                if (statuses.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Rounded.AutoAwesome,
                                contentDescription = null,
                                tint = BravPurpleBright,
                                modifier = Modifier.size(46.dp)
                            )
                            Text("Aucun statut actif pour le moment.", fontWeight = FontWeight.Bold)
                            Text(
                                "Créez un statut texte, photo ou vidéo en appuyant sur +.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 104.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(statuses, key = { it.id }) { status ->
                            val isMine = status.userId == viewModel.currentUserId
                            val isLiked = viewModel.currentUserId in status.likedByUids
                            val showEmojiDock = expandedEmojiCardId == status.id

                            FuturisticStatusFeedCard(
                                status = status,
                                isMine = isMine,
                                myUid = viewModel.currentUserId,
                                isLiked = isLiked,
                                showEmojiDock = showEmojiDock,
                                onOpenViewer = { activeViewingStatusId = status.id },
                                onToggleLike = { viewModel.toggleStatusLike(status) },
                                onOpenComments = { activeCommentsStatusId = status.id },
                                onToggleEmojiDock = {
                                    expandedEmojiCardId = if (showEmojiDock) null else status.id
                                },
                                onToggleReaction = { reaction ->
                                    triggerBurst(reaction)
                                    viewModel.toggleStatusReaction(status, reaction.key)
                                },
                                onDeleteStatus = {
                                    scope.launch { viewModel.socialRepository.deleteStatus(status.id) }
                                }
                            )
                        }
                    }
                }
            }
        }

        // Global burst overlay on top of the feed screen when emitting futuristic/funny emojis
        FloatingEmojiBurstOverlay(burstTrigger = burstTrigger)
    }

    if (showCreateTextDialog) {
        var text by remember { mutableStateOf("") }
        var bgHex by remember { mutableStateOf("#570CA2") }
        var restrictAudience by remember { mutableStateOf(false) }
        val allowed = remember { mutableStateListOf<String>() }

        AlertDialog(
            onDismissRequest = { showCreateTextDialog = false },
            title = { Text("Nouveau statut texte") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        label = { Text("Votre message (24h)") },
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("#570CA2", "#EA0D1B", "#0F766E", "#1E293B", "#0EA5E9").forEach { hex ->
                            val c = Color(android.graphics.Color.parseColor(hex))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = c,
                                onClick = { bgHex = hex },
                                modifier = Modifier
                                    .size(32.dp)
                                    .then(
                                        if (bgHex == hex) Modifier.border(2.dp, Color.White, RoundedCornerShape(10.dp))
                                        else Modifier
                                    )
                            ) {}
                        }
                    }
                    OutlinedButton(onClick = { restrictAudience = !restrictAudience }) {
                        Text(if (restrictAudience) "Audience : Sélectionnée" else "Audience : Tous les contacts")
                    }
                    if (restrictAudience && savedContacts.isNotEmpty()) {
                        LazyColumn(modifier = Modifier.height(110.dp)) {
                            items(savedContacts, key = { it.userId }) { u ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = u.userId in allowed,
                                        onCheckedChange = { c -> if (c) allowed.add(u.userId) else allowed.remove(u.userId) }
                                    )
                                    Text(u.displayName)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = text.isNotBlank(),
                    onClick = {
                        val me = currentUser ?: return@Button
                        scope.launch {
                            viewModel.socialRepository.createTextStatus(
                                user = me,
                                text = text,
                                backgroundColor = bgHex,
                                audienceType = if (restrictAudience) "selected" else "all",
                                allowedUids = allowed.toList()
                            )
                            showCreateTextDialog = false
                        }
                    }
                ) { Text("Publier") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateTextDialog = false }) { Text("Annuler") }
            }
        )
    }

    // Full-screen Futuristic Status Viewer (Text, Photo & Video)
    viewingStatus?.let { status ->
        LaunchedEffect(status.id) {
            if (viewModel.currentUserId !in status.viewerIds) {
                viewModel.socialRepository.markStatusViewed(status.id, viewModel.currentUserId)
            }
        }
        FuturisticStatusViewerDialog(
            status = status,
            myUid = viewModel.currentUserId,
            viewModel = viewModel,
            onDismiss = { activeViewingStatusId = null },
            onOpenComments = { activeCommentsStatusId = status.id },
            onOpenPrivateChat = { cid ->
                activeViewingStatusId = null
                onOpenConversation(cid)
            }
        )
    }

    // Real-Time Comments + Futuristic Emoji Studio Bottom Sheet
    commentsStatus?.let { status ->
        StatusCommentsBottomSheet(
            status = status,
            viewModel = viewModel,
            onDismiss = { activeCommentsStatusId = null }
        )
    }
}

@Composable
private fun FuturisticStatusFeedCard(
    status: StatusPost,
    isMine: Boolean,
    myUid: String,
    isLiked: Boolean,
    showEmojiDock: Boolean,
    onOpenViewer: () -> Unit,
    onToggleLike: () -> Unit,
    onOpenComments: () -> Unit,
    onToggleEmojiDock: () -> Unit,
    onToggleReaction: (BravReactionType) -> Unit,
    onDeleteStatus: () -> Unit
) {
    val context = LocalContext.current
    val cyberCyan = Color(0xFF22D3EE)
    val cardBorderBrush = Brush.linearGradient(
        colors = listOf(cyberCyan.copy(alpha = 0.48f), BravPurpleBright.copy(alpha = 0.62f), BravRed.copy(alpha = 0.42f))
    )
    val statusBgColor = runCatching { Color(android.graphics.Color.parseColor(status.backgroundColor)) }
        .getOrDefault(BravPurple)
    val myActiveReactionKey = remember(status.reactions, myUid) {
        status.reactions.entries.firstOrNull { myUid in it.value }?.key
    }

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.25.dp, cardBorderBrush, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onOpenViewer)
            .testTag("status_card_${status.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Card Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .border(2.dp, cardBorderBrush, CircleShape)
                        .padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    UserAvatarWithStatus(
                        name = status.userName,
                        avatarUrl = status.userAvatar,
                        size = 42.dp
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isMine) "Mon statut" else status.userName.ifBlank { "Membre BRAV" },
                        fontWeight = FontWeight.ExtraBold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val timeText = status.createdAt?.let { formatShortDateTime(it.seconds) }.orEmpty()
                        if (timeText.isNotBlank()) {
                            Text(
                                text = timeText,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = if (status.audienceType == "selected") Icons.Rounded.Lock else Icons.Rounded.Public,
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = if (status.audienceType == "selected") BravRed else cyberCyan
                        )
                        Text(
                            text = if (status.audienceType == "selected") "Privé" else "Contacts",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Rounded.Visibility, contentDescription = "Vues", modifier = Modifier.size(14.dp), tint = BravPurple)
                        Text("${status.viewerIds.size}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
                if (isMine) {
                    IconButton(onClick = onDeleteStatus, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Supprimer statut", tint = BravRed, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Visual Stage Frame
            when (status.type) {
                "image" -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color(0xFF0E091A))
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(context).data(status.mediaUrl).crossfade(true).build(),
                            contentDescription = status.caption.ifBlank { "Statut photo" },
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        if (status.caption.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.55f))
                                    .padding(10.dp)
                            ) {
                                Text(status.caption, color = Color.White, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                            }
                        }
                    }
                }
                "video" -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.linearGradient(listOf(Color(0xFF1F093D), Color(0xFF0A0E24)))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Rounded.PlayCircleFilled,
                                contentDescription = "Lire la vidéo du statut",
                                tint = cyberCyan,
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = status.caption.ifBlank { "Statut vidéo HD • Appuyez pour lire" },
                                color = Color.White,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                else -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 128.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(statusBgColor, statusBgColor.copy(alpha = 0.78f), Color(0xFF190A33)),
                                    start = Offset(0f, 0f),
                                    end = Offset(700f, 400f)
                                )
                            )
                            .padding(18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = status.text,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Live Animated Reactions on Status Card
            if (status.reactions.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                MessageReactionsRow(
                    reactions = status.reactions,
                    myUid = myUid,
                    onToggleReaction = onToggleReaction
                )
            }

            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
            Spacer(Modifier.height(8.dp))

            // Interactive Like / Comment / Futuristic Emoji Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = if (isLiked) BravRed.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceContainerHighest,
                    onClick = onToggleLike,
                    modifier = Modifier.testTag("like_status_${status.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = "J'aime",
                            tint = if (isLiked) BravRed else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (status.likedByUids.isEmpty()) "J'aime" else "${status.likedByUids.size}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isLiked) BravRed else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    onClick = onOpenComments,
                    modifier = Modifier.testTag("comment_status_${status.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ChatBubbleOutline,
                            contentDescription = "Commenter",
                            tint = BravPurple,
                            modifier = Modifier.size(17.dp)
                        )
                        Text(
                            text = if (status.commentCount <= 0L) "Commenter" else "${status.commentCount}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = if (showEmojiDock) Color(0xFF130B29) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                    onClick = onToggleEmojiDock,
                    modifier = Modifier.testTag("emoji_dock_toggle_${status.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = "Émojis futuristes",
                            tint = if (showEmojiDock) cyberCyan else BravPurple,
                            modifier = Modifier.size(17.dp)
                        )
                        Text(
                            text = "Émojis",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (showEmojiDock) cyberCyan else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            AnimatedVisibility(visible = showEmojiDock) {
                Column {
                    Spacer(Modifier.height(10.dp))
                    FuturisticEmojiStudioDock(
                        selectedKey = myActiveReactionKey,
                        onEmitReaction = { reaction -> onToggleReaction(reaction) }
                    )
                }
            }
        }
    }
}

@Composable
private fun FuturisticStatusViewerDialog(
    status: StatusPost,
    myUid: String,
    viewModel: BravViewModel,
    onDismiss: () -> Unit,
    onOpenComments: () -> Unit,
    onOpenPrivateChat: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var replyText by remember { mutableStateOf("") }
    var showEmojiStudio by remember { mutableStateOf(false) }
    var burstTrigger by remember { mutableStateOf<Pair<BravReactionType, Long>?>(null) }

    val isLiked = myUid in status.likedByUids
    val myActiveReactionKey = remember(status.reactions, myUid) {
        status.reactions.entries.firstOrNull { myUid in it.value }?.key
    }
    val cyberCyan = Color(0xFF22D3EE)

    val shimmer = rememberInfiniteTransition(label = "status_viewer_progress")
    val barProgress by shimmer.animateFloat(
        initialValue = 0.08f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
        label = "bar"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val bgColor = runCatching { Color(android.graphics.Color.parseColor(status.backgroundColor)) }
            .getOrDefault(Color(0xFF1A0836))
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = if (status.type == "text") bgColor else Color(0xFF070410)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Main Stage
                when (status.type) {
                    "image" -> {
                        AsyncImage(
                            model = ImageRequest.Builder(context).data(status.mediaUrl).crossfade(true).build(),
                            contentDescription = status.caption.ifBlank { "Statut de ${status.userName}" },
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    "video" -> {
                        var localVideoFile by remember(status.mediaUrl) { mutableStateOf<File?>(null) }
                        var videoError by remember(status.mediaUrl) { mutableStateOf<String?>(null) }
                        LaunchedEffect(status.mediaUrl) {
                            val res = viewModel.workerApiClient.downloadMediaToCache(context, status.mediaUrl, "status_${status.id}.mp4")
                            res.onSuccess { localVideoFile = it }
                                .onFailure { videoError = it.localizedMessage ?: "Lecture vidéo impossible" }
                        }
                        val playbackUri = localVideoFile?.let { Uri.fromFile(it) }
                        if (playbackUri != null) {
                            val exoPlayer = remember(playbackUri) {
                                ExoPlayer.Builder(context).build().apply {
                                    setMediaItem(MediaItem.fromUri(playbackUri))
                                    prepare()
                                    playWhenReady = true
                                }
                            }
                            DisposableEffect(exoPlayer) {
                                onDispose { exoPlayer.release() }
                            }
                            AndroidView(
                                factory = { ctx ->
                                    PlayerView(ctx).apply {
                                        player = exoPlayer
                                        layoutParams = ViewGroup.LayoutParams(
                                            ViewGroup.LayoutParams.MATCH_PARENT,
                                            ViewGroup.LayoutParams.MATCH_PARENT
                                        )
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else if (videoError != null) {
                            Text(
                                text = videoError ?: "Erreur vidéo",
                                color = Color.White,
                                modifier = Modifier.align(Alignment.Center).padding(24.dp)
                            )
                        } else {
                            CircularProgressIndicator(color = cyberCyan, modifier = Modifier.align(Alignment.Center))
                        }
                    }
                    else -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.radialGradient(
                                        listOf(bgColor, bgColor.copy(alpha = 0.72f), Color(0xFF0A0518))
                                    )
                                )
                                .padding(horizontal = 28.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = status.text,
                                color = Color.White,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Top Cyber Header HUD
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.72f), Color.Transparent)))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { barProgress },
                        color = cyberCyan,
                        trackColor = Color.White.copy(alpha = 0.25f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(999.dp))
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatarWithStatus(name = status.userName, avatarUrl = status.userAvatar, size = 40.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(status.userName.ifBlank { "Membre BRAV" }, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${status.viewerIds.size} vue(s) • ${status.likedByUids.size} j'aime • ${status.commentCount} comm.",
                                color = Color.White.copy(alpha = 0.78f),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Rounded.Close, contentDescription = "Fermer", tint = Color.White)
                        }
                    }
                }

                // Bottom Interactive Studio Dock
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (status.reactions.isNotEmpty()) {
                        MessageReactionsRow(
                            reactions = status.reactions,
                            myUid = myUid,
                            onToggleReaction = { r ->
                                burstTrigger = r to System.currentTimeMillis()
                                viewModel.toggleStatusReaction(status, r.key)
                            }
                        )
                    }

                    AnimatedVisibility(visible = showEmojiStudio) {
                        FuturisticEmojiStudioDock(
                            selectedKey = myActiveReactionKey,
                            onEmitReaction = { r ->
                                burstTrigger = r to System.currentTimeMillis()
                                viewModel.toggleStatusReaction(status, r.key)
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = if (isLiked) BravRed else Color.White.copy(alpha = 0.16f),
                            onClick = { viewModel.toggleStatusLike(status) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                    contentDescription = "J'aime",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text("${status.likedByUids.size}", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = Color.White.copy(alpha = 0.16f),
                            onClick = onOpenComments
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = "Commentaires", tint = Color.White, modifier = Modifier.size(18.dp))
                                Text("${status.commentCount}", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = if (showEmojiStudio) cyberCyan.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.16f),
                            onClick = { showEmojiStudio = !showEmojiStudio }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, contentDescription = "Émojis", tint = cyberCyan, modifier = Modifier.size(18.dp))
                                Text("Émojis", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (status.userId != myUid) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = replyText,
                                onValueChange = { replyText = it },
                                placeholder = { Text("Répondre en privé...", color = Color.White.copy(alpha = 0.7f)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = cyberCyan,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.35f)
                                ),
                                shape = RoundedCornerShape(999.dp),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Button(
                                enabled = replyText.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = BravPurple),
                                onClick = {
                                    scope.launch {
                                        val target = viewModel.userRepository.getUserById(status.userId)
                                        if (target != null) {
                                            viewModel.openOrCreateDirectChat(target).onSuccess { conv ->
                                                viewModel.chatRepository.sendTextMessage(
                                                    conv,
                                                    myUid,
                                                    "Réponse à votre statut : $replyText",
                                                    peerPublicKey = target.publicKey
                                                )
                                                onOpenPrivateChat(conv.id)
                                            }
                                        }
                                    }
                                }
                            ) { Text("Envoyer") }
                        }
                    }
                }

                FloatingEmojiBurstOverlay(burstTrigger = burstTrigger)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StatusCommentsBottomSheet(
    status: StatusPost,
    viewModel: BravViewModel,
    onDismiss: () -> Unit
) {
    val comments by viewModel.socialRepository.observeStatusComments(status.id)
        .collectAsStateWithLifecycle(initialValue = emptyList())
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var commentText by remember { mutableStateOf("") }
    var selectedReaction by remember { mutableStateOf<BravReactionType?>(null) }
    var showEmojiDock by remember { mutableStateOf(true) }
    var burstTrigger by remember { mutableStateOf<Pair<BravReactionType, Long>?>(null) }
    val cyberCyan = Color(0xFF22D3EE)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Commentaires • ${status.userName}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "${comments.size} commentaire(s) • ${status.likedByUids.size} j'aime",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { showEmojiDock = !showEmojiDock }) {
                        Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = BravPurple, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (showEmojiDock) "Masquer studio" else "Émojis")
                    }
                }

                Spacer(Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))

                if (comments.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Soyez le premier à commenter avec un émoji futuriste !",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(comments, key = { it.id }) { comment ->
                            StatusCommentRow(
                                comment = comment,
                                canDelete = comment.authorId == viewModel.currentUserId || status.userId == viewModel.currentUserId,
                                onDelete = { viewModel.deleteStatusComment(status.id, comment.id) }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                AnimatedVisibility(visible = showEmojiDock) {
                    Column {
                        FuturisticEmojiStudioDock(
                            selectedKey = selectedReaction?.key,
                            title = "Joindre un Émoji Futuriste ou Drôle",
                            onEmitReaction = { reaction ->
                                burstTrigger = reaction to System.currentTimeMillis()
                                selectedReaction = if (selectedReaction == reaction) null else reaction
                            }
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                }

                selectedReaction?.let { chosen ->
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = BravPurple.copy(alpha = 0.14f),
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            AnimatedReactionIcon(reaction = chosen, size = 20.dp)
                            Text(
                                text = "Émoji sélectionné : ${chosen.label}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = BravPurple
                            )
                            IconButton(
                                onClick = { selectedReaction = null },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = "Retirer", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        placeholder = { Text("Écrire un commentaire fun ou futuriste...") },
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 3,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("status_comment_input")
                    )
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        shape = CircleShape,
                        color = if (commentText.isNotBlank() || selectedReaction != null) cyberCyan else MaterialTheme.colorScheme.surfaceContainerHighest,
                        onClick = {
                            if (commentText.isNotBlank() || selectedReaction != null) {
                                val chosen = selectedReaction
                                if (chosen != null) burstTrigger = chosen to System.currentTimeMillis()
                                viewModel.addStatusComment(
                                    statusId = status.id,
                                    text = commentText,
                                    reactionKey = chosen?.key.orEmpty()
                                ) {
                                    commentText = ""
                                    selectedReaction = null
                                }
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("send_status_comment_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.AutoMirrored.Rounded.Send,
                                contentDescription = "Publier le commentaire",
                                tint = if (commentText.isNotBlank() || selectedReaction != null) Color(0xFF0A0614) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            FloatingEmojiBurstOverlay(burstTrigger = burstTrigger)
        }
    }
}

@Composable
private fun StatusCommentRow(
    comment: StatusComment,
    canDelete: Boolean,
    onDelete: () -> Unit
) {
    val reaction = remember(comment.reactionKey) {
        if (comment.reactionKey.isNotBlank()) BravReactionType.fromKey(comment.reactionKey) else null
    }
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            UserAvatarWithStatus(
                name = comment.authorName,
                avatarUrl = comment.authorAvatar,
                size = 34.dp
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = comment.authorName.ifBlank { "Membre BRAV" },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    val time = comment.createdAt?.let { formatShortDateTime(it.seconds) }.orEmpty()
                    if (time.isNotBlank()) {
                        Text(
                            text = time,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (comment.text.isNotBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = comment.text,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                if (reaction != null) {
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Color(0xFF150C2B)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            AnimatedReactionIcon(reaction = reaction, size = 20.dp)
                            Text(
                                text = reaction.label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF22D3EE)
                            )
                        }
                    }
                }
            }
            if (canDelete) {
                IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                    Icon(
                        Icons.Rounded.DeleteOutline,
                        contentDescription = "Supprimer le commentaire",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
        }
    }
}
