package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.Contact
import com.example.model.User
import com.example.ui.components.UserAvatarWithStatus
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed
import com.example.ui.theme.CallActionGreen
import com.example.ui.theme.StatusOnlineGreen
import com.example.util.DefaultDialerHelper
import com.example.util.PhoneUtils
import kotlinx.coroutines.delay

@Composable
fun DefaultDialerActionCard(
    onStatusChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var refreshTick by remember { mutableIntStateOf(0) }
    val supported = remember(refreshTick) { DefaultDialerHelper.isDefaultDialerSupported(context) }
    val isDefault = remember(refreshTick) { DefaultDialerHelper.isBravDefaultDialer(context) }

    val roleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshTick++
        onStatusChanged(DefaultDialerHelper.isBravDefaultDialer(context))
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isDefault) StatusOnlineGreen.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.55f),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("default_dialer_card")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = if (isDefault) Icons.Rounded.CheckCircle else Icons.Rounded.PhoneAndroid,
                contentDescription = null,
                tint = if (isDefault) StatusOnlineGreen else BravPurple,
                modifier = Modifier.size(22.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isDefault) "Compositeur par défaut actif" else "Compositeur téléphonique par défaut",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = when {
                        isDefault -> "BRAV Chat gère la composition des numéros sur cet appareil."
                        supported -> "Utilisez BRAV Chat pour composer vos numéros et appels mobile."
                        else -> "Non pris en charge par cet appareil."
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (supported && !isDefault) {
                Button(
                    onClick = {
                        val intent = DefaultDialerHelper.createRequestDefaultDialerIntent(context)
                        if (intent != null) {
                            runCatching { roleLauncher.launch(intent) }
                        }
                    },
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier.testTag("set_default_dialer_button")
                ) {
                    Text("Définir", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun DialerModalSheet(
    initialNumber: String = "",
    savedContacts: List<User>,
    phoneContacts: List<Contact>,
    searchedUsers: List<User>,
    onLookupNumber: (String) -> Unit,
    onStartBravAudioCall: (peerUid: String, peerName: String) -> Unit,
    onStartBravVideoCall: (peerUid: String, peerName: String) -> Unit,
    onFeedback: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var dialNumber by remember(initialNumber) {
        mutableStateOf(DefaultDialerHelper.sanitizeDialInput(initialNumber))
    }
    var pendingCarrierNumber by remember { mutableStateOf<String?>(null) }
    var dialerRefreshTick by remember { mutableIntStateOf(0) }

    val isDefaultDialer = remember(dialerRefreshTick) {
        DefaultDialerHelper.isBravDefaultDialer(context)
    }
    val canBeDefaultDialer = remember(dialerRefreshTick) {
        DefaultDialerHelper.isDefaultDialerSupported(context)
    }

    val roleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        dialerRefreshTick++
        val nowDefault = DefaultDialerHelper.isBravDefaultDialer(context)
        if (nowDefault) {
            onFeedback("BRAV Chat est maintenant votre compositeur par défaut")
        }
    }

    val callPhoneLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val num = pendingCarrierNumber
        pendingCarrierNumber = null
        if (granted && !num.isNullOrBlank()) {
            val placed = DefaultDialerHelper.placeCarrierCall(context, num)
            if (placed) onDismiss() else onFeedback("Impossible de lancer l'appel mobile")
        } else if (!granted) {
            onFeedback("Autorisation Téléphone requise pour les appels mobiles")
        }
    }

    val bravCallPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    LaunchedEffect(dialNumber) {
        val digitCount = dialNumber.count { it.isDigit() }
        if (digitCount >= 6) {
            delay(280L)
            onLookupNumber(dialNumber)
        }
    }

    val matchedPhoneContacts = remember(dialNumber, phoneContacts) {
        val qDigits = dialNumber.filter { it.isDigit() }
        if (qDigits.length < 2) emptyList()
        else phoneContacts.filter { c ->
            c.normalizedPhoneNumber.contains(qDigits) ||
                c.rawPhoneNumber.filter { it.isDigit() }.contains(qDigits)
        }.take(4)
    }

    val matchedBravUsers = remember(dialNumber, savedContacts, searchedUsers, matchedPhoneContacts) {
        val pool = (savedContacts + searchedUsers + matchedPhoneContacts.mapNotNull { it.bravUser })
            .distinctBy { it.userId }
        val qDigits = dialNumber.filter { it.isDigit() }
        if (qDigits.length < 2) emptyList()
        else {
            pool.filter { user ->
                val maskedDigits = user.phoneMasked.filter { it.isDigit() }
                (maskedDigits.isNotEmpty() && (qDigits.endsWith(maskedDigits) || maskedDigits.contains(qDigits))) ||
                    searchedUsers.any { it.userId == user.userId } ||
                    matchedPhoneContacts.any { it.bravUser?.userId == user.userId }
            }.take(3)
        }
    }

    fun appendDigit(d: String) {
        if (dialNumber.length < 22) {
            dialNumber = DefaultDialerHelper.sanitizeDialInput(dialNumber + d)
        }
    }

    fun triggerCarrierCall(number: String) {
        val cleaned = DefaultDialerHelper.sanitizeDialInput(number)
        if (cleaned.isBlank()) return
        if (DefaultDialerHelper.hasCallPhonePermission(context)) {
            val ok = DefaultDialerHelper.placeCarrierCall(context, cleaned)
            if (ok) onDismiss() else onFeedback("Impossible de passer cet appel mobile")
        } else {
            pendingCarrierNumber = cleaned
            callPhoneLauncher.launch(Manifest.permission.CALL_PHONE)
        }
    }

    fun triggerBravCall(user: User, isVideo: Boolean) {
        val name = user.displayName.ifBlank { "@${user.username}" }
        val needMic = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
        val needCam = isVideo && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        if (needMic || needCam) {
            val perms = buildList {
                if (needMic) add(Manifest.permission.RECORD_AUDIO)
                if (needCam) add(Manifest.permission.CAMERA)
            }.toTypedArray()
            bravCallPermLauncher.launch(perms)
            return
        }
        onDismiss()
        if (isVideo) onStartBravVideoCall(user.userId, name) else onStartBravAudioCall(user.userId, name)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.Dialpad, contentDescription = null, tint = BravPurple)
                    Text("Clavier téléphonique", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (canBeDefaultDialer && !isDefaultDialer) {
                        TextButton(
                            onClick = {
                                val intent = DefaultDialerHelper.createRequestDefaultDialerIntent(context)
                                if (intent != null) runCatching { roleLauncher.launch(intent) }
                            },
                            modifier = Modifier.testTag("dialer_set_default_button")
                        ) {
                            Text("Définir par défaut", color = BravPurple, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("dialer_close_button")) {
                        Icon(Icons.Rounded.Close, contentDescription = "Fermer le clavier")
                    }
                }
            }

            // Number display
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (dialNumber.isBlank()) "Saisir un numéro" else PhoneUtils.formatDisplay(dialNumber),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (dialNumber.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("dialer_number_display")
                )
                if (dialNumber.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .combinedClickable(
                                onClick = { dialNumber = dialNumber.dropLast(1) },
                                onLongClick = { dialNumber = "" }
                            )
                            .testTag("dialer_backspace_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.Backspace,
                            contentDescription = "Effacer un chiffre",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Live Contact / BRAV User Matches
            if (matchedBravUsers.isNotEmpty() || matchedPhoneContacts.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(matchedBravUsers, key = { "brav_${it.userId}" }) { user ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = BravPurple.copy(alpha = 0.08f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatarWithStatus(
                                    name = user.displayName,
                                    avatarUrl = user.avatarUrl,
                                    availabilityStatus = user.availabilityStatus,
                                    size = 36.dp
                                )
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(user.displayName.ifBlank { user.username }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        text = "BRAV Chat • @${user.username}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = BravPurple
                                    )
                                }
                                IconButton(
                                    onClick = { triggerBravCall(user, isVideo = false) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Rounded.Call, contentDescription = "Appel audio BRAV", tint = CallActionGreen)
                                }
                                IconButton(
                                    onClick = { triggerBravCall(user, isVideo = true) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Rounded.Videocam, contentDescription = "Appel vidéo BRAV", tint = BravRed)
                                }
                            }
                        }
                    }

                    items(
                        matchedPhoneContacts.filter { c -> matchedBravUsers.none { it.userId == c.bravUser?.userId } },
                        key = { "sim_${it.id}" }
                    ) { contact ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            onClick = { dialNumber = DefaultDialerHelper.sanitizeDialInput(contact.rawPhoneNumber) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(contact.preferredDisplayName, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    Text(contact.rawPhoneNumber, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Icon(Icons.Rounded.Call, contentDescription = "Sélectionner", tint = CallActionGreen, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            // Keypad Grid
            val rows = remember {
                listOf(
                    listOf("1" to "", "2" to "ABC", "3" to "DEF"),
                    listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                    listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
                    listOf("*" to "", "0" to "+", "#" to "")
                )
            }
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        row.forEach { (digit, letters) ->
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerLow,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(58.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .combinedClickable(
                                        onClick = { appendDigit(digit) },
                                        onLongClick = { if (digit == "0") appendDigit("+") }
                                    )
                                    .testTag("dialer_key_$digit")
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(digit, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                                    if (letters.isNotEmpty()) {
                                        Text(
                                            letters,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Primary Call Actions
            val primaryBravUser = matchedBravUsers.firstOrNull()
            if (primaryBravUser != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { triggerBravCall(primaryBravUser, isVideo = false) },
                        colors = ButtonDefaults.buttonColors(containerColor = CallActionGreen, contentColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f).height(52.dp).testTag("dialer_brav_audio_button")
                    ) {
                        Icon(Icons.Rounded.Call, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("BRAV Audio", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { triggerCarrierCall(dialNumber) },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.height(52.dp).testTag("dialer_carrier_call_button")
                    ) {
                        Icon(Icons.Rounded.PhoneAndroid, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("SIM")
                    }
                }
            } else {
                Button(
                    onClick = { triggerCarrierCall(dialNumber) },
                    enabled = dialNumber.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = CallActionGreen, contentColor = Color.White),
                    shape = RoundedCornerShape(999.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.72f)
                        .height(54.dp)
                        .testTag("dialer_place_call_button")
                ) {
                    Icon(Icons.Rounded.Call, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Appeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}
