package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Call(
    @DocumentId val id: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val callerAvatar: String = "",
    val callerUsername: String = "",
    val receiverId: String = "",
    val receiverName: String = "",
    val receiverAvatar: String = "",
    val receiverUsername: String = "",
    val participantIds: List<String> = emptyList(),
    val callType: String = "audio", // audio | video
    val status: String = "calling", // calling | accepted | on_hold | rejected | ended
    val heldByUid: String = "",
    val missed: Boolean = false,
    val durationSeconds: Long = 0L,
    val hiddenForUsers: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    val endedAt: Timestamp? = null
)

data class Contact(
    val id: String = "",
    val phoneDisplayName: String = "",
    val rawPhoneNumber: String = "",
    val normalizedPhoneNumber: String = "",
    val bravUser: User? = null
) {
    val isBravUser: Boolean get() = bravUser != null
    val displayLocation: String
        get() {
            val user = bravUser ?: return ""
            return when {
                user.locationCity.isNotBlank() && user.locationDetails.isNotBlank() ->
                    "${user.locationCity} (${user.locationDetails})"
                user.locationCity.isNotBlank() -> user.locationCity
                user.locationDetails.isNotBlank() -> user.locationDetails
                else -> "Localisation non précisée"
            }
        }
    val preferredDisplayName: String
        get() = when {
            phoneDisplayName.isNotBlank() -> phoneDisplayName
            bravUser?.displayName?.isNotBlank() == true -> bravUser.displayName
            else -> normalizedPhoneNumber
        }
}
