package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed
import com.example.ui.theme.StatusOnlineGreen
import com.example.viewmodel.BravViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OffersMarketplaceScreen(
    viewModel: BravViewModel,
    onOpenConversation: (String) -> Unit = {},
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val scope = rememberCoroutineScope()
    val offers by viewModel.offers.collectAsStateWithLifecycle()
    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("Toutes") }

    val categories = remember { listOf("Toutes", "Services", "Emploi", "Vente", "Immobilier") }
    val visibleOffers = remember(offers, selectedCategory) {
        if (selectedCategory == "Toutes") offers
        else offers.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
                    }
                },
                title = { Text("Annonces & Offres gratuites") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = BravPurple,
                contentColor = Color.White
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Publier une annonce gratuite")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = StatusOnlineGreen.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Storefront, contentDescription = null, tint = StatusOnlineGreen)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = "Publication 100% gratuite pour tous les membres BRAV Chat.",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) }
                        )
                    }
                }
            }

            if (visibleOffers.isEmpty()) {
                item {
                    Text(
                        "Aucune annonce publiée pour le moment. Appuyez sur + pour publier gratuitement votre offre.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(visibleOffers, key = { it.id }) { offer ->
                    val isMine = offer.userId == viewModel.currentUserId
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    offer.title,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = StatusOnlineGreen.copy(alpha = 0.16f)
                                ) {
                                    Text(
                                        text = "Gratuit",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusOnlineGreen,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Text(
                                "${offer.category} • ${offer.locationCity.ifBlank { "En ligne" }}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (offer.description.isNotBlank()) {
                                Text(offer.description, style = MaterialTheme.typography.bodyMedium)
                            }
                            if (offer.priceOrSalary.isNotBlank()) {
                                Text(
                                    "Tarif / Salaire : ${offer.priceOrSalary}",
                                    fontWeight = FontWeight.SemiBold,
                                    color = BravPurple
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "Par ${offer.authorName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (isMine) {
                                    TextButton(onClick = { viewModel.deleteListing(offer.id) }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = null, tint = BravRed, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Supprimer", color = BravRed)
                                    }
                                } else if (offer.userId.isNotBlank()) {
                                    OutlinedButton(onClick = {
                                        scope.launch {
                                            val target = viewModel.userRepository.getUserById(offer.userId)
                                            if (target != null) {
                                                viewModel.openOrCreateDirectChat(target).onSuccess { conv ->
                                                    onOpenConversation(conv.id)
                                                }
                                            }
                                        }
                                    }) {
                                        Icon(Icons.Rounded.ChatBubble, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Contacter")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var title by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Services") }
        var desc by remember { mutableStateOf("") }
        var city by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Publier une annonce gratuite") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Titre de l'annonce") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Services", "Emploi", "Vente").forEach { preset ->
                            FilterChip(
                                selected = category.equals(preset, ignoreCase = true),
                                onClick = { category = preset },
                                label = { Text(preset) }
                            )
                        }
                    }
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Catégorie") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") }, maxLines = 3)
                    OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("Ville") }, singleLine = true)
                    OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Prix / Salaire (optionnel)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    enabled = title.trim().length >= 2 && category.trim().length >= 2,
                    colors = ButtonDefaults.buttonColors(containerColor = BravPurple, contentColor = Color.White),
                    onClick = {
                        viewModel.createFreeListing(title, category, desc, city, price)
                        showCreateDialog = false
                    }
                ) { Text("Publier gratuitement") }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Annuler") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminModerationScreen(
    viewModel: BravViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val scope = rememberCoroutineScope()
    val reports by viewModel.adminReports.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
                    }
                },
                title = { Text("Espace Administration BRAV") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Signalements utilisateurs (${reports.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            if (reports.isEmpty()) {
                item {
                    Text("Aucun signalement en attente.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(reports, key = { it.id }) { rep ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Motif : ${rep.reason}", fontWeight = FontWeight.Bold)
                            Text("Statut : ${rep.status} • Cible : ${rep.targetUid.ifBlank { "-" }}", style = MaterialTheme.typography.bodySmall)
                            if (rep.details.isNotBlank()) Text(rep.details, style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    scope.launch { viewModel.socialRepository.adminUpdateReportStatus(rep.id, "dismissed") }
                                }) { Text("Classer") }
                                if (rep.targetUid.isNotBlank()) {
                                    Button(
                                        colors = ButtonDefaults.buttonColors(containerColor = BravRed, contentColor = Color.White),
                                        onClick = {
                                            scope.launch {
                                                viewModel.socialRepository.adminToggleUserSuspension(rep.targetUid, true)
                                                viewModel.socialRepository.adminUpdateReportStatus(rep.id, "action_taken")
                                                viewModel.showMessage("Compte cible suspendu")
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Rounded.Verified, contentDescription = null)
                                        Spacer(Modifier.width(4.dp))
                                        Text("Suspendre")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
