package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Reply
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.media.VoicePlaybackState
import com.example.model.BravReactionType
import com.example.model.Message
import com.example.ui.components.MessageReactionsRow
import com.example.ui.components.VoiceMessageBubble
import com.example.ui.components.formatShortTime
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed
import org.json.JSONObject

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatMessageBubble(
    message: Message,
    displayText: String,
    translatedText: String?,
    isMine: Boolean,
    myUid: String,
    senderDisplayName: String,
    isGroup: Boolean,
    playbackState: VoicePlaybackState,
    onLongPress: () -> Unit,
    onToggleReaction: (BravReactionType) -> Unit,
    onOpenMedia: (url: String, isVideo: Boolean, title: String) -> Unit,
    onOpenDocument: (Message) -> Unit = {},
    onToggleVoicePlay: () -> Unit,
    onCycleVoiceSpeed: () -> Unit
) {
    val context = LocalContext.current
    val bubbleShape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = if (isMine) 18.dp else 4.dp,
        bottomEnd = if (isMine) 4.dp else 18.dp
    )

    val mineBrush = Brush.linearGradient(listOf(BravPurple, Color(0xFF7B1188)))
    val fgColor = if (isMine) Color.White else MaterialTheme.colorScheme.onSurface

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalAlignment = if (isMine) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 310.dp)
                .clip(bubbleShape)
                .then(
                    if (isMine) Modifier.background(mineBrush)
                    else Modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh)
                )
                .combinedClickable(
                    onClick = {
                        if (message.messageType == "image" || message.messageType == "video") {
                            if (message.mediaUrl.isNotBlank()) {
                                onOpenMedia(
                                    message.mediaUrl,
                                    message.messageType == "video",
                                    message.mediaName
                                )
                            }
                        }
                    },
                    onLongClick = onLongPress
                )
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (isGroup && !isMine) {
                    Text(
                        text = senderDisplayName,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = BravPurple
                    )
                }

                if (message.forwardedFrom.isNotBlank()) {
                    Text(
                        text = "Transféré de ${message.forwardedFrom}",
                        style = MaterialTheme.typography.labelSmall,
                        fontStyle = FontStyle.Italic,
                        color = fgColor.copy(alpha = 0.78f)
                    )
                }

                if (message.replyToPreview.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isMine) Color.White.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceContainerHighest
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.AutoMirrored.Rounded.Reply,
                                contentDescription = null,
                                tint = fgColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = message.replyToPreview,
                                style = MaterialTheme.typography.labelSmall,
                                color = fgColor,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                when {
                    message.deletedForAll -> {
                        Text(
                            text = "Ce message a été supprimé",
                            style = MaterialTheme.typography.bodyMedium,
                            fontStyle = FontStyle.Italic,
                            color = fgColor.copy(alpha = 0.72f)
                        )
                    }
                    message.messageType == "voice" || message.messageType == "audio" -> {
                        VoiceMessageBubble(
                            mediaUrl = message.mediaUrl,
                            durationMs = message.durationMs,
                            waveform = message.waveform,
                            playbackState = playbackState,
                            isMine = isMine,
                            onTogglePlay = onToggleVoicePlay,
                            onCycleSpeed = onCycleVoiceSpeed
                        )
                    }
                    message.messageType == "image" -> {
                        AsyncImage(
                            model = ImageRequest.Builder(context).data(message.mediaUrl).crossfade(true).build(),
                            contentDescription = "Photo partagée",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        if (displayText.isNotBlank()) {
                            Text(displayText, color = fgColor, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    message.messageType == "video" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(170.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black.copy(alpha = 0.75f))
                                .clickable { onOpenMedia(message.mediaUrl, true, message.mediaName) },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Rounded.PlayCircle,
                                contentDescription = "Lire la vidéo",
                                tint = Color.White,
                                modifier = Modifier.size(52.dp)
                            )
                        }
                        if (displayText.isNotBlank()) {
                            Text(displayText, color = fgColor, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    message.messageType == "file" -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    if (message.mediaUrl.isNotBlank()) {
                                        onOpenDocument(message)
                                    }
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Icon(Icons.Rounded.Description, contentDescription = null, tint = fgColor)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = message.mediaName.ifBlank { "Document" },
                                    color = fgColor,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${(message.mediaSize / 1024L).coerceAtLeast(1L)} Ko",
                                    color = fgColor.copy(alpha = 0.75f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                    message.messageType == "location" -> {
                        val loc = remember(message.content) {
                            runCatching { JSONObject(message.content) }.getOrNull()
                        }
                        val lat = loc?.optDouble("lat", 0.0) ?: 0.0
                        val lng = loc?.optDouble("lng", 0.0) ?: 0.0
                        val label = loc?.optString("label", "Position GPS") ?: "Position GPS"
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable {
                                val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng($label)")
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                            }
                        ) {
                            Icon(Icons.Rounded.LocationOn, contentDescription = null, tint = BravRed)
                            Spacer(Modifier.width(6.dp))
                            Column {
                                Text(label, color = fgColor, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "%.5f, %.5f".format(lat, lng),
                                    color = fgColor.copy(alpha = 0.8f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                    message.messageType == "contact" -> {
                        val c = remember(message.content) {
                            runCatching { JSONObject(message.content) }.getOrNull()
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Person, contentDescription = null, tint = fgColor)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(c?.optString("displayName").orEmpty().ifBlank { "Contact BRAV" }, color = fgColor, fontWeight = FontWeight.Bold)
                                Text("@${c?.optString("username").orEmpty()}", color = fgColor.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = displayText,
                            color = fgColor,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }

                if (!translatedText.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isMine) Color.White.copy(alpha = 0.14f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Rounded.Translate, contentDescription = null, tint = fgColor, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(translatedText, style = MaterialTheme.typography.bodySmall, color = fgColor)
                        }
                    }
                }

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (message.pinned) {
                        Icon(Icons.Rounded.PushPin, contentDescription = "Épinglé", tint = fgColor.copy(alpha = 0.75f), modifier = Modifier.size(11.dp))
                    }
                    if (message.isEncrypted) {
                        Icon(Icons.Rounded.Lock, contentDescription = "E2EE", tint = fgColor.copy(alpha = 0.72f), modifier = Modifier.size(11.dp))
                    }
                    if (message.editedAt != null && !message.deletedForAll) {
                        Text("modifié", style = MaterialTheme.typography.labelSmall, color = fgColor.copy(alpha = 0.7f))
                    }
                    val ts = message.timestamp
                    if (ts != null) {
                        Text(
                            text = formatShortTime(ts.seconds),
                            style = MaterialTheme.typography.labelSmall,
                            color = fgColor.copy(alpha = 0.75f)
                        )
                    }
                    if (isMine) {
                        val readIcon = if (message.status == "read" || message.status == "delivered") {
                            Icons.Rounded.DoneAll
                        } else {
                            Icons.Rounded.Done
                        }
                        val tint = if (message.status == "read") Color(0xFF80D8FF) else fgColor.copy(alpha = 0.8f)
                        Icon(readIcon, contentDescription = message.status, tint = tint, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        MessageReactionsRow(
            reactions = message.reactions,
            myUid = myUid,
            onToggleReaction = onToggleReaction
        )
    }
}
