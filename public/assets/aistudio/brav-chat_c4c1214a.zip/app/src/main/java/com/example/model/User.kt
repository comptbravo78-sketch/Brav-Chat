package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class PrivacySettings(
    val showPhoto: String = "everyone",       // everyone | contacts | nobody
    val showStatus: String = "everyone",      // everyone | contacts | nobody
    val showLastSeen: String = "everyone",    // everyone | contacts | nobody
    val whoCanAddToGroup: String = "everyone",
    val whoCanCall: String = "everyone",
    val whoCanRequest: String = "everyone",
    val showInfo: String = "everyone"
)

@IgnoreExtraProperties
data class User(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val username: String = "",
    val phoneLookupHash: String = "",
    val emailLookupHash: String = "",
    val phoneMasked: String = "",
    val bio: String = "Disponible sur BRAV Chat",
    val locationCity: String = "",
    val locationDetails: String = "",
    val avatarUrl: String = "",
    val coverUrl: String = "",
    val availabilityStatus: String = "online", // online | offline | busy | dnd | invisible
    @get:PropertyName("isOnline") @field:PropertyName("isOnline")
    val isOnline: Boolean = false,
    val lastSeenAt: Timestamp? = null,
    val publicKey: String = "",
    val privacySettings: Map<String, String> = mapOf(
        "showPhoto" to "everyone",
        "showStatus" to "everyone",
        "showLastSeen" to "everyone",
        "whoCanAddToGroup" to "everyone",
        "whoCanCall" to "everyone",
        "whoCanRequest" to "everyone",
        "showInfo" to "everyone"
    ),
    val role: String = "user",
    @get:PropertyName("isSuspended") @field:PropertyName("isSuspended")
    val isSuspended: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserPrivateInfo(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val phoneVerified: Boolean = false,
    val securityPinHash: String = "",
    val encryptedBackupJson: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserDevice(
    @DocumentId val id: String = "",
    val deviceId: String = "",
    val deviceName: String = "",
    val platform: String = "android",
    val revoked: Boolean = false,
    @ServerTimestamp val lastActiveAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ContactRequest(
    @DocumentId val id: String = "",
    val fromUid: String = "",
    val fromName: String = "",
    val fromUsername: String = "",
    val toUid: String = "",
    val toName: String = "",
    val status: String = "pending", // pending | accepted | declined
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class BlockedEntry(
    @DocumentId val id: String = "",
    val blockedUid: String = "",
    val reason: String = "",
    @ServerTimestamp val blockedAt: Timestamp? = null
)
