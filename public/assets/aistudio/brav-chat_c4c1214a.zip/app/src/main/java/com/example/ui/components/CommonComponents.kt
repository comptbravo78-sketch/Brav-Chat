package com.example.ui.components

import android.net.Uri
import android.view.ViewGroup
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.launch
import com.example.R
import com.example.media.VoicePlaybackState
import com.example.network.WorkerApiClient
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed
import com.example.ui.theme.StatusBusyAmber
import com.example.ui.theme.StatusDndRed
import com.example.ui.theme.StatusOfflineGray
import com.example.ui.theme.StatusOnlineGreen
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BravLogoMark(
    size: Dp = 44.dp,
    modifier: Modifier = Modifier
) {
    Image(
        painter = painterResource(id = R.drawable.ic_brav_logo),
        contentDescription = "Logo officiel BRAV Chat",
        modifier = modifier.size(size),
        contentScale = ContentScale.Fit
    )
}

@Composable
fun UserAvatarWithStatus(
    name: String,
    avatarUrl: String,
    availabilityStatus: String = "offline",
    isOnlineRealtime: Boolean? = null,
    size: Dp = 48.dp,
    modifier: Modifier = Modifier
) {
    val effectiveStatus = when {
        availabilityStatus == "invisible" -> "invisible"
        availabilityStatus == "dnd" -> "dnd"
        availabilityStatus == "busy" -> "busy"
        isOnlineRealtime == true || availabilityStatus == "online" -> "online"
        else -> "offline"
    }

    val statusColor = when (effectiveStatus) {
        "online" -> StatusOnlineGreen
        "busy" -> StatusBusyAmber
        "dnd" -> StatusDndRed
        else -> StatusOfflineGray
    }

    Box(modifier = modifier.size(size)) {
        if (avatarUrl.isNotBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(avatarUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Photo de $name",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
            )
        } else {
            val initials = name.trim()
                .split(" ")
                .filter { it.isNotBlank() }
                .take(2)
                .joinToString("") { it.first().uppercase() }
                .ifBlank { "B" }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(listOf(BravPurple, BravRed))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initials,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }

        if (effectiveStatus != "invisible") {
            Box(
                modifier = Modifier
                    .size((size.value * 0.28f).dp.coerceAtLeast(10.dp))
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(statusColor)
                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

@Composable
fun VoiceMessageBubble(
    mediaUrl: String,
    durationMs: Long,
    waveform: List<Int>,
    playbackState: VoicePlaybackState,
    isMine: Boolean,
    onTogglePlay: () -> Unit,
    onCycleSpeed: () -> Unit
) {
    val isThisPlaying = playbackState.activeUrl == mediaUrl && playbackState.isPlaying
    val isThisActive = playbackState.activeUrl == mediaUrl
    val totalMs = if (isThisActive && playbackState.durationMs > 0L) playbackState.durationMs else durationMs.coerceAtLeast(1000L)
    val progress = if (isThisActive) (playbackState.positionMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f) else 0f

    val bars = remember(waveform) {
        if (waveform.isNotEmpty()) waveform else List(28) { idx -> 20 + ((idx * 17) % 65) }
    }
    val fg = if (isMine) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
    val activeBarColor = if (isMine) Color.White else MaterialTheme.colorScheme.primary
    val inactiveBarColor = fg.copy(alpha = 0.35f)

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .width(230.dp)
            .padding(vertical = 2.dp)
    ) {
        IconButton(
            onClick = onTogglePlay,
            modifier = Modifier.size(40.dp)
        ) {
            if (isThisActive && playbackState.isBuffering) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = fg, strokeWidth = 2.dp)
            } else {
                Icon(
                    imageVector = if (isThisPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (isThisPlaying) "Pause" else "Lire le vocal",
                    tint = fg
                )
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
            ) {
                val count = bars.size.coerceAtLeast(1)
                val barW = (size.width / count) * 0.6f
                val step = size.width / count
                bars.forEachIndexed { idx, amp ->
                    val frac = idx.toFloat() / count.toFloat()
                    val h = (size.height * (amp / 100f)).coerceAtLeast(4f)
                    val top = (size.height - h) / 2f
                    drawRoundRect(
                        color = if (frac <= progress) activeBarColor else inactiveBarColor,
                        topLeft = Offset(idx * step, top),
                        size = Size(barW, h),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val shownMs = if (isThisActive && playbackState.positionMs > 0) playbackState.positionMs else totalMs
                Text(
                    text = formatDurationMs(shownMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = fg.copy(alpha = 0.85f)
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = fg.copy(alpha = 0.16f),
                    onClick = onCycleSpeed
                ) {
                    Text(
                        text = "${playbackState.speed}x",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = fg,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun MediaLightboxDialog(
    url: String,
    isVideo: Boolean,
    title: String,
    workerApiClient: WorkerApiClient? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (isVideo) {
                    var localVideoFile by remember(url) { mutableStateOf<File?>(null) }
                    var videoError by remember(url) { mutableStateOf<String?>(null) }
                    LaunchedEffect(url) {
                        if (workerApiClient != null) {
                            val res = workerApiClient.downloadMediaToCache(context, url, title.ifBlank { "video.mp4" })
                            res.onSuccess { localVideoFile = it }
                                .onFailure { videoError = it.localizedMessage ?: "Lecture vidéo impossible" }
                        }
                    }

                    val playbackUri = localVideoFile?.let { Uri.fromFile(it) } ?: if (workerApiClient == null) Uri.parse(url) else null
                    if (playbackUri != null) {
                        val exoPlayer = remember(playbackUri) {
                            ExoPlayer.Builder(context).build().apply {
                                setMediaItem(MediaItem.fromUri(playbackUri))
                                prepare()
                                playWhenReady = true
                            }
                        }
                        DisposableEffect(exoPlayer) {
                            onDispose { exoPlayer.release() }
                        }
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = exoPlayer
                                    layoutParams = ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (videoError != null) {
                        Text(
                            text = videoError ?: "Erreur vidéo",
                            color = Color.White,
                            modifier = Modifier.align(Alignment.Center).padding(24.dp)
                        )
                    } else {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(color = Color.White)
                            Text("Chargement vidéo...", color = Color.White.copy(alpha = 0.8f))
                        }
                    }
                } else {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(url).crossfade(true).build(),
                        contentDescription = title,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(horizontal = 12.dp, vertical = 16.dp)
                        .align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = "Fermer", tint = Color.White)
                    }
                    Text(
                        text = title.ifBlank { "Aperçu média" },
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }
}

@Composable
fun ChatLockPromptDialog(
    title: String = "Discussion verrouillée",
    hasPinConfigured: Boolean,
    onVerifyPin: suspend (String) -> Boolean,
    onSuccess: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var pinInput by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    fun launchBiometric() {
        val activity = context as? FragmentActivity ?: return
        val executor = ContextCompat.getMainExecutor(context)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    errorMsg = errString.toString()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("Confirmez votre identité pour déverrouiller")
            .setNegativeButtonText("Utiliser le code PIN")
            .build()
        prompt.authenticate(info)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Lock, contentDescription = null) },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    if (hasPinConfigured) "Saisissez votre code PIN ou utilisez la biométrie."
                    else "Utilisez la biométrie ou configurez un code PIN dans Paramètres."
                )
                if (hasPinConfigured) {
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { pinInput = it.filter { ch -> ch.isDigit() }.take(8) },
                        label = { Text("Code PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                errorMsg?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(
                    onClick = { launchBiometric() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Déverrouiller par empreinte / visage")
                }
            }
        },
        confirmButton = {
            if (hasPinConfigured) {
                var checking by remember { mutableStateOf(false) }
                val scope = androidx.compose.runtime.rememberCoroutineScope()
                Button(
                    enabled = pinInput.length >= 4 && !checking,
                    onClick = {
                        checking = true
                        scope.launch {
                            val ok = onVerifyPin(pinInput)
                            checking = false
                            if (ok) onSuccess() else errorMsg = "Code PIN incorrect"
                        }
                    }
                ) {
                    Text("Valider")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}

fun formatDurationMs(ms: Long): String {
    val sec = (ms / 1000L).coerceAtLeast(0L)
    val m = sec / 60L
    val s = sec % 60L
    return "%d:%02d".format(m, s)
}

private val shortTimeFormatter = object : ThreadLocal<SimpleDateFormat>() {
    override fun initialValue(): SimpleDateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
}

private val dateTimeFormatter = object : ThreadLocal<SimpleDateFormat>() {
    override fun initialValue(): SimpleDateFormat = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
}

fun formatShortTime(epochSeconds: Long): String =
    shortTimeFormatter.get()?.format(Date(epochSeconds * 1000L)).orEmpty()

fun formatShortDateTime(epochSeconds: Long): String =
    dateTimeFormatter.get()?.format(Date(epochSeconds * 1000L)).orEmpty()
