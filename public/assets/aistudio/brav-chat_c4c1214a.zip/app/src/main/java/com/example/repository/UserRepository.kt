package com.example.repository

import android.content.Context
import android.os.Build
import com.example.R
import com.example.crypto.E2eeCryptoManager
import com.example.model.BlockedEntry
import com.example.model.User
import com.example.model.UserDevice
import com.example.model.UserPrivateInfo
import com.example.network.WorkerApiClient
import com.example.util.OperationType
import com.example.util.PhoneUtils
import com.example.util.handleFirestoreError
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.util.UUID

class UserRepository(
    private val db: FirebaseFirestore,
    private val cryptoManager: E2eeCryptoManager? = null,
    private val workerApiClient: WorkerApiClient? = null
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        cryptoManager = E2eeCryptoManager(context.applicationContext)
    )

    suspend fun ensureUserProfileExists(
        firebaseUser: FirebaseUser,
        deviceId: String? = null
    ): Result<User> {
        val uid = firebaseUser.uid
        val userRef = db.collection("users").document(uid)
        val privateRef = userRef.collection("private").document("info")
        val pubKey = cryptoManager?.getPublicKeyBase64(uid).orEmpty()

        return try {
            val snap = userRef.get().await()
            val email = firebaseUser.email.orEmpty()
            val phone = firebaseUser.phoneNumber.orEmpty()
            val displayName = firebaseUser.displayName?.takeIf { it.isNotBlank() }
                ?: email.substringBefore("@").takeIf { it.isNotBlank() }
                ?: "Membre BRAV"

            val existing = snap.toObject(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            if (!snap.exists() || existing == null) {
                val baseUsername = sanitizeUsername(displayName) + "_" + uid.take(4).lowercase()
                val newUserMap = hashMapOf<String, Any>(
                    "userId" to uid,
                    "displayName" to displayName.take(100),
                    "username" to baseUsername.take(40),
                    "phoneLookupHash" to if (phone.isNotBlank()) PhoneUtils.sha256LookupHash(PhoneUtils.normalize(phone)) else "",
                    "emailLookupHash" to if (email.isNotBlank()) PhoneUtils.sha256LookupHash(email) else "",
                    "phoneMasked" to if (phone.isNotBlank()) PhoneUtils.maskPhone(phone) else "",
                    "bio" to "Disponible sur BRAV Chat",
                    "locationCity" to "",
                    "locationDetails" to "",
                    "avatarUrl" to (firebaseUser.photoUrl?.toString().orEmpty()),
                    "coverUrl" to "",
                    "availabilityStatus" to "online",
                    "isOnline" to true,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "publicKey" to pubKey,
                    "privacySettings" to mapOf(
                        "showPhoto" to "everyone",
                        "showStatus" to "everyone",
                        "showLastSeen" to "everyone",
                        "whoCanAddToGroup" to "everyone",
                        "whoCanCall" to "everyone",
                        "whoCanRequest" to "everyone",
                        "showInfo" to "everyone"
                    ),
                    "role" to "user",
                    "isSuspended" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                userRef.set(newUserMap).await()
            } else {
                val updates = mutableMapOf<String, Any>(
                    "isOnline" to (existing.availabilityStatus != "invisible" && existing.availabilityStatus != "offline"),
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (pubKey.isNotBlank() && existing.publicKey != pubKey) {
                    updates["publicKey"] = pubKey
                }
                if (existing.emailLookupHash.isBlank() && email.isNotBlank()) {
                    updates["emailLookupHash"] = PhoneUtils.sha256LookupHash(email)
                }
                if (existing.avatarUrl.isBlank() && firebaseUser.photoUrl != null) {
                    updates["avatarUrl"] = firebaseUser.photoUrl.toString()
                }
                userRef.update(updates).await()
            }

            // Ensure private PII doc exists for owner only
            val privateSnap = privateRef.get().await()
            if (!privateSnap.exists()) {
                val privMap = hashMapOf<String, Any>(
                    "userId" to uid,
                    "email" to email,
                    "phoneNumber" to phone,
                    "phoneVerified" to phone.isNotBlank(),
                    "securityPinHash" to "",
                    "encryptedBackupJson" to "",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                privateRef.set(privMap).await()
            }

            if (!deviceId.isNullOrBlank()) {
                registerDeviceSession(uid, deviceId)
            }

            val updatedSnap = userRef.get().await()
            val finalUser = updatedSnap.toObject(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: User(id = uid, userId = uid, displayName = displayName)
            Result.success(finalUser)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userRef.path)
            Result.failure(e)
        }
    }

    fun observeUser(uid: String): Flow<User?> {
        return db.collection("users").document(uid).snapshots().map { snap ->
            snap.toObject(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        }
    }

    fun observePrivateInfo(uid: String): Flow<UserPrivateInfo?> {
        return db.collection("users").document(uid)
            .collection("private").document("info")
            .snapshots()
            .map { snap ->
                snap.toObject(UserPrivateInfo::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
    }

    fun observeDevices(uid: String): Flow<List<UserDevice>> {
        return db.collection("users").document(uid)
            .collection("devices")
            .snapshots()
            .map { snap ->
                snap.toObjects(UserDevice::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.lastActiveAt ?: Timestamp(0, 0) }
            }
    }

    fun observeBlockedUsers(uid: String): Flow<List<BlockedEntry>> {
        return db.collection("users").document(uid)
            .collection("blocked")
            .snapshots()
            .map { snap ->
                snap.toObjects(BlockedEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
    }

    suspend fun getUserById(uid: String): User? {
        return try {
            db.collection("users").document(uid).get().await()
                .toObject(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "users/$uid")
            null
        }
    }

    suspend fun isUsernameAvailable(username: String, excludeUid: String): Boolean {
        val clean = sanitizeUsername(username)
        if (clean.length < 3) return false
        return try {
            val snap = db.collection("users")
                .whereEqualTo("username", clean)
                .limit(2)
                .get()
                .await()
            snap.documents.none { it.id != excludeUid }
        } catch (_: Exception) {
            true
        }
    }

    data class ProfileValidationResult(
        val isValid: Boolean,
        val fieldErrors: Map<String, String> = emptyMap()
    )

    fun validateProfileInput(
        displayName: String,
        username: String,
        bio: String,
        phoneNumber: String,
        email: String
    ): ProfileValidationResult {
        val errors = mutableMapOf<String, String>()
        val cleanName = displayName.trim()
        if (cleanName.length < 2) {
            errors["displayName"] = "Entrez au moins 2 caractères pour votre nom complet."
        } else if (cleanName.length > 100) {
            errors["displayName"] = "Le nom complet ne doit pas dépasser 100 caractères."
        }

        val cleanUser = sanitizeUsername(username)
        if (username.isNotBlank() && cleanUser.length < 3) {
            errors["username"] = "Le nom d'utilisateur doit contenir au moins 3 caractères."
        }

        if (bio.trim().length > 300) {
            errors["bio"] = "La biographie est limitée à 300 caractères."
        }

        val trimmedEmail = email.trim()
        if (trimmedEmail.isNotBlank() && !Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$").matches(trimmedEmail)) {
            errors["email"] = "Adresse e-mail invalide."
        }

        val trimmedPhone = phoneNumber.trim()
        if (trimmedPhone.isNotBlank()) {
            val digits = trimmedPhone.filter { it.isDigit() }
            if (digits.length < 7 || digits.length > 15) {
                errors["phone"] = "Numéro de téléphone invalide (7 à 15 chiffres attendus)."
            }
        }
        return ProfileValidationResult(isValid = errors.isEmpty(), fieldErrors = errors)
    }

    suspend fun updateProfile(
        uid: String,
        displayName: String,
        username: String,
        bio: String,
        locationCity: String,
        locationDetails: String,
        avatarUrl: String? = null,
        coverUrl: String? = null,
        phoneNumber: String? = null,
        email: String? = null
    ): Result<Unit> {
        val userRef = db.collection("users").document(uid)
        val privateRef = userRef.collection("private").document("info")
        return try {
            val validation = validateProfileInput(
                displayName = displayName,
                username = username,
                bio = bio,
                phoneNumber = phoneNumber.orEmpty(),
                email = email.orEmpty()
            )
            if (!validation.isValid) {
                val firstMsg = validation.fieldErrors.values.firstOrNull() ?: "Champs invalides."
                return Result.failure(IllegalArgumentException(firstMsg))
            }

            val cleanUsername = sanitizeUsername(username)
            if (cleanUsername.isNotBlank() && !isUsernameAvailable(cleanUsername, uid)) {
                return Result.failure(IllegalArgumentException("Ce nom d'utilisateur @$cleanUsername est déjà pris."))
            }

            // Preserve existing avatarUrl in D1 sync when caller did not explicitly supply a new avatarUrl
            val resolvedAvatarForSync = avatarUrl ?: runCatching {
                userRef.get().await().getString("avatarUrl").orEmpty()
            }.getOrDefault("")

            val updates = mutableMapOf<String, Any>(
                "displayName" to displayName.trim().take(100),
                "username" to cleanUsername.take(40),
                "bio" to bio.trim().take(300),
                "locationCity" to locationCity.trim().take(120),
                "locationDetails" to locationDetails.trim().take(200),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            avatarUrl?.let { updates["avatarUrl"] = it }
            coverUrl?.let { updates["coverUrl"] = it }

            val privUpdates = mutableMapOf<String, Any>(
                "userId" to uid,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (phoneNumber != null) {
                val norm = PhoneUtils.normalize(phoneNumber)
                updates["phoneLookupHash"] = if (norm.isNotBlank()) PhoneUtils.sha256LookupHash(norm) else ""
                updates["phoneMasked"] = if (norm.isNotBlank()) PhoneUtils.maskPhone(norm) else ""
                privUpdates["phoneNumber"] = norm
            }
            if (email != null) {
                val trimmedEmail = email.trim()
                updates["emailLookupHash"] = if (trimmedEmail.isNotBlank()) PhoneUtils.sha256LookupHash(trimmedEmail) else ""
                privUpdates["email"] = trimmedEmail
            }

            userRef.update(updates).await()
            if (phoneNumber != null || email != null) {
                privateRef.set(privUpdates, com.google.firebase.firestore.SetOptions.merge()).await()
            }
            workerApiClient?.syncUserDirectoryToD1(
                userId = uid,
                displayName = displayName.trim().take(100),
                username = cleanUsername.take(40),
                city = locationCity.trim().take(120),
                avatarUrl = resolvedAvatarForSync
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path)
            Result.failure(e)
        }
    }

    suspend fun removeProfilePhoto(uid: String): Result<Unit> {
        val userRef = db.collection("users").document(uid)
        return try {
            val snap = userRef.get().await()
            userRef.update(
                mapOf(
                    "avatarUrl" to "",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            workerApiClient?.syncUserDirectoryToD1(
                userId = uid,
                displayName = snap.getString("displayName").orEmpty(),
                username = snap.getString("username").orEmpty(),
                city = snap.getString("locationCity").orEmpty(),
                avatarUrl = ""
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateAvailabilityStatus(uid: String, status: String): Result<Unit> {
        val valid = status in setOf("online", "offline", "busy", "dnd", "invisible")
        if (!valid) return Result.failure(IllegalArgumentException("Statut invalide"))
        val userRef = db.collection("users").document(uid)
        return try {
            userRef.update(
                mapOf(
                    "availabilityStatus" to status,
                    "isOnline" to (status == "online" || status == "busy"),
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path)
            Result.failure(e)
        }
    }

    suspend fun updatePrivacySettings(uid: String, settings: Map<String, String>): Result<Unit> {
        val userRef = db.collection("users").document(uid)
        return try {
            userRef.update(
                mapOf(
                    "privacySettings" to settings,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path)
            Result.failure(e)
        }
    }

    suspend fun registerDeviceSession(uid: String, deviceId: String): Result<Unit> {
        val cleanDeviceId = deviceId.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(120)
        val devRef = db.collection("users").document(uid).collection("devices").document(cleanDeviceId)
        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}".take(100)
        return try {
            val snap = devRef.get().await()
            val payload = hashMapOf<String, Any>(
                "deviceId" to cleanDeviceId,
                "deviceName" to deviceName,
                "platform" to "android",
                "revoked" to false,
                "lastActiveAt" to FieldValue.serverTimestamp()
            )
            if (!snap.exists()) {
                payload["createdAt"] = FieldValue.serverTimestamp()
            }
            devRef.set(payload, com.google.firebase.firestore.SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, devRef.path)
            Result.failure(e)
        }
    }

    suspend fun revokeDeviceSession(uid: String, deviceId: String): Result<Unit> {
        val devRef = db.collection("users").document(uid).collection("devices").document(deviceId)
        return try {
            devRef.update(
                mapOf(
                    "revoked" to true,
                    "lastActiveAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, devRef.path)
            Result.failure(e)
        }
    }

    suspend fun blockUser(uid: String, targetUid: String, reason: String = ""): Result<Unit> {
        val blockRef = db.collection("users").document(uid).collection("blocked").document(targetUid)
        return try {
            blockRef.set(
                mapOf(
                    "blockedUid" to targetUid,
                    "reason" to reason.take(300),
                    "blockedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, blockRef.path)
            Result.failure(e)
        }
    }

    suspend fun unblockUser(uid: String, targetUid: String): Result<Unit> {
        val blockRef = db.collection("users").document(uid).collection("blocked").document(targetUid)
        return try {
            blockRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, blockRef.path)
            Result.failure(e)
        }
    }

    suspend fun exportEncryptedBackup(uid: String): Result<String> {
        return try {
            val userSnap = db.collection("users").document(uid).get().await()
            val contactsSnap = db.collection("users").document(uid).collection("contacts").get().await()
            val privSnap = db.collection("users").document(uid).collection("private").document("info").get().await()
            val backupJson = JSONObject().apply {
                put("version", 1)
                put("exportedAtMs", System.currentTimeMillis())
                put("userId", uid)
                put("displayName", userSnap.getString("displayName").orEmpty())
                put("username", userSnap.getString("username").orEmpty())
                put("bio", userSnap.getString("bio").orEmpty())
                put("contactsCount", contactsSnap.size())
                put("phoneNumber", privSnap.getString("phoneNumber").orEmpty())
            }.toString()

            val crypto = cryptoManager ?: return Result.success(backupJson)
            val myPub = crypto.getPublicKeyBase64(uid)
            val encrypted = crypto.encryptForPeer(uid, myPub, "backup_$uid", backupJson)
            val envelope = JSONObject().apply {
                put("ciphertext", encrypted.ciphertextBase64)
                put("iv", encrypted.ivBase64)
                put("senderPublicKey", encrypted.senderPublicKeyBase64)
            }.toString()

            db.collection("users").document(uid)
                .collection("private").document("info")
                .set(
                    mapOf(
                        "userId" to uid,
                        "encryptedBackupJson" to envelope.take(450_000),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    com.google.firebase.firestore.SetOptions.merge()
                ).await()
            Result.success(envelope)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreEncryptedBackup(uid: String): Result<String> {
        return try {
            val privSnap = db.collection("users").document(uid).collection("private").document("info").get().await()
            val envelopeStr = privSnap.getString("encryptedBackupJson").orEmpty()
            if (envelopeStr.isBlank()) return Result.failure(IllegalStateException("Aucune sauvegarde chiffrée trouvée."))
            val obj = JSONObject(envelopeStr)
            val ciphertext = obj.getString("ciphertext")
            val iv = obj.getString("iv")
            val senderPub = obj.getString("senderPublicKey")
            val crypto = cryptoManager ?: return Result.failure(IllegalStateException("Crypto indisponible"))
            val plain = crypto.decryptFromPeer(uid, senderPub, "backup_$uid", ciphertext, iv)
                ?: return Result.failure(IllegalStateException("Impossible de déchiffrer la sauvegarde sur cet appareil."))
            val restored = JSONObject(plain)
            val bio = restored.optString("bio")
            if (bio.isNotBlank()) {
                db.collection("users").document(uid).update(
                    mapOf("bio" to bio, "updatedAt" to FieldValue.serverTimestamp())
                ).await()
            }
            Result.success(plain)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun checkIsAdmin(uid: String, email: String?): Boolean {
        if (!email.isNullOrBlank() && email.lowercase() in setOf("comptbravo78@gmail.com", "admin@bravchat.ci")) {
            return true
        }
        return runCatching {
            db.collection("admins").document(uid).get().await().exists()
        }.getOrDefault(false)
    }

    suspend fun deleteAccountData(uid: String): Result<Unit> {
        val userRef = db.collection("users").document(uid)
        return try {
            userRef.collection("private").document("info").delete().await()
            userRef.collection("devices").get().await().documents.forEach { it.reference.delete().await() }
            userRef.collection("contacts").get().await().documents.forEach { it.reference.delete().await() }
            userRef.collection("blocked").get().await().documents.forEach { it.reference.delete().await() }
            userRef.collection("conversation_prefs").get().await().documents.forEach { it.reference.delete().await() }
            userRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, userRef.path)
            Result.failure(e)
        }
    }

    suspend fun logTelemetry(uid: String, category: String, message: String) {
        val id = "log_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        runCatching {
            db.collection("system_telemetry").document(id).set(
                mapOf(
                    "userId" to uid,
                    "category" to category.take(64),
                    "message" to message.take(1000),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    fun sanitizeUsername(input: String): String {
        return input.trim()
            .removePrefix("@")
            .lowercase()
            .replace(Regex("[^a-z0-9._-]"), "")
            .take(36)
    }
}
