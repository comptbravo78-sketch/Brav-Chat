package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CallMade
import androidx.compose.material.icons.automirrored.rounded.CallMissed
import androidx.compose.material.icons.automirrored.rounded.CallReceived
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import com.example.model.Call
import com.example.model.User
import com.example.ui.components.UserAvatarWithStatus
import com.example.ui.components.formatShortDateTime
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed
import com.example.ui.theme.CallActionGreen
import com.example.ui.theme.EndCallRed
import com.example.ui.theme.StatusOnlineGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

internal val CallLightBg = Color(0xFFF8F9FC)
internal val CallLightCard = Color(0xFFFFFFFF)
internal val CallLightBorder = Color(0xFFE2E8F0)
internal val CallSlateText = Color(0xFF0F172A)
internal val CallMutedText = Color(0xFF475569)

@Composable
fun CallHistoryScreen(
    currentUserId: String,
    calls: List<Call>,
    savedContacts: List<User> = emptyList(),
    onStartAudioCall: (peerUid: String, peerName: String) -> Unit,
    onStartVideoCall: (peerUid: String, peerName: String) -> Unit,
    onOpenDialer: () -> Unit = {},
    onDeleteCall: (callId: String) -> Unit = {},
    onClearHistory: () -> Unit = {}
) {
    val context = LocalContext.current
    var pendingCallRequest by remember { mutableStateOf<Triple<String, String, Boolean>?>(null) }
    var showClearDialog by remember { mutableStateOf(false) }

    val callPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val req = pendingCallRequest ?: return@rememberLauncherForActivityResult
        pendingCallRequest = null
        val micOk = grants[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) {
            if (req.third) onStartVideoCall(req.first, req.second)
            else onStartAudioCall(req.first, req.second)
        }
    }

    fun launchCall(peerUid: String, peerName: String, isVideo: Boolean) {
        if (peerUid.isBlank()) return
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (isVideo && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA)
        }
        if (needed.isEmpty()) {
            if (isVideo) onStartVideoCall(peerUid, peerName) else onStartAudioCall(peerUid, peerName)
        } else {
            pendingCallRequest = Triple(peerUid, peerName, isVideo)
            callPermLauncher.launch(needed.toTypedArray())
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenDialer,
                containerColor = BravPurple,
                contentColor = Color.White,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("calls_open_dialer_fab")
            ) {
                Icon(Icons.Rounded.Dialpad, contentDescription = "Ouvrir le clavier")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Appels", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                if (calls.isNotEmpty()) {
                    TextButton(
                        onClick = { showClearDialog = true },
                        modifier = Modifier.testTag("clear_call_history_button")
                    ) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = "Tout effacer", tint = BravRed, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Tout effacer", color = BravRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            DefaultDialerActionCard()
            Spacer(Modifier.height(12.dp))

            if (savedContacts.isNotEmpty()) {
                Text("Appel rapide", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(savedContacts, key = { it.userId }) { contact ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        tonalElevation = 1.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatarWithStatus(
                                name = contact.displayName,
                                avatarUrl = contact.avatarUrl,
                                availabilityStatus = contact.availabilityStatus,
                                size = 38.dp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = contact.displayName,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            IconButton(
                                onClick = { launchCall(contact.userId, contact.displayName, false) },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.Rounded.Call, contentDescription = "Appel audio", tint = BravPurple, modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { launchCall(contact.userId, contact.displayName, true) },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.Rounded.Videocam, contentDescription = "Appel vidéo", tint = BravRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        if (calls.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.Call, contentDescription = null, tint = BravPurple.copy(alpha = 0.5f), modifier = Modifier.size(44.dp))
                    Text("Aucun appel enregistré.", fontWeight = FontWeight.SemiBold)
                    Text("Démarrez un appel depuis vos contacts ou une discussion.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(calls, key = { it.id }) { call ->
                    val isOutgoing = call.callerId == currentUserId
                    val peerUid = if (isOutgoing) call.receiverId else call.callerId
                    val contactMatch = savedContacts.firstOrNull { it.userId == peerUid }
                    val peerName = contactMatch?.displayName?.ifBlank { null }
                        ?: (if (isOutgoing) call.receiverName else call.callerName).ifBlank { "Membre BRAV" }
                    val peerAvatar = contactMatch?.avatarUrl?.ifBlank { null }
                        ?: (if (isOutgoing) call.receiverAvatar else call.callerAvatar)

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatarWithStatus(
                                name = peerName,
                                avatarUrl = peerAvatar,
                                availabilityStatus = contactMatch?.availabilityStatus ?: "offline",
                                size = 44.dp
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(peerName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val ts = call.createdAt?.let { formatShortDateTime(it.seconds) } ?: ""
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(
                                        imageVector = when {
                                            call.missed -> Icons.AutoMirrored.Rounded.CallMissed
                                            isOutgoing -> Icons.AutoMirrored.Rounded.CallMade
                                            else -> Icons.AutoMirrored.Rounded.CallReceived
                                        },
                                        contentDescription = null,
                                        tint = if (call.missed) BravRed else StatusOnlineGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "${if (call.callType == "video") "Vidéo" else "Audio"} • ${if (call.missed) "Manqué" else "${call.durationSeconds}s"} • $ts",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton(onClick = { launchCall(peerUid, peerName, false) }) {
                                Icon(Icons.Rounded.Call, contentDescription = "Rappeler en audio", tint = BravPurple)
                            }
                            IconButton(onClick = { launchCall(peerUid, peerName, true) }) {
                                Icon(Icons.Rounded.Videocam, contentDescription = "Rappeler en vidéo", tint = BravRed)
                            }
                            IconButton(
                                onClick = { onDeleteCall(call.id) },
                                modifier = Modifier.testTag("delete_call_${call.id}")
                            ) {
                                Icon(
                                    Icons.Rounded.DeleteOutline,
                                    contentDescription = "Supprimer cet appel de l'historique",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            icon = { Icon(Icons.Rounded.DeleteSweep, contentDescription = null, tint = BravRed) },
            title = { Text("Effacer l'historique ?") },
            text = { Text("Tous les appels affichés seront retirés de votre journal sur cet appareil et votre compte.") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = BravRed, contentColor = Color.White),
                    onClick = {
                        showClearDialog = false
                        onClearHistory()
                    }
                ) { Text("Tout effacer") }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
fun IncomingCallBannerDialog(
    call: Call,
    peerUser: User? = null,
    soundEnabled: Boolean = true,
    vibrationEnabled: Boolean = true,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    val context = LocalContext.current
    val verifiedPeer = peerUser?.takeIf { it.userId == call.callerId }
    val callerName = verifiedPeer?.displayName?.ifBlank { null } ?: call.callerName.ifBlank { "Membre BRAV" }
    val callerAvatar = verifiedPeer?.avatarUrl?.ifBlank { null } ?: call.callerAvatar
    val callerUsername = verifiedPeer?.username?.ifBlank { null } ?: call.callerUsername
    val callerSubtitle = if (callerUsername.isNotBlank()) "@$callerUsername"
    else if (call.callerId.isNotBlank()) "ID : ${call.callerId.take(8)}..." else "Appel BRAV CHAT"

    LaunchedEffect(call.id, soundEnabled, vibrationEnabled) {
        val ringtone = if (soundEnabled) {
            runCatching {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                RingtoneManager.getRingtone(context, uri)?.apply {
                    audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) isLooping = true
                    play()
                }
            }.getOrNull()
        } else null

        val fallbackTone = if (soundEnabled && ringtone == null) {
            runCatching { ToneGenerator(AudioManager.STREAM_RING, 85) }.getOrNull()
        } else null

        val vibrator = if (vibrationEnabled) {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                }
            }.getOrNull()
        } else null

        if (vibrator != null) {
            runCatching {
                val pattern = longArrayOf(0L, 650L, 850L)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(pattern, 0)
                }
            }
        }

        try {
            while (isActive) {
                if (soundEnabled) {
                    if (ringtone != null && !ringtone.isPlaying) runCatching { ringtone.play() }
                    else if (ringtone == null) runCatching { fallbackTone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900) }
                }
                delay(1500L)
            }
        } finally {
            runCatching { ringtone?.stop() }
            runCatching { fallbackTone?.stopTone() }
            runCatching { fallbackTone?.release() }
            runCatching { vibrator?.cancel() }
        }
    }

    var micPermDeniedNotice by remember { mutableStateOf(false) }
    val acceptPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val micGranted = grants[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micGranted) {
            micPermDeniedNotice = false
            onAccept()
        } else {
            micPermDeniedNotice = true
        }
    }

    Surface(modifier = Modifier.fillMaxSize().zIndex(100f), color = CallLightBg) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CallLightBg)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 28.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = CallLightCard,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .border(1.dp, CallLightBorder, RoundedCornerShape(999.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        if (call.callType == "video") Icons.Rounded.Videocam else Icons.Rounded.Call,
                        contentDescription = null,
                        tint = BravPurple,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (call.callType == "video") "Appel vidéo entrant" else "Appel audio entrant",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = CallSlateText
                    )
                }
            }

            Column(
                modifier = Modifier.align(Alignment.Center).padding(bottom = 64.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CallPeerPhotoAvatar(
                    name = callerName,
                    avatarUrl = callerAvatar,
                    size = 148.dp,
                    ringAnimated = true,
                    isLightSurface = true
                )
                Spacer(Modifier.height(24.dp))
                Text(
                    text = callerName,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = CallSlateText,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = callerSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = CallMutedText,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = StatusOnlineGreen, modifier = Modifier.size(14.dp))
                    Text(
                        text = "BRAV Chat • Chiffrement de bout en bout",
                        style = MaterialTheme.typography.labelMedium,
                        color = CallMutedText
                    )
                }
            }

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .widthIn(max = 420.dp)
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = CircleShape,
                        color = EndCallRed,
                        shadowElevation = 4.dp,
                        onClick = onReject,
                        modifier = Modifier.size(72.dp).testTag("reject_call_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.CallEnd, contentDescription = "Refuser l'appel", tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Refuser", color = CallSlateText, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (micPermDeniedNotice) {
                        Text(
                            text = "Autorisez le micro pour répondre",
                            color = EndCallRed,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                    Surface(
                        shape = CircleShape,
                        color = CallActionGreen,
                        shadowElevation = 4.dp,
                        onClick = {
                            val needed = mutableListOf<String>()
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                needed.add(Manifest.permission.RECORD_AUDIO)
                            }
                            if (call.callType == "video" && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                needed.add(Manifest.permission.CAMERA)
                            }
                            if (needed.isEmpty()) onAccept() else acceptPermLauncher.launch(needed.toTypedArray())
                        },
                        modifier = Modifier.size(72.dp).testTag("accept_call_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                if (call.callType == "video") Icons.Rounded.Videocam else Icons.Rounded.Call,
                                contentDescription = "Répondre à l'appel",
                                tint = Color.White,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Répondre", color = CallSlateText, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun CallTerminalOverlay(
    call: Call,
    reason: String,
    currentUserId: String,
    peerUser: User? = null,
    onDismiss: () -> Unit
) {
    val isCaller = call.callerId == currentUserId
    val peerUid = if (isCaller) call.receiverId else call.callerId
    val verifiedPeer = peerUser?.takeIf { it.userId == peerUid }
    val peerName = verifiedPeer?.displayName?.ifBlank { null }
        ?: (if (isCaller) call.receiverName else call.callerName).ifBlank { "Membre BRAV" }
    val peerAvatar = verifiedPeer?.avatarUrl?.ifBlank { null }
        ?: (if (isCaller) call.receiverAvatar else call.callerAvatar)

    Surface(
        modifier = Modifier.fillMaxSize().zIndex(102f).clickable(onClick = onDismiss),
        color = CallLightBg
    ) {
        Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CallPeerPhotoAvatar(
                    name = peerName,
                    avatarUrl = peerAvatar,
                    size = 112.dp,
                    ringAnimated = false,
                    isLightSurface = true
                )
                Text(peerName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = CallSlateText)
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = EndCallRed.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = reason,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = EndCallRed,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}
