package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.Conversation
import com.example.model.ConversationPref
import com.example.model.User
import com.example.network.PresenceStatus
import com.example.ui.components.ChatLockPromptDialog
import com.example.ui.components.UserAvatarWithStatus
import com.example.ui.components.formatShortTime
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed

private enum class HomeChatFilter(val label: String) {
    ALL("Toutes"),
    UNREAD("Non lues"),
    GROUPS("Groupes"),
    ARCHIVED("Archivées"),
    LOCKED("Verrouillées")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun HomeDashboardScreen(
    currentUserId: String,
    conversations: List<Conversation>,
    prefsMap: Map<String, ConversationPref>,
    presenceMap: Map<String, PresenceStatus>,
    typingConversations: Map<String, Set<String>>,
    savedContacts: List<User>,
    hasPinConfigured: Boolean,
    isAdmin: Boolean,
    compactLayout: Boolean = false,
    onVerifyPin: suspend (String) -> Boolean,
    onOpenConversation: (String) -> Unit,
    onCreateGroup: (List<User>, String, String) -> Unit,
    onJoinGroupByCode: (String) -> Unit,
    onUpdatePref: (String, Boolean?, Boolean?, Boolean?, Boolean?, Boolean?, Boolean?) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onNavigateToContacts: () -> Unit,
    onOpenStatuses: () -> Unit,
    onOpenDialer: () -> Unit,
    onRequestDefaultDialer: () -> Unit,
    onOpenMap: () -> Unit,
    onOpenOffers: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAdmin: () -> Unit
) {
    var filter by remember { mutableStateOf(HomeChatFilter.ALL) }
    var searchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var overflowExpanded by remember { mutableStateOf(false) }
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var showJoinGroupDialog by remember { mutableStateOf(false) }
    var actionTargetConv by remember { mutableStateOf<Conversation?>(null) }
    var deleteConfirmConv by remember { mutableStateOf<Conversation?>(null) }
    var lockedConvToOpen by remember { mutableStateOf<String?>(null) }

    val filtered = remember(conversations, prefsMap, filter, searchQuery, currentUserId) {
        conversations
            .filter { conv ->
                val pref = prefsMap[conv.id]
                if (pref?.hiddenLocally == true) return@filter false
                when (filter) {
                    HomeChatFilter.ALL -> pref?.archived != true && pref?.locked != true
                    HomeChatFilter.UNREAD -> pref?.markedUnread == true
                    HomeChatFilter.GROUPS -> conv.isGroup && pref?.archived != true
                    HomeChatFilter.ARCHIVED -> pref?.archived == true
                    HomeChatFilter.LOCKED -> pref?.locked == true
                }
            }
            .filter { conv ->
                if (searchQuery.isBlank()) return@filter true
                val title = resolveConversationTitle(conv, currentUserId)
                title.contains(searchQuery, ignoreCase = true) ||
                    conv.lastMessage.contains(searchQuery, ignoreCase = true)
            }
            .sortedWith(
                compareByDescending<Conversation> { prefsMap[it.id]?.pinned == true }
                    .thenByDescending { it.lastMessageTimestamp?.seconds ?: it.updatedAt?.seconds ?: 0L }
            )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                title = {
                    Text(
                        text = "BRAV Chat",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = BravPurple,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                actions = {
                    IconButton(
                        onClick = onOpenStatuses,
                        modifier = Modifier.testTag("home_camera_button")
                    ) {
                        Icon(Icons.Rounded.PhotoCamera, contentDescription = "Statuts")
                    }
                    IconButton(
                        onClick = onOpenDialer,
                        modifier = Modifier.testTag("home_dialer_button")
                    ) {
                        Icon(Icons.Rounded.Dialpad, contentDescription = "Clavier d'appel")
                    }
                    IconButton(
                        onClick = {
                            searchVisible = !searchVisible
                            if (!searchVisible) searchQuery = ""
                        },
                        modifier = Modifier.testTag("home_search_button")
                    ) {
                        Icon(
                            if (searchVisible) Icons.Rounded.Close else Icons.Rounded.Search,
                            contentDescription = "Rechercher"
                        )
                    }
                    Box {
                        IconButton(
                            onClick = { overflowExpanded = true },
                            modifier = Modifier.testTag("home_overflow_menu_button")
                        ) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "Menu")
                        }
                        DropdownMenu(
                            expanded = overflowExpanded,
                            onDismissRequest = { overflowExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Nouveau groupe") },
                                leadingIcon = { Icon(Icons.Rounded.GroupAdd, contentDescription = null) },
                                onClick = {
                                    overflowExpanded = false
                                    showCreateGroupDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Rejoindre par code") },
                                leadingIcon = { Icon(Icons.Rounded.Group, contentDescription = null) },
                                onClick = {
                                    overflowExpanded = false
                                    showJoinGroupDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Compositeur par défaut") },
                                leadingIcon = { Icon(Icons.Rounded.PhoneAndroid, contentDescription = null) },
                                onClick = {
                                    overflowExpanded = false
                                    onRequestDefaultDialer()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Carte en direct") },
                                leadingIcon = { Icon(Icons.Rounded.Map, contentDescription = null) },
                                onClick = {
                                    overflowExpanded = false
                                    onOpenMap()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Annonces & Offres") },
                                leadingIcon = { Icon(Icons.Rounded.Storefront, contentDescription = null) },
                                onClick = {
                                    overflowExpanded = false
                                    onOpenOffers()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Mon profil") },
                                leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null) },
                                onClick = {
                                    overflowExpanded = false
                                    onOpenProfile()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Paramètres") },
                                leadingIcon = { Icon(Icons.Rounded.Settings, contentDescription = null) },
                                onClick = {
                                    overflowExpanded = false
                                    onOpenSettings()
                                }
                            )
                            if (isAdmin) {
                                DropdownMenuItem(
                                    text = { Text("Administration") },
                                    leadingIcon = { Icon(Icons.Rounded.AdminPanelSettings, contentDescription = null, tint = BravRed) },
                                    onClick = {
                                        overflowExpanded = false
                                        onOpenAdmin()
                                    }
                                )
                            }
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToContacts,
                containerColor = BravPurple,
                contentColor = Color.White,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("home_new_chat_fab")
            ) {
                Icon(Icons.Rounded.AddComment, contentDescription = "Nouvelle discussion")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            AnimatedVisibility(visible = searchVisible) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Effacer")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("home_search_input")
                )
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(HomeChatFilter.entries) { item ->
                    val selected = filter == item
                    FilterChip(
                        selected = selected,
                        onClick = { filter = item },
                        label = {
                            Text(
                                item.label,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        },
                        shape = RoundedCornerShape(999.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BravPurple.copy(alpha = 0.14f),
                            selectedLabelColor = BravPurple
                        ),
                        modifier = Modifier.testTag("home_filter_${item.name.lowercase()}")
                    )
                }
            }

            if (filtered.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BravPurple.copy(alpha = 0.1f),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Rounded.ChatBubbleOutline,
                                    contentDescription = null,
                                    tint = BravPurple,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                        }
                        Text(
                            text = if (searchQuery.isNotBlank()) "Aucun résultat" else "Aucune discussion",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Button(
                            onClick = onNavigateToContacts,
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text("Nouvelle discussion")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 88.dp)
                ) {
                    items(filtered, key = { it.id }) { conv ->
                        val pref = prefsMap[conv.id]
                        val peerUid = if (!conv.isGroup) conv.participants.firstOrNull { it != currentUserId }.orEmpty() else ""
                        val title = resolveConversationTitle(conv, currentUserId)
                        val avatar = if (conv.isGroup) conv.groupAvatarUrl else conv.participantAvatars[peerUid].orEmpty()
                        val isPeerOnline = peerUid.isNotBlank() && presenceMap[peerUid]?.online == true
                        val typingSet = typingConversations[conv.id].orEmpty().filter { it != currentUserId }
                        val isUnread = pref?.markedUnread == true

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = {
                                        if (pref?.locked == true) {
                                            lockedConvToOpen = conv.id
                                        } else {
                                            onOpenConversation(conv.id)
                                        }
                                    },
                                    onLongClick = { actionTargetConv = conv }
                                )
                                .padding(
                                    horizontal = 16.dp,
                                    vertical = if (compactLayout) 8.dp else 12.dp
                                )
                                .testTag("home_conversation_${conv.id}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatarWithStatus(
                                name = title,
                                avatarUrl = avatar,
                                isOnlineRealtime = if (conv.isGroup) null else isPeerOnline,
                                size = if (compactLayout) 44.dp else 52.dp
                            )
                            Spacer(Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f).padding(end = 8.dp)
                                    )
                                    val ts = conv.lastMessageTimestamp ?: conv.updatedAt
                                    if (ts != null) {
                                        Text(
                                            text = formatShortTime(ts.seconds),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isUnread) BravPurple else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Spacer(Modifier.height(3.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (typingSet.isNotEmpty()) {
                                            "En train d'écrire..."
                                        } else {
                                            conv.lastMessage.ifBlank { "Appuyez pour discuter" }
                                        },
                                        color = if (typingSet.isNotEmpty()) BravPurple else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isUnread || typingSet.isNotEmpty()) FontWeight.SemiBold else FontWeight.Normal,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f).padding(end = 8.dp)
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        if (pref?.muted == true) {
                                            Icon(
                                                Icons.Rounded.NotificationsOff,
                                                contentDescription = "Muet",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                        if (pref?.pinned == true) {
                                            Icon(
                                                Icons.Rounded.PushPin,
                                                contentDescription = "Épinglée",
                                                tint = BravPurple,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                        if (pref?.locked == true) {
                                            Icon(
                                                Icons.Rounded.Lock,
                                                contentDescription = "Verrouillée",
                                                tint = BravRed,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                        if (isUnread) {
                                            Surface(
                                                shape = CircleShape,
                                                color = BravPurple,
                                                modifier = Modifier.size(20.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = "1",
                                                        color = Color.White,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 82.dp, end = 16.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
                        )
                    }
                }
            }
        }
    }

    actionTargetConv?.let { conv ->
        ConversationActionsDialog(
            title = resolveConversationTitle(conv, currentUserId),
            pref = prefsMap[conv.id],
            onTogglePin = {
                onUpdatePref(conv.id, null, !(prefsMap[conv.id]?.pinned ?: false), null, null, null, null)
                actionTargetConv = null
            },
            onToggleArchive = {
                onUpdatePref(conv.id, !(prefsMap[conv.id]?.archived ?: false), null, null, null, null, null)
                actionTargetConv = null
            },
            onToggleMute = {
                onUpdatePref(conv.id, null, null, !(prefsMap[conv.id]?.muted ?: false), null, null, null)
                actionTargetConv = null
            },
            onToggleLock = {
                onUpdatePref(conv.id, null, null, null, !(prefsMap[conv.id]?.locked ?: false), null, null)
                actionTargetConv = null
            },
            onToggleUnread = {
                onUpdatePref(conv.id, null, null, null, null, !(prefsMap[conv.id]?.markedUnread ?: false), null)
                actionTargetConv = null
            },
            onRequestDelete = {
                deleteConfirmConv = conv
                actionTargetConv = null
            },
            onDismiss = { actionTargetConv = null }
        )
    }

    deleteConfirmConv?.let { conv ->
        DeleteConversationDialog(
            conv = conv,
            title = resolveConversationTitle(conv, currentUserId),
            onConfirm = {
                onDeleteConversation(conv.id)
                deleteConfirmConv = null
            },
            onDismiss = { deleteConfirmConv = null }
        )
    }

    lockedConvToOpen?.let { cid ->
        ChatLockPromptDialog(
            hasPinConfigured = hasPinConfigured,
            onVerifyPin = onVerifyPin,
            onSuccess = {
                lockedConvToOpen = null
                onOpenConversation(cid)
            },
            onDismiss = { lockedConvToOpen = null }
        )
    }

    if (showCreateGroupDialog) {
        CreateGroupDialog(
            savedContacts = savedContacts,
            onCreate = { members, name, desc ->
                onCreateGroup(members, name, desc)
                showCreateGroupDialog = false
            },
            onDismiss = { showCreateGroupDialog = false }
        )
    }

    if (showJoinGroupDialog) {
        JoinGroupByCodeDialog(
            onJoin = { code ->
                onJoinGroupByCode(code)
                showJoinGroupDialog = false
            },
            onDismiss = { showJoinGroupDialog = false }
        )
    }
}

internal fun resolveConversationTitle(conv: Conversation, currentUserId: String): String {
    if (conv.isGroup) return conv.groupName.ifBlank { "Groupe BRAV" }
    val peerId = conv.participants.firstOrNull { it != currentUserId }.orEmpty()
    return conv.participantNames[peerId]?.ifBlank { "Membre BRAV" } ?: "Membre BRAV"
}
