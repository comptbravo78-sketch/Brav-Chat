package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.local.ThemeMode
import com.example.media.VoiceProcessingConfig
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed
import com.example.ui.theme.StatusOnlineGreen
import com.example.viewmodel.BravViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    viewModel: BravViewModel,
    isAdmin: Boolean,
    onBack: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenOffers: () -> Unit,
    onOpenAdmin: () -> Unit,
    onSignOut: () -> Unit
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val devices by viewModel.devices.collectAsStateWithLifecycle()
    val blockedUsers by viewModel.blockedUsers.collectAsStateWithLifecycle()
    val appPrefs by viewModel.appPrefs.collectAsStateWithLifecycle()
    val firebaseEmail = remember { Firebase.auth.currentUser?.email.orEmpty() }

    var showPinDialog by remember { mutableStateOf(false) }
    var showBlockedDialog by remember { mutableStateOf(false) }
    var showMicTestDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var legalDialog by remember { mutableStateOf<Pair<String, String>?>(null) }
    var cacheBytes by remember { mutableLongStateOf(viewModel.prefsRepository.computeLocalCacheSizeBytes()) }
    var permissionRefreshTick by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permissionRefreshTick++
    }

    val hwNsSupported = remember { runCatching { NoiseSuppressor.isAvailable() }.getOrDefault(false) }
    val hwAecSupported = remember { runCatching { AcousticEchoCanceler.isAvailable() }.getOrDefault(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Paramètres", fontWeight = FontWeight.Bold)
                        Text(
                            text = "Sécurité, confidentialité, appels et affichage",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
                    }
                }
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            val layoutClass = when {
                maxWidth >= 840.dp -> "Grand écran (Tablette / Paysage)"
                maxWidth >= 600.dp -> "Écran intermédiaire (Pliable)"
                else -> "Mobile compact"
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 48.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // A. Compte et sécurité
                item {
                    SettingsCategoryCard(
                        icon = Icons.Rounded.Security,
                        title = "A. Compte et sécurité",
                        subtitle = "Identifiants, sessions actives et protection du compte"
                    ) {
                        SettingsActionRow(
                            icon = Icons.Rounded.Person,
                            title = "Modifier mes informations de profil",
                            subtitle = "Nom, @username, photo, bio et coordonnées",
                            onClick = onOpenProfile,
                            testTag = "settings_to_profile_row"
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))

                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Rounded.Key, contentDescription = null, tint = StatusOnlineGreen, modifier = Modifier.size(20.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Authentification Google sécurisée", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = if (firebaseEmail.isNotBlank()) {
                                        "Connecté avec $firebaseEmail. Le mot de passe est géré via la sécurité Google."
                                    } else {
                                        "Authentification gérée via Google Credential Manager."
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { showPinDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("settings_pin_button")
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (appPrefs.chatLockPinHash.isBlank()) "Définir un code PIN de verrouillage"
                                else "Modifier ou désactiver le code PIN"
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.Devices, contentDescription = null, tint = BravPurple, modifier = Modifier.size(18.dp))
                            Text("Sessions actives (${devices.count { !it.revoked }})", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        }
                        devices.forEach { dev ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(dev.deviceName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = when {
                                            dev.revoked -> "Session révoquée"
                                            dev.deviceId == appPrefs.deviceId -> "Cet appareil • Actif"
                                            else -> "Appareil autorisé"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (dev.revoked) BravRed else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (!dev.revoked && dev.deviceId != appPrefs.deviceId) {
                                    TextButton(onClick = {
                                        scope.launch { viewModel.userRepository.revokeDeviceSession(viewModel.currentUserId, dev.deviceId) }
                                    }) {
                                        Text("Révoquer", color = BravRed)
                                    }
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        val r = viewModel.userRepository.exportEncryptedBackup(viewModel.currentUserId)
                                        viewModel.showMessage(if (r.isSuccess) "Sauvegarde chiffrée enregistrée" else "Échec de sauvegarde")
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.Backup, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Sauvegarder")
                            }
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        val r = viewModel.userRepository.restoreEncryptedBackup(viewModel.currentUserId)
                                        viewModel.showMessage(if (r.isSuccess) "Sauvegarde restaurée" else r.exceptionOrNull()?.localizedMessage ?: "Échec")
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Restaurer")
                            }
                        }

                        Button(
                            onClick = onSignOut,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("sign_out_button")
                        ) {
                            Icon(Icons.Rounded.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Se déconnecter")
                        }

                        TextButton(
                            onClick = { showDeleteConfirm = true },
                            modifier = Modifier.fillMaxWidth().testTag("delete_account_button")
                        ) {
                            Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = BravRed, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Supprimer définitivement mon compte", color = BravRed)
                        }
                    }
                }

                // B. Confidentialité
                item {
                    val priv = currentUser?.privacySettings ?: emptyMap()
                    SettingsCategoryCard(
                        icon = Icons.Rounded.PrivacyTip,
                        title = "B. Confidentialité",
                        subtitle = "Contrôle de visibilité et autorisations système"
                    ) {
                        listOf(
                            "showPhoto" to "Photo de profil visible par",
                            "showStatus" to "Statuts visibles par",
                            "showLastSeen" to "Dernière présence visible par",
                            "showInfo" to "Biographie et ville visibles par",
                            "whoCanCall" to "Qui peut m'appeler",
                            "whoCanAddToGroup" to "Ajout aux groupes",
                            "whoCanRequest" to "Demandes de contact"
                        ).forEach { (key, label) ->
                            val currentVal = priv[key] ?: "everyone"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                TextButton(onClick = {
                                    val next = when (currentVal) {
                                        "everyone" -> "contacts"
                                        "contacts" -> "nobody"
                                        else -> "everyone"
                                    }
                                    scope.launch {
                                        viewModel.userRepository.updatePrivacySettings(viewModel.currentUserId, priv + (key to next))
                                    }
                                }) {
                                    Text(
                                        when (currentVal) {
                                            "contacts" -> "Contacts"
                                            "nobody" -> "Personne"
                                            else -> "Tout le monde"
                                        },
                                        color = BravPurple,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        SettingsActionRow(
                            icon = Icons.Rounded.Block,
                            title = "Utilisateurs bloqués",
                            subtitle = if (blockedUsers.isEmpty()) "Aucun contact bloqué" else "${blockedUsers.size} utilisateur(s) bloqué(s)",
                            onClick = { showBlockedDialog = true },
                            testTag = "settings_blocked_users_button"
                        )

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))

                        Text("Autorisations Android", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        val permissionsList = buildList {
                            add(Manifest.permission.RECORD_AUDIO to "Microphone (appels & notes vocales)")
                            add(Manifest.permission.CAMERA to "Caméra (appels vidéo & statuts)")
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                add(Manifest.permission.POST_NOTIFICATIONS to "Notifications d'appels & messages")
                            }
                            add(Manifest.permission.ACCESS_FINE_LOCATION to "Localisation précise (carte temps réel)")
                            add(Manifest.permission.READ_CONTACTS to "Répertoire contacts")
                        }
                        remember(permissionRefreshTick) { permissionRefreshTick }
                        permissionsList.forEach { (perm, label) ->
                            val granted = ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                if (granted) {
                                    Surface(
                                        shape = RoundedCornerShape(999.dp),
                                        color = StatusOnlineGreen.copy(alpha = 0.14f)
                                    ) {
                                        Text(
                                            text = "Accordée",
                                            color = StatusOnlineGreen,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                        )
                                    }
                                } else {
                                    TextButton(onClick = { permLauncher.launch(perm) }) {
                                        Text("Autoriser", color = BravPurple, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        TextButton(
                            onClick = {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.fromParts("package", context.packageName, null)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                runCatching { context.startActivity(intent) }
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Paramètres système de l'application")
                        }
                    }
                }

                // C. Notifications
                item {
                    SettingsCategoryCard(
                        icon = Icons.Rounded.Notifications,
                        title = "C. Notifications",
                        subtitle = "Alertes de messages, appels entrants et manqués"
                    ) {
                        SettingsSwitchRow(
                            title = "Activer les notifications",
                            subtitle = "Interrupteur général pour toutes les alertes BRAV",
                            checked = appPrefs.notificationsEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setNotificationSettings(master = it) }
                        }
                        SettingsSwitchRow(
                            title = "Messages privés",
                            checked = appPrefs.notifyMessages,
                            enabled = appPrefs.notificationsEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setNotificationSettings(messages = it) }
                        }
                        SettingsSwitchRow(
                            title = "Appels entrants",
                            checked = appPrefs.notifyCalls,
                            enabled = appPrefs.notificationsEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setNotificationSettings(calls = it) }
                        }
                        SettingsSwitchRow(
                            title = "Appels manqués",
                            checked = appPrefs.notifyMissedCalls,
                            enabled = appPrefs.notificationsEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setNotificationSettings(missedCalls = it) }
                        }
                        SettingsSwitchRow(
                            title = "Discussions de groupe & statuts",
                            checked = appPrefs.notifyGroups && appPrefs.notifyStatuses,
                            enabled = appPrefs.notificationsEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setNotificationSettings(groups = it, statuses = it) }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
                        SettingsSwitchRow(
                            title = "Sonneries et alertes sonores",
                            checked = appPrefs.notifySoundEnabled,
                            enabled = appPrefs.notificationsEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setNotificationSettings(sound = it) }
                        }
                        SettingsSwitchRow(
                            title = "Vibrations",
                            checked = appPrefs.notifyVibrationEnabled,
                            enabled = appPrefs.notificationsEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setNotificationSettings(vibration = it) }
                        }
                        SettingsSwitchRow(
                            title = "Masquer le contenu sur l'écran verrouillé",
                            checked = appPrefs.hideNotificationContent,
                            enabled = appPrefs.notificationsEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setNotificationSettings(hideContent = it) }
                        }
                    }
                }

                // D. Paramètres des appels
                item {
                    SettingsCategoryCard(
                        icon = Icons.Rounded.Call,
                        title = "D. Paramètres des appels",
                        subtitle = "Qualité vocale, réduction du bruit ambiant et routage audio"
                    ) {
                        DefaultDialerActionCard()
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
                        SettingsSwitchRow(
                            title = "Réduction du bruit ambiant",
                            subtitle = "Filtre actif des bruits de fond (vent, circulation, parasites) sur le micro transmis",
                            checked = appPrefs.noiseSuppressionEnabled,
                            testTag = "switch_noise_suppression"
                        ) {
                            scope.launch { viewModel.prefsRepository.setCallAudioSettings(noiseSuppression = it) }
                        }
                        SettingsSwitchRow(
                            title = "Suppression de l'écho (AEC)",
                            subtitle = "Élimine le retour de la voix du correspondant pendant les appels",
                            checked = appPrefs.echoCancellationEnabled,
                            testTag = "switch_echo_cancellation"
                        ) {
                            scope.launch { viewModel.prefsRepository.setCallAudioSettings(echoCancellation = it) }
                        }
                        SettingsSwitchRow(
                            title = "Priorité vocale & gain automatique",
                            subtitle = "Met en avant la bande vocale humaine (EQ + AGC doux) pour une écoute nette",
                            checked = appPrefs.voicePriorityEnabled,
                            testTag = "switch_voice_priority"
                        ) {
                            scope.launch { viewModel.prefsRepository.setCallAudioSettings(voicePriority = it, autoGainControl = it) }
                        }
                        SettingsSwitchRow(
                            title = "Haut-parleur par défaut (appels audio)",
                            checked = appPrefs.defaultSpeakerAudio
                        ) {
                            scope.launch { viewModel.prefsRepository.setCallAudioSettings(defaultSpeakerAudio = it) }
                        }
                        SettingsSwitchRow(
                            title = "Démarrer les appels micro coupé",
                            checked = appPrefs.startCallMuted
                        ) {
                            scope.launch { viewModel.prefsRepository.setCallAudioSettings(startMuted = it) }
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.65f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Capacités audio de cet appareil", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Réducteur de bruit matériel : ${if (hwNsSupported) "Pris en charge + DSP BRAV" else "Traitement DSP BRAV actif"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Annulateur d'écho matériel : ${if (hwAecSupported) "Pris en charge + WebRTC AEC" else "WebRTC AEC logiciel actif"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { showMicTestDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("test_mic_dsp_button")
                        ) {
                            Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = BravPurple, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Tester le microphone et le filtre vocal")
                        }
                    }
                }

                // E. Apparence
                item {
                    SettingsCategoryCard(
                        icon = Icons.Rounded.Palette,
                        title = "E. Apparence & Stockage",
                        subtitle = "Thème, densité d'affichage et optimisation réseau"
                    ) {
                        Text("Thème de l'interface", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemeMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = appPrefs.themeMode == mode,
                                    onClick = { viewModel.setThemeMode(mode) },
                                    label = { Text(mode.label) }
                                )
                            }
                        }

                        SettingsSwitchRow(
                            title = "Affichage compact des listes",
                            checked = appPrefs.compactLayoutEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setCompactLayout(it) }
                        }
                        SettingsSwitchRow(
                            title = "Économiseur de données",
                            checked = appPrefs.dataSaverEnabled
                        ) {
                            scope.launch { viewModel.prefsRepository.setDataSaver(it) }
                        }
                        SettingsSwitchRow(
                            title = "Télécharger médias en Wi-Fi uniquement",
                            checked = appPrefs.autoDownloadWifiOnly
                        ) {
                            scope.launch { viewModel.prefsRepository.setAutoDownloadWifiOnly(it) }
                        }

                        Text(
                            text = "Format détecté : $layoutClass",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedButton(
                            onClick = {
                                viewModel.prefsRepository.clearLocalMediaCache()
                                cacheBytes = viewModel.prefsRepository.computeLocalCacheSizeBytes()
                                viewModel.showMessage("Cache média nettoyé")
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Vider le cache local (${(cacheBytes / 1024L)} Ko)")
                        }
                    }
                }

                // F. Informations sur BRAV CHAT
                item {
                    SettingsCategoryCard(
                        icon = Icons.Rounded.Info,
                        title = "F. Informations sur BRAV CHAT",
                        subtitle = "Version, documents légaux et services associés"
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Version de l'application", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "v${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        SettingsActionRow(
                            icon = Icons.Rounded.Description,
                            title = "Conditions d'utilisation",
                            subtitle = "Règles de messagerie, appels et annonces",
                            onClick = {
                                legalDialog = "Conditions d'utilisation BRAV CHAT" to TERMS_TEXT
                            }
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.VerifiedUser,
                            title = "Politique de confidentialité",
                            subtitle = "Chiffrement de bout en bout et protection des données",
                            onClick = {
                                legalDialog = "Politique de confidentialité BRAV CHAT" to PRIVACY_TEXT
                            }
                        )
                        SettingsActionRow(
                            icon = Icons.Rounded.Storefront,
                            title = "Annonces & Offres gratuites",
                            subtitle = "Consulter ou publier des offres communautaires",
                            onClick = onOpenOffers
                        )
                        if (isAdmin) {
                            SettingsActionRow(
                                icon = Icons.Rounded.AdminPanelSettings,
                                title = "Console d'administration BRAV",
                                subtitle = "Modération et signalements",
                                onClick = onOpenAdmin,
                                accentTint = BravRed
                            )
                        }
                    }
                }
            }
        }
    }

    if (showPinDialog) {
        ChatLockPinDialog(
            hasPinConfigured = appPrefs.chatLockPinHash.isNotBlank(),
            onSavePin = { pin ->
                viewModel.prefsRepository.setChatLockPin(pin)
                viewModel.showMessage(if (pin.isBlank()) "Code PIN désactivé" else "Code PIN enregistré")
            },
            onDismiss = { showPinDialog = false }
        )
    }

    if (showBlockedDialog) {
        BlockedUsersDialog(
            blockedUsers = blockedUsers,
            onUnblock = { targetUid ->
                scope.launch {
                    viewModel.userRepository.unblockUser(viewModel.currentUserId, targetUid)
                    viewModel.showMessage("Utilisateur débloqué")
                }
            },
            onDismiss = { showBlockedDialog = false }
        )
    }

    if (showMicTestDialog) {
        LiveMicrophoneTestDialog(
            processingConfig = VoiceProcessingConfig(
                noiseSuppressionEnabled = appPrefs.noiseSuppressionEnabled,
                echoCancellationEnabled = appPrefs.echoCancellationEnabled,
                autoGainControlEnabled = appPrefs.autoGainControlEnabled,
                voicePriorityEnabled = appPrefs.voicePriorityEnabled
            ),
            onDismiss = { showMicTestDialog = false }
        )
    }

    legalDialog?.let { (title, content) ->
        LegalDocumentDialog(
            title = title,
            content = content,
            onDismiss = { legalDialog = null }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Supprimer définitivement le compte ?") },
            text = { Text("Cette action efface votre profil, vos appareils enregistrés et vos préférences sur BRAV CHAT.") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = BravRed, contentColor = Color.White),
                    onClick = {
                        showDeleteConfirm = false
                        scope.launch {
                            viewModel.userRepository.deleteAccountData(viewModel.currentUserId)
                            onSignOut()
                        }
                    }
                ) { Text("Supprimer") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
private fun SettingsCategoryCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(BravPurple.copy(alpha = 0.12f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = BravPurple, modifier = Modifier.size(20.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    enabled: Boolean = true,
    testTag: String = "",
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (enabled) 1f else 0.5f)
                )
            }
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            modifier = if (testTag.isNotBlank()) Modifier.testTag(testTag) else Modifier
        )
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    accentTint: Color = BravPurple,
    testTag: String = ""
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.4f),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (testTag.isNotBlank()) Modifier.testTag(testTag) else Modifier)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accentTint, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(
                Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private const val TERMS_TEXT =
    "BRAV CHAT est une plateforme de messagerie chiffrée et d'appels audio/vidéo WebRTC.\n\n" +
        "1. Respect des membres : tout harcèlement, usurpation d'identité ou diffusion illégale de contenu est interdit et peut entraîner une suspension.\n" +
        "2. Appels et messagerie : vous êtes responsable des échanges effectués depuis votre compte Google authentifié.\n" +
        "3. Annonces gratuites : les offres publiées sur BRAV CHAT sont gratuites et soumises à modération en cas d'abus."

private const val PRIVACY_TEXT =
    "Protection des données BRAV CHAT :\n\n" +
        "• Chiffrement de bout en bout (E2EE) des messages et localisations en direct.\n" +
        "• Les coordonnées privées (e-mail, téléphone) sont conservées dans votre espace propriétaire isolé et ne sont jamais exposées sans votre accord.\n" +
        "• Les appels audio et vidéo WebRTC transitent en temps réel avec traitement local du bruit ambiant directement sur votre appareil.\n" +
        "• Vous pouvez modifier votre photo, exporter une sauvegarde chiffrée ou supprimer votre compte à tout moment."
