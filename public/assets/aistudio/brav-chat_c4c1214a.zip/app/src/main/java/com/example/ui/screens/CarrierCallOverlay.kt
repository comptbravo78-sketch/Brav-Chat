package com.example.ui.screens

import android.telecom.Call
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.telecom.CarrierCallController
import com.example.telecom.CarrierCallUiState
import com.example.ui.theme.BravPurple
import com.example.ui.theme.CallActionGreen
import com.example.ui.theme.EndCallRed
import kotlinx.coroutines.delay

@Composable
fun CarrierCallOverlay(state: CarrierCallUiState) {
    if (!state.hasCall) return

    var elapsedSeconds by remember(state.connectTimeMillis, state.state) { mutableLongStateOf(0L) }
    LaunchedEffect(state.state, state.connectTimeMillis) {
        while (state.state == Call.STATE_ACTIVE || state.state == Call.STATE_HOLDING) {
            elapsedSeconds = if (state.connectTimeMillis > 0L) {
                ((System.currentTimeMillis() - state.connectTimeMillis) / 1000L).coerceAtLeast(0L)
            } else {
                elapsedSeconds + 1L
            }
            delay(1000L)
        }
    }

    val title = state.callerDisplayName.ifBlank { state.number }.ifBlank { "Appel téléphonique" }
    val subtitle = if (state.callerDisplayName.isNotBlank() && state.number.isNotBlank()) state.number else ""

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .zIndex(105f),
        color = CallLightBg
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CallLightBg)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(bottom = 72.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CallPeerPhotoAvatar(
                    name = title,
                    avatarUrl = "",
                    size = 132.dp,
                    ringAnimated = state.isRinging,
                    isLightSurface = true
                )
                Spacer(Modifier.height(20.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = CallSlateText,
                    textAlign = TextAlign.Center
                )
                if (subtitle.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = CallMutedText)
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = if (state.isActive && elapsedSeconds > 0L) {
                        "${state.statusLabel} • ${formatCallChronometer(elapsedSeconds)}"
                    } else {
                        state.statusLabel
                    },
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = BravPurple
                )
            }

            if (state.isRinging) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .widthIn(max = 420.dp)
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Surface(
                        shape = CircleShape,
                        color = EndCallRed,
                        onClick = { CarrierCallController.rejectOrHangup() },
                        modifier = Modifier.size(72.dp).testTag("carrier_reject_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.CallEnd, contentDescription = "Refuser", tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                    }
                    Surface(
                        shape = CircleShape,
                        color = CallActionGreen,
                        onClick = { CarrierCallController.answer() },
                        modifier = Modifier.size(72.dp).testTag("carrier_accept_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Call, contentDescription = "Répondre", tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = CallLightCard,
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .widthIn(max = 420.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (state.isMuted) BravPurple else Color(0xFFF1F5F9),
                            onClick = { CarrierCallController.toggleMute() },
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    if (state.isMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                                    contentDescription = "Micro",
                                    tint = if (state.isMuted) Color.White else CallSlateText
                                )
                            }
                        }
                        Surface(
                            shape = CircleShape,
                            color = if (state.isSpeakerOn) BravPurple else Color(0xFFF1F5F9),
                            onClick = { CarrierCallController.toggleSpeaker() },
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.AutoMirrored.Rounded.VolumeUp,
                                    contentDescription = "Haut-parleur",
                                    tint = if (state.isSpeakerOn) Color.White else CallSlateText
                                )
                            }
                        }
                        Surface(
                            shape = CircleShape,
                            color = if (state.isHolding) BravPurple else Color(0xFFF1F5F9),
                            onClick = { CarrierCallController.toggleHold() },
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    if (state.isHolding) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                                    contentDescription = "Attente",
                                    tint = if (state.isHolding) Color.White else CallSlateText
                                )
                            }
                        }
                        Surface(
                            shape = CircleShape,
                            color = EndCallRed,
                            onClick = { CarrierCallController.rejectOrHangup() },
                            modifier = Modifier.size(62.dp).testTag("carrier_hangup_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.CallEnd, contentDescription = "Raccrocher", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}
