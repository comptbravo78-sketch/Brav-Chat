package com.example.messaging

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.local.AppPreferencesRepository
import com.example.network.WorkerApiClient
import com.example.network.WorkerConstants
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okhttp3.Request

class BravFirebaseMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "FCM token refreshed")
        if (Firebase.auth.currentUser != null) {
            serviceScope.launch {
                runCatching { WorkerApiClient().registerDeviceToken(token) }
            }
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        serviceScope.launch {
            val prefsRepo = AppPreferencesRepository(applicationContext)
            val prefs = runCatching { prefsRepo.state.first() }.getOrNull()
            if (prefs?.notificationsEnabled == false) return@launch

            val type = message.data["type"].orEmpty()
            val title = message.notification?.title ?: message.data["title"] ?: "BRAV Chat"
            val bodyRaw = message.notification?.body ?: message.data["body"] ?: "Nouvelle notification"

            val shouldNotify = when (type) {
                "incoming_call" -> prefs?.notifyCalls ?: true
                "missed_call" -> prefs?.notifyMissedCalls ?: true
                "group_message" -> prefs?.notifyGroups ?: true
                "status" -> prefs?.notifyStatuses ?: true
                else -> prefs?.notifyMessages ?: true
            }
            if (!shouldNotify) return@launch

            val soundOn = prefs?.notifySoundEnabled ?: true
            val vibOn = prefs?.notifyVibrationEnabled ?: true
            val avatarUrl = message.data["callerAvatar"].orEmpty()
                .ifBlank { message.data["avatarUrl"].orEmpty() }

            if (type == "incoming_call") {
                val callId = message.data["callId"].orEmpty()
                if (callId.isNotBlank()) {
                    showIncomingCallNotification(
                        context = applicationContext,
                        callId = callId,
                        callerName = message.data["callerName"].orEmpty().ifBlank { title },
                        callerAvatarUrl = avatarUrl,
                        isVideo = message.data["callType"] == "video",
                        soundEnabled = soundOn,
                        vibrationEnabled = vibOn
                    )
                    return@launch
                }
            }

            val body = if (prefs?.hideNotificationContent == true) {
                "Nouveau contenu chiffré — appuyez pour ouvrir"
            } else {
                bodyRaw
            }

            val largeIcon = if (avatarUrl.isNotBlank()) {
                fetchCircularAvatarBitmap(avatarUrl)
            } else null

            showNotification(
                channelId = when (type) {
                    "incoming_call", "missed_call" -> CHANNEL_CALLS
                    "status", "contact_request" -> CHANNEL_SOCIAL
                    else -> CHANNEL_MESSAGES
                },
                title = title,
                body = body,
                conversationId = message.data["conversationId"],
                callId = message.data["callId"],
                isCall = type == "incoming_call",
                soundEnabled = soundOn,
                vibrationEnabled = vibOn,
                largeIcon = largeIcon
            )
        }
    }

    private fun showNotification(
        channelId: String,
        title: String,
        body: String,
        conversationId: String?,
        callId: String?,
        isCall: Boolean,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean,
        largeIcon: Bitmap? = null
    ) {
        ensureChannels(applicationContext)
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (!conversationId.isNullOrBlank()) putExtra("extra_conversation_id", conversationId)
            if (!callId.isNullOrBlank()) putExtra("extra_call_id", callId)
        }
        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            (conversationId ?: callId ?: title).hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.ic_brav_logo)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setPriority(if (isCall) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .apply {
                if (largeIcon != null) setLargeIcon(largeIcon)
                if (!soundEnabled && !vibrationEnabled) {
                    setSilent(true)
                } else {
                    var defaults = 0
                    if (soundEnabled) defaults = defaults or NotificationCompat.DEFAULT_SOUND
                    if (vibrationEnabled) defaults = defaults or NotificationCompat.DEFAULT_VIBRATE
                    setDefaults(defaults)
                    if (!vibrationEnabled) setVibrate(longArrayOf(0L))
                }
            }

        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build())
    }

    companion object {
        private const val TAG = "BravFCM"
        const val CHANNEL_MESSAGES = "brav_messages_channel"
        const val CHANNEL_CALLS = "brav_calls_channel"
        const val CHANNEL_SOCIAL = "brav_social_channel"
        private val notificationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        fun ensureChannels(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_MESSAGES,
                    context.getString(R.string.notification_channel_messages_name),
                    NotificationManager.IMPORTANCE_HIGH
                ),
                NotificationChannel(
                    CHANNEL_CALLS,
                    context.getString(R.string.notification_channel_calls_name),
                    NotificationManager.IMPORTANCE_HIGH
                ),
                NotificationChannel(
                    CHANNEL_SOCIAL,
                    context.getString(R.string.notification_channel_social_name),
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
            nm.createNotificationChannels(channels)
        }

        fun showIncomingCallNotification(
            context: Context,
            callId: String,
            callerName: String,
            callerAvatarUrl: String = "",
            isVideo: Boolean,
            soundEnabled: Boolean = true,
            vibrationEnabled: Boolean = true
        ) {
            ensureChannels(context)
            val appCtx = context.applicationContext

            fun postWithAvatar(avatarBitmap: Bitmap?) {
                val intent = Intent(appCtx, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("extra_call_id", callId)
                }
                val pendingIntent = PendingIntent.getActivity(
                    appCtx,
                    callId.hashCode(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val title = if (isVideo) "Appel vidéo entrant" else "Appel audio entrant"
                val body = "${callerName.ifBlank { "Membre BRAV" }} vous appelle..."
                val builder = NotificationCompat.Builder(appCtx, CHANNEL_CALLS)
                    .setSmallIcon(R.drawable.ic_brav_logo)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setOngoing(true)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .setFullScreenIntent(pendingIntent, true)
                    .apply {
                        if (avatarBitmap != null) setLargeIcon(avatarBitmap)
                        if (!soundEnabled && !vibrationEnabled) {
                            setSilent(true)
                        } else if (!vibrationEnabled) {
                            setVibrate(longArrayOf(0L))
                        }
                    }

                val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                runCatching { nm.notify(callId.hashCode(), builder.build()) }
            }

            postWithAvatar(null)
            if (callerAvatarUrl.isNotBlank()) {
                notificationScope.launch {
                    val bmp = fetchCircularAvatarBitmap(callerAvatarUrl)
                    if (bmp != null) {
                        postWithAvatar(bmp)
                    }
                }
            }
        }

        fun showMissedCallNotification(
            context: Context,
            callId: String,
            callerName: String,
            callerAvatarUrl: String = "",
            isVideo: Boolean,
            soundEnabled: Boolean = true,
            vibrationEnabled: Boolean = true
        ) {
            ensureChannels(context)
            val appCtx = context.applicationContext
            notificationScope.launch {
                val bmp = if (callerAvatarUrl.isNotBlank()) fetchCircularAvatarBitmap(callerAvatarUrl) else null
                val intent = Intent(appCtx, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pendingIntent = PendingIntent.getActivity(
                    appCtx,
                    ("missed_$callId").hashCode(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val title = if (isVideo) "Appel vidéo manqué" else "Appel audio manqué"
                val body = callerName.ifBlank { "Membre BRAV" }
                val builder = NotificationCompat.Builder(appCtx, CHANNEL_CALLS)
                    .setSmallIcon(R.drawable.ic_brav_logo)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .apply {
                        if (bmp != null) setLargeIcon(bmp)
                        if (!soundEnabled && !vibrationEnabled) setSilent(true)
                    }
                val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                runCatching { nm.notify(("missed_$callId").hashCode(), builder.build()) }
            }
        }

        fun cancelIncomingCallNotification(context: Context, callId: String) {
            if (callId.isBlank()) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            runCatching { nm.cancel(callId.hashCode()) }
        }

        private fun fetchCircularAvatarBitmap(rawUrl: String): Bitmap? {
            return runCatching {
                val resolvedUrl = if (rawUrl.startsWith("/")) "${WorkerConstants.BASE_URL}$rawUrl" else rawUrl
                val client = WorkerApiClient().mediaAuthorizedClient
                val req = Request.Builder().url(resolvedUrl).get().build()
                val bytes = client.newCall(req).execute().use { res ->
                    if (!res.isSuccessful) return null
                    res.body?.bytes()
                } ?: return null
                if (bytes.isEmpty()) return null

                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / sample > 256 || bounds.outHeight / sample > 256) {
                    sample *= 2
                }
                val decoded = BitmapFactory.decodeByteArray(
                    bytes,
                    0,
                    bytes.size,
                    BitmapFactory.Options().apply { inSampleSize = sample }
                ) ?: return null

                val targetSize = 128
                val output = Bitmap.createBitmap(targetSize, targetSize, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(output)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                val rect = Rect(0, 0, decoded.width, decoded.height)
                val side = minOf(decoded.width, decoded.height)
                val srcLeft = (decoded.width - side) / 2
                val srcTop = (decoded.height - side) / 2
                val cropSrc = Rect(srcLeft, srcTop, srcLeft + side, srcTop + side)
                val dstRect = RectF(0f, 0f, targetSize.toFloat(), targetSize.toFloat())
                canvas.drawOval(dstRect, paint)
                paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
                canvas.drawBitmap(decoded, cropSrc, dstRect, paint)
                if (decoded != output) decoded.recycle()
                output
            }.getOrNull()
        }
    }
}
