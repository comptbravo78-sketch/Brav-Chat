package com.example.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "offline_outbox")
data class OfflineMessageEntity(
    @PrimaryKey val localId: String,
    val conversationId: String,
    val senderId: String,
    val receiverId: String,
    val plaintext: String,
    val messageType: String,
    val replyToMessageId: String = "",
    val replyToPreview: String = "",
    val forwardedFrom: String = "",
    val peerPublicKey: String = "",
    val isGroup: Boolean = false,
    val groupKeyBase64: String = "",
    val createdAtMs: Long = System.currentTimeMillis()
)

@Dao
interface OfflineQueueDao {
    @Query("SELECT * FROM offline_outbox WHERE conversationId = :conversationId ORDER BY createdAtMs ASC")
    fun observePendingForConversation(conversationId: String): Flow<List<OfflineMessageEntity>>

    @Query("SELECT * FROM offline_outbox ORDER BY createdAtMs ASC")
    suspend fun getAllPending(): List<OfflineMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(item: OfflineMessageEntity)

    @Query("DELETE FROM offline_outbox WHERE localId = :localId")
    suspend fun deleteById(localId: String)

    @Query("DELETE FROM offline_outbox WHERE conversationId = :conversationId")
    suspend fun deleteForConversation(conversationId: String)

    @Query("DELETE FROM offline_outbox")
    suspend fun clearAll()
}

@Database(
    entities = [OfflineMessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class BravLocalDatabase : RoomDatabase() {
    abstract fun offlineQueueDao(): OfflineQueueDao

    companion object {
        @Volatile
        private var INSTANCE: BravLocalDatabase? = null

        fun getInstance(context: Context): BravLocalDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BravLocalDatabase::class.java,
                    "brav_chat_local_outbox.db"
                ).fallbackToDestructiveMigration(true).build().also { INSTANCE = it }
            }
        }
    }
}
