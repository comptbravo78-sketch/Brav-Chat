package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.local.AppPreferencesRepository
import com.example.network.WorkerApiClient
import com.example.network.WorkerRealtimeClient
import com.example.repository.UserRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

sealed interface AuthUiState {
    data object Loading : AuthUiState
    data object Unauthenticated : AuthUiState
    data class Authenticated(val firebaseUser: FirebaseUser) : AuthUiState
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        trySend(firebaseAuth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class AuthViewModel(
    private val userRepository: UserRepository,
    private val prefsRepository: AppPreferencesRepository,
    private val workerApiClient: WorkerApiClient,
    private val realtimeClient: WorkerRealtimeClient
) : ViewModel() {

    private val auth = Firebase.auth

    private val _authState = MutableStateFlow<AuthUiState>(
        auth.currentUser?.let { AuthUiState.Authenticated(it) } ?: AuthUiState.Unauthenticated
    )
    val authState: StateFlow<AuthUiState> = _authState.asStateFlow()

    private val _isSigningIn = MutableStateFlow(false)
    val isSigningIn: StateFlow<Boolean> = _isSigningIn.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        val user = firebaseAuth.currentUser
        if (user != null) {
            _authState.value = AuthUiState.Authenticated(user)
            onUserAuthenticated(user)
        } else {
            realtimeClient.disconnect()
            _authState.value = AuthUiState.Unauthenticated
        }
    }

    init {
        auth.addAuthStateListener(authStateListener)
    }

    fun signInWithGoogleIdToken(idToken: String) {
        viewModelScope.launch {
            _isSigningIn.value = true
            _authError.value = null
            try {
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                auth.signInWithCredential(credential).await()
            } catch (e: Exception) {
                Log.e(TAG, "Firebase Google sign-in failed", e)
                _authError.value = e.localizedMessage ?: "Échec de connexion Google."
            } finally {
                _isSigningIn.value = false
            }
        }
    }

    fun setLoading(loading: Boolean) {
        _isSigningIn.value = loading
    }

    fun setAuthError(message: String?) {
        _authError.value = message
    }

    fun signOut() {
        viewModelScope.launch {
            runCatching {
                val fcmToken = FirebaseMessaging.getInstance().token.await()
                if (!fcmToken.isNullOrBlank()) {
                    workerApiClient.unregisterDeviceToken(fcmToken)
                }
            }
            realtimeClient.disconnect()
            auth.signOut()
        }
    }

    private fun onUserAuthenticated(user: FirebaseUser) {
        viewModelScope.launch {
            val deviceId = prefsRepository.getOrCreateDeviceId()
            val config = workerApiClient.getOrFetchConfig(forceRefresh = true)
            val profile = userRepository.ensureUserProfileExists(user, deviceId).getOrNull()
            if (profile != null) {
                workerApiClient.syncUserDirectoryToD1(
                    userId = profile.userId,
                    displayName = profile.displayName,
                    username = profile.username,
                    city = profile.locationCity,
                    avatarUrl = profile.avatarUrl
                )
            }
            if (config == null || config.features.realtimeHub) {
                realtimeClient.connect(deviceId)
            }
            runCatching {
                val fcmToken = FirebaseMessaging.getInstance().token.await()
                if (!fcmToken.isNullOrBlank()) {
                    workerApiClient.registerDeviceToken(fcmToken)
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        auth.removeAuthStateListener(authStateListener)
    }

    companion object {
        private const val TAG = "BravAuthVM"
    }
}
