package com.example.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.crypto.E2eeCryptoManager
import com.example.local.AppPreferencesRepository
import com.example.local.BravLocalDatabase
import com.example.media.VoiceRecorderPlayer
import com.example.media.WebRtcCallManager
import com.example.network.WorkerApiClient
import com.example.network.WorkerRealtimeClient
import com.example.repository.AiTranslationRepository
import com.example.repository.CallRepository
import com.example.repository.ChatRepository
import com.example.repository.ContactSyncRepository
import com.example.repository.SocialRepository
import com.example.repository.UserRepository
import com.example.telecom.CarrierCallController
import com.example.ui.components.BravLogoMark
import com.example.ui.screens.AdminModerationScreen
import com.example.ui.screens.CallHistoryScreen
import com.example.ui.screens.CallScreen
import com.example.ui.screens.CallTerminalOverlay
import com.example.ui.screens.CarrierCallOverlay
import com.example.ui.screens.ChatConversationScreen
import com.example.ui.screens.ContactsScreen
import com.example.ui.screens.DialerModalSheet
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.IncomingCallBannerDialog
import com.example.ui.screens.LiveMapScreen
import com.example.ui.screens.OffersMarketplaceScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SignInScreen
import com.example.ui.screens.StatusesScreen
import com.example.util.DefaultDialerHelper
import com.example.viewmodel.AuthUiState
import com.example.viewmodel.AuthViewModel
import com.example.viewmodel.BravViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

private enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("Discussions", Icons.Rounded.ChatBubble),
    STATUSES("Actus", Icons.Rounded.AutoAwesome),
    CONTACTS("Contacts", Icons.Rounded.Contacts),
    CALLS("Appels", Icons.Rounded.Call),
    PROFILE("Profil", Icons.Rounded.Person)
}

private sealed interface SecondaryRoute {
    data object None : SecondaryRoute
    data class Conversation(val conversationId: String) : SecondaryRoute
    data object Statuses : SecondaryRoute
    data object LiveMap : SecondaryRoute
    data object Offers : SecondaryRoute
    data object Admin : SecondaryRoute
    data object Settings : SecondaryRoute
}

@Composable
fun BravMainApp(
    prefsRepository: AppPreferencesRepository,
    workerApiClient: WorkerApiClient,
    realtimeClient: WorkerRealtimeClient,
    initialConversationId: String? = null,
    initialCallId: String? = null,
    initialDialNumber: String? = null,
    onConsumeInitialDialNumber: () -> Unit = {}
) {
    val authViewModel: AuthViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                val crypto = E2eeCryptoManager(app)
                AuthViewModel(
                    userRepository = UserRepository(db, crypto),
                    prefsRepository = prefsRepository,
                    workerApiClient = workerApiClient,
                    realtimeClient = realtimeClient
                )
            }
        }
    )

    val authState by authViewModel.authState.collectAsStateWithLifecycle()
    val isSigningIn by authViewModel.isSigningIn.collectAsStateWithLifecycle()
    val authError by authViewModel.authError.collectAsStateWithLifecycle()

    when (val state = authState) {
        AuthUiState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        AuthUiState.Unauthenticated -> {
            SignInScreen(
                isLoading = isSigningIn,
                errorMessage = authError,
                onGoogleIdToken = authViewModel::signInWithGoogleIdToken,
                onSetLoading = authViewModel::setLoading,
                onError = authViewModel::setAuthError
            )
        }
        is AuthUiState.Authenticated -> {
            val uid = state.firebaseUser.uid
            key(uid) {
                AuthenticatedBravShell(
                    currentUserId = uid,
                    userEmail = state.firebaseUser.email,
                    prefsRepository = prefsRepository,
                    workerApiClient = workerApiClient,
                    realtimeClient = realtimeClient,
                    initialConversationId = initialConversationId,
                    initialCallId = initialCallId,
                    initialDialNumber = initialDialNumber,
                    onConsumeInitialDialNumber = onConsumeInitialDialNumber,
                    onSignOut = { authViewModel.signOut() }
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedBravShell(
    currentUserId: String,
    userEmail: String?,
    prefsRepository: AppPreferencesRepository,
    workerApiClient: WorkerApiClient,
    realtimeClient: WorkerRealtimeClient,
    initialConversationId: String?,
    initialCallId: String?,
    initialDialNumber: String?,
    onConsumeInitialDialNumber: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val viewModel: BravViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                val crypto = E2eeCryptoManager(app)
                val localDb = BravLocalDatabase.getInstance(app)
                val callRepo = CallRepository(db, workerApiClient)
                BravViewModel(
                    currentUserId = currentUserId,
                    userRepository = UserRepository(db, crypto, workerApiClient),
                    contactRepository = ContactSyncRepository(db, workerApiClient, app),
                    chatRepository = ChatRepository(db, workerApiClient, crypto, localDb),
                    callRepository = callRepo,
                    socialRepository = SocialRepository(db, workerApiClient, crypto),
                    aiTranslationRepository = AiTranslationRepository(),
                    prefsRepository = prefsRepository,
                    workerApiClient = workerApiClient,
                    realtimeClient = realtimeClient,
                    voicePlayer = VoiceRecorderPlayer(app, workerApiClient),
                    webRtcCallManager = WebRtcCallManager(app, workerApiClient, callRepo),
                    appContext = app
                )
            }
        }
    )

    var showDialerSheet by remember { mutableStateOf(false) }
    var dialerInitialNumber by remember { mutableStateOf("") }

    LaunchedEffect(currentUserId, userEmail) {
        viewModel.checkAdmin(userEmail)
    }
    LaunchedEffect(initialCallId) {
        viewModel.handleDeepLinkCall(initialCallId)
    }
    LaunchedEffect(initialDialNumber) {
        if (initialDialNumber != null) {
            dialerInitialNumber = initialDialNumber
            showDialerSheet = true
            onConsumeInitialDialNumber()
        }
    }

    val notifPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val defaultDialerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (DefaultDialerHelper.isBravDefaultDialer(context)) {
            viewModel.showMessage("BRAV Chat est maintenant votre compositeur par défaut")
        }
    }

    fun requestDefaultDialer() {
        if (DefaultDialerHelper.isBravDefaultDialer(context)) {
            viewModel.showMessage("BRAV Chat est déjà le compositeur par défaut")
            return
        }
        val intent = DefaultDialerHelper.createRequestDefaultDialerIntent(context)
        if (intent != null) {
            runCatching { defaultDialerLauncher.launch(intent) }
                .onFailure { viewModel.showMessage("Impossible d'ouvrir les paramètres de compositeur") }
        } else {
            viewModel.showMessage("Compositeur par défaut non pris en charge sur cet appareil")
        }
    }

    var currentTab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var secondaryRoute by remember {
        mutableStateOf<SecondaryRoute>(
            if (!initialConversationId.isNullOrBlank()) SecondaryRoute.Conversation(initialConversationId)
            else SecondaryRoute.None
        )
    }

    val snackbarHostState = remember { SnackbarHostState() }
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val prefsMap by viewModel.conversationPrefs.collectAsStateWithLifecycle()
    val presenceMap by viewModel.presenceMap.collectAsStateWithLifecycle()
    val typingMap by viewModel.typingConversations.collectAsStateWithLifecycle()
    val savedContacts by viewModel.savedContactUsers.collectAsStateWithLifecycle()
    val phoneContacts by viewModel.phoneContacts.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val calls by viewModel.callHistory.collectAsStateWithLifecycle()
    val incomingCall by viewModel.incomingCall.collectAsStateWithLifecycle()
    val incomingCallPeer by viewModel.incomingCallPeer.collectAsStateWithLifecycle()
    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()
    val activeCallPeer by viewModel.activeCallPeer.collectAsStateWithLifecycle()
    val terminalCallState by viewModel.terminalCallState.collectAsStateWithLifecycle()
    val carrierCallState by CarrierCallController.uiState.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val appPrefs by viewModel.appPrefs.collectAsStateWithLifecycle()

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = secondaryRoute,
            transitionSpec = { fadeIn(tween(190)) togetherWith fadeOut(tween(150)) },
            label = "secondary_route_transition"
        ) { sec ->
            when (sec) {
                is SecondaryRoute.Conversation -> {
                    ChatConversationScreen(
                        conversationId = sec.conversationId,
                        viewModel = viewModel,
                        onBack = { secondaryRoute = SecondaryRoute.None }
                    )
                }
                SecondaryRoute.Statuses -> {
                    StatusesScreen(
                        viewModel = viewModel,
                        onOpenConversation = { cid -> secondaryRoute = SecondaryRoute.Conversation(cid) },
                        onBack = { secondaryRoute = SecondaryRoute.None }
                    )
                }
                SecondaryRoute.LiveMap -> {
                    LiveMapScreen(
                        viewModel = viewModel,
                        onBack = { secondaryRoute = SecondaryRoute.None }
                    )
                }
                SecondaryRoute.Offers -> {
                    OffersMarketplaceScreen(
                        viewModel = viewModel,
                        onOpenConversation = { cid -> secondaryRoute = SecondaryRoute.Conversation(cid) },
                        onBack = { secondaryRoute = SecondaryRoute.None }
                    )
                }
                SecondaryRoute.Admin -> {
                    AdminModerationScreen(
                        viewModel = viewModel,
                        onBack = { secondaryRoute = SecondaryRoute.None }
                    )
                }
                SecondaryRoute.Settings -> {
                    SettingsScreen(
                        viewModel = viewModel,
                        isAdmin = isAdmin,
                        onBack = { secondaryRoute = SecondaryRoute.None },
                        onOpenProfile = {
                            secondaryRoute = SecondaryRoute.None
                            currentTab = MainTab.PROFILE
                        },
                        onOpenOffers = { secondaryRoute = SecondaryRoute.Offers },
                        onOpenAdmin = { secondaryRoute = SecondaryRoute.Admin },
                        onSignOut = onSignOut
                    )
                }
                SecondaryRoute.None -> {
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val useRail = maxWidth >= 600.dp
                        Scaffold(
                            snackbarHost = { SnackbarHost(snackbarHostState) },
                            bottomBar = {
                                if (!useRail) {
                                    NavigationBar {
                                        MainTab.entries.forEach { tab ->
                                            NavigationBarItem(
                                                selected = currentTab == tab,
                                                onClick = { currentTab = tab },
                                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                                label = { Text(tab.label, maxLines = 1) }
                                            )
                                        }
                                    }
                                }
                            }
                        ) { innerPadding ->
                            Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                                if (useRail) {
                                    NavigationRail(
                                        header = { BravLogoMark(size = 34.dp) }
                                    ) {
                                        MainTab.entries.forEach { tab ->
                                            NavigationRailItem(
                                                selected = currentTab == tab,
                                                onClick = { currentTab = tab },
                                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                                label = { Text(tab.label) }
                                            )
                                        }
                                        NavigationRailItem(
                                            selected = false,
                                            onClick = {
                                                dialerInitialNumber = ""
                                                showDialerSheet = true
                                            },
                                            icon = { Icon(Icons.Rounded.Dialpad, contentDescription = "Clavier") },
                                            label = { Text("Clavier") }
                                        )
                                        NavigationRailItem(
                                            selected = false,
                                            onClick = { secondaryRoute = SecondaryRoute.Settings },
                                            icon = { Icon(Icons.Rounded.Settings, contentDescription = "Paramètres") },
                                            label = { Text("Paramètres") }
                                        )
                                    }
                                }
                                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                                    AnimatedContent(
                                        targetState = currentTab,
                                        transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(120)) },
                                        label = "main_tab_transition"
                                    ) { tab ->
                                        when (tab) {
                                            MainTab.HOME -> HomeDashboardScreen(
                                                currentUserId = currentUserId,
                                                conversations = conversations,
                                                prefsMap = prefsMap,
                                                presenceMap = presenceMap,
                                                typingConversations = typingMap,
                                                savedContacts = savedContacts,
                                                hasPinConfigured = appPrefs.chatLockPinHash.isNotBlank(),
                                                isAdmin = isAdmin,
                                                compactLayout = appPrefs.compactLayoutEnabled,
                                                onVerifyPin = { pin -> viewModel.prefsRepository.verifyChatLockPin(pin) },
                                                onOpenConversation = { cid -> secondaryRoute = SecondaryRoute.Conversation(cid) },
                                                onCreateGroup = { members, name, desc ->
                                                    scope.launch {
                                                        viewModel.createGroup(members, name, desc).onSuccess { conv ->
                                                            secondaryRoute = SecondaryRoute.Conversation(conv.id)
                                                        }
                                                    }
                                                },
                                                onJoinGroupByCode = { code ->
                                                    viewModel.joinGroupByCode(code) { cid ->
                                                        secondaryRoute = SecondaryRoute.Conversation(cid)
                                                    }
                                                },
                                                onUpdatePref = { cid, archived, pinned, muted, locked, unread, hidden ->
                                                    scope.launch {
                                                        viewModel.chatRepository.updateConversationPref(
                                                            myUid = currentUserId,
                                                            conversationId = cid,
                                                            archived = archived,
                                                            pinned = pinned,
                                                            muted = muted,
                                                            locked = locked,
                                                            markedUnread = unread,
                                                            hiddenLocally = hidden
                                                        )
                                                    }
                                                },
                                                onDeleteConversation = { cid -> viewModel.deleteConversation(cid) },
                                                onNavigateToContacts = { currentTab = MainTab.CONTACTS },
                                                onOpenStatuses = { currentTab = MainTab.STATUSES },
                                                onOpenDialer = {
                                                    dialerInitialNumber = ""
                                                    showDialerSheet = true
                                                },
                                                onRequestDefaultDialer = { requestDefaultDialer() },
                                                onOpenMap = { secondaryRoute = SecondaryRoute.LiveMap },
                                                onOpenOffers = { secondaryRoute = SecondaryRoute.Offers },
                                                onOpenProfile = { currentTab = MainTab.PROFILE },
                                                onOpenSettings = { secondaryRoute = SecondaryRoute.Settings },
                                                onOpenAdmin = { secondaryRoute = SecondaryRoute.Admin }
                                            )
                                            MainTab.STATUSES -> StatusesScreen(
                                                viewModel = viewModel,
                                                onOpenConversation = { cid -> secondaryRoute = SecondaryRoute.Conversation(cid) },
                                                onBack = null
                                            )
                                            MainTab.CONTACTS -> ContactsScreen(
                                                viewModel = viewModel,
                                                onOpenConversation = { cid -> secondaryRoute = SecondaryRoute.Conversation(cid) }
                                            )
                                            MainTab.CALLS -> CallHistoryScreen(
                                                currentUserId = currentUserId,
                                                calls = calls,
                                                savedContacts = savedContacts,
                                                onStartAudioCall = { pUid, pName -> viewModel.startOutgoingCall(pUid, pName, isVideo = false) },
                                                onStartVideoCall = { pUid, pName -> viewModel.startOutgoingCall(pUid, pName, isVideo = true) },
                                                onOpenDialer = {
                                                    dialerInitialNumber = ""
                                                    showDialerSheet = true
                                                },
                                                onDeleteCall = { callId -> viewModel.deleteCallHistoryItem(callId) },
                                                onClearHistory = { viewModel.clearAllCallHistory() }
                                            )
                                            MainTab.PROFILE -> ProfileScreen(
                                                viewModel = viewModel,
                                                onOpenSettings = { secondaryRoute = SecondaryRoute.Settings }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showDialerSheet) {
            DialerModalSheet(
                initialNumber = dialerInitialNumber,
                savedContacts = savedContacts,
                phoneContacts = phoneContacts,
                searchedUsers = searchResults,
                onLookupNumber = { q -> viewModel.searchUsers(q) },
                onStartBravAudioCall = { pUid, pName -> viewModel.startOutgoingCall(pUid, pName, isVideo = false) },
                onStartBravVideoCall = { pUid, pName -> viewModel.startOutgoingCall(pUid, pName, isVideo = true) },
                onFeedback = { msg -> viewModel.showMessage(msg) },
                onDismiss = { showDialerSheet = false }
            )
        }

        // Incoming call full-screen overlay when no active call is open
        incomingCall?.let { incoming ->
            if (activeCall == null) {
                IncomingCallBannerDialog(
                    call = incoming,
                    peerUser = incomingCallPeer,
                    soundEnabled = appPrefs.notificationsEnabled && appPrefs.notifySoundEnabled,
                    vibrationEnabled = appPrefs.notificationsEnabled && appPrefs.notifyVibrationEnabled,
                    onAccept = { viewModel.acceptIncomingCall(incoming) },
                    onReject = { viewModel.rejectIncomingCall(incoming) }
                )
            }
        }

        // Full-screen active WebRTC audio/video CallScreen
        activeCall?.let { call ->
            CallScreen(
                call = call,
                currentUserId = currentUserId,
                peerUser = activeCallPeer,
                appPrefs = appPrefs,
                webRtcCallManager = viewModel.webRtcCallManager,
                onToggleHold = { viewModel.toggleCallHold() },
                onHangup = { viewModel.endActiveCall(missed = call.status == "calling") }
            )
        }

        // Native GSM/Telecom InCallService overlay when acting as default dialer
        if (carrierCallState.hasCall && activeCall == null && incomingCall == null) {
            CarrierCallOverlay(state = carrierCallState)
        }

        // Brief terminal call status overlay (Terminé / Refusé / Aucune réponse)
        terminalCallState?.let { (endedCall, reason) ->
            if (activeCall == null && incomingCall == null) {
                val peerUid = if (endedCall.callerId == currentUserId) endedCall.receiverId else endedCall.callerId
                val endedPeer = savedContacts.firstOrNull { it.userId == peerUid }
                CallTerminalOverlay(
                    call = endedCall,
                    reason = reason,
                    currentUserId = currentUserId,
                    peerUser = endedPeer,
                    onDismiss = { viewModel.dismissTerminalCallBanner() }
                )
            }
        }
    }
}
