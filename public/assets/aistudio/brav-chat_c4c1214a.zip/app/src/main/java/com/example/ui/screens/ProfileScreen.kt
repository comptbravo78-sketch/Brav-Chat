package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.LocationCity
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.UserAvatarWithStatus
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed
import com.example.ui.theme.StatusOnlineGreen
import com.example.viewmodel.BravViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class PendingPhotoPreview(
    val uri: Uri,
    val bytes: ByteArray,
    val mimeType: String
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    viewModel: BravViewModel,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val privateInfo by viewModel.privateInfo.collectAsStateWithLifecycle()
    val firebaseEmail = remember { Firebase.auth.currentUser?.email.orEmpty() }

    var displayName by remember(currentUser?.displayName) { mutableStateOf(currentUser?.displayName.orEmpty()) }
    var username by remember(currentUser?.username) { mutableStateOf(currentUser?.username.orEmpty()) }
    var bio by remember(currentUser?.bio) { mutableStateOf(currentUser?.bio.orEmpty()) }
    var locationCity by remember(currentUser?.locationCity) { mutableStateOf(currentUser?.locationCity.orEmpty()) }
    var locationDetails by remember(currentUser?.locationDetails) { mutableStateOf(currentUser?.locationDetails.orEmpty()) }
    var phone by remember(privateInfo?.phoneNumber) { mutableStateOf(privateInfo?.phoneNumber.orEmpty()) }
    var email by remember(privateInfo?.email, firebaseEmail) {
        mutableStateOf(privateInfo?.email.orEmpty().ifBlank { firebaseEmail })
    }

    var fieldErrors by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var isSavingProfile by remember { mutableStateOf(false) }
    var saveSuccessBanner by remember { mutableStateOf(false) }
    var isUploadingPhoto by remember { mutableStateOf(false) }
    var pendingPreview by remember { mutableStateOf<PendingPhotoPreview?>(null) }
    var showRemovePhotoConfirm by remember { mutableStateOf(false) }

    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
            val rawBytes = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            }
            if (rawBytes == null || rawBytes.isEmpty()) {
                viewModel.showMessage("Impossible de lire l'image sélectionnée.")
                return@launch
            }
            val (uploadBytes, uploadMime) = compressProfileImageIfNeeded(rawBytes, mime)
            pendingPreview = PendingPhotoPreview(uri = uri, bytes = uploadBytes, mimeType = uploadMime)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header bar with navigation to dedicated Settings screen
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Mon profil",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Identité publique, coordonnées et compte BRAV CHAT",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(
                    onClick = onOpenSettings,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("profile_open_settings_button")
                ) {
                    Icon(Icons.Rounded.Settings, contentDescription = "Ouvrir les paramètres", modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Paramètres")
                }
            }
        }

        // Section C + A top card: Photo management + Identity summary + Availability
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            UserAvatarWithStatus(
                                name = currentUser?.displayName.orEmpty().ifBlank { "Membre BRAV" },
                                avatarUrl = currentUser?.avatarUrl.orEmpty(),
                                availabilityStatus = currentUser?.availabilityStatus ?: "online",
                                size = 78.dp
                            )
                            Surface(
                                shape = CircleShape,
                                color = BravPurple,
                                onClick = {
                                    avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                modifier = Modifier
                                    .size(30.dp)
                                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
                                    .testTag("change_profile_photo_button")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Rounded.PhotoCamera,
                                        contentDescription = "Choisir une photo de profil",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentUser?.displayName.orEmpty().ifBlank { "Membre BRAV" },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val handle = currentUser?.username.orEmpty()
                            if (handle.isNotBlank()) {
                                Text(
                                    text = "@$handle",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = BravPurple,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            if (locationCity.isNotBlank()) {
                                Text(
                                    text = listOf(locationCity, locationDetails).filter { it.isNotBlank() }.joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            enabled = !isUploadingPhoto,
                            modifier = Modifier.weight(1f).testTag("pick_photo_button")
                        ) {
                            if (isUploadingPhoto) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(6.dp))
                            } else {
                                Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(17.dp))
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(if (currentUser?.avatarUrl.isNullOrBlank()) "Ajouter une photo" else "Modifier photo")
                        }
                        if (!currentUser?.avatarUrl.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = { showRemovePhotoConfirm = true },
                                enabled = !isUploadingPhoto,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = BravRed),
                                modifier = Modifier.testTag("remove_photo_button")
                            ) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Supprimer la photo", modifier = Modifier.size(17.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Supprimer")
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    Text(
                        text = "Disponibilité visible",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "online" to "En ligne",
                            "busy" to "Occupé",
                            "dnd" to "Ne pas déranger",
                            "invisible" to "Invisible",
                            "offline" to "Hors ligne"
                        ).forEach { (key, label) ->
                            FilterChip(
                                selected = currentUser?.availabilityStatus == key,
                                onClick = {
                                    scope.launch {
                                        viewModel.userRepository.updateAvailabilityStatus(viewModel.currentUserId, key)
                                    }
                                },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }
        }

        // Section A + D: Identité personnelle & modification structurée
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SectionHeaderRow(
                        icon = Icons.Rounded.Person,
                        title = "Identité personnelle",
                        subtitle = "Ces informations permettent à vos contacts de vous reconnaître pendant les échanges et appels."
                    )

                    OutlinedTextField(
                        value = displayName,
                        onValueChange = {
                            displayName = it
                            saveSuccessBanner = false
                            fieldErrors = fieldErrors - "displayName"
                        },
                        label = { Text("Nom et prénoms *") },
                        leadingIcon = { Icon(Icons.Rounded.Badge, contentDescription = null) },
                        isError = fieldErrors.containsKey("displayName"),
                        supportingText = fieldErrors["displayName"]?.let { err -> { Text(err) } },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("profile_display_name_input")
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = {
                            username = it
                            saveSuccessBanner = false
                            fieldErrors = fieldErrors - "username"
                        },
                        label = { Text("Nom d'utilisateur unique (@username)") },
                        leadingIcon = { Icon(Icons.Rounded.AlternateEmail, contentDescription = null) },
                        isError = fieldErrors.containsKey("username"),
                        supportingText = fieldErrors["username"]?.let { err -> { Text(err) } }
                            ?: { Text("Lettres minuscules, chiffres, points ou tirets (min. 3 caractères)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("profile_username_input")
                    )

                    OutlinedTextField(
                        value = bio,
                        onValueChange = {
                            bio = it
                            saveSuccessBanner = false
                            fieldErrors = fieldErrors - "bio"
                        },
                        label = { Text("Biographie / description personnelle") },
                        isError = fieldErrors.containsKey("bio"),
                        supportingText = {
                            Text(fieldErrors["bio"] ?: "${bio.trim().length}/300 caractères")
                        },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth().testTag("profile_bio_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = locationCity,
                            onValueChange = {
                                locationCity = it
                                saveSuccessBanner = false
                            },
                            label = { Text("Ville") },
                            leadingIcon = { Icon(Icons.Rounded.LocationCity, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("profile_city_input")
                        )
                        OutlinedTextField(
                            value = locationDetails,
                            onValueChange = {
                                locationDetails = it
                                saveSuccessBanner = false
                            },
                            label = { Text("Quartier / Pays") },
                            leadingIcon = { Icon(Icons.Rounded.LocationOn, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("profile_location_details_input")
                        )
                    }
                }
            }
        }

        // Section Coordonnées privées + Enregistrement
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SectionHeaderRow(
                        icon = Icons.Rounded.Phone,
                        title = "Coordonnées de contact",
                        subtitle = "Stockées dans votre espace privé chiffré et indexées par hachage sécurisé."
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = {
                            phone = it
                            saveSuccessBanner = false
                            fieldErrors = fieldErrors - "phone"
                        },
                        label = { Text("Numéro de téléphone") },
                        leadingIcon = { Icon(Icons.Rounded.Phone, contentDescription = null) },
                        isError = fieldErrors.containsKey("phone"),
                        supportingText = fieldErrors["phone"]?.let { err -> { Text(err) } },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("profile_phone_input")
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            saveSuccessBanner = false
                            fieldErrors = fieldErrors - "email"
                        },
                        label = { Text("Adresse e-mail") },
                        leadingIcon = { Icon(Icons.Rounded.Email, contentDescription = null) },
                        isError = fieldErrors.containsKey("email"),
                        supportingText = fieldErrors["email"]?.let { err -> { Text(err) } },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("profile_email_input")
                    )

                    AnimatedVisibility(visible = saveSuccessBanner) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = StatusOnlineGreen.copy(alpha = 0.14f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = StatusOnlineGreen)
                                Text(
                                    text = "Modifications enregistrées et synchronisées avec Firebase.",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StatusOnlineGreen
                                )
                            }
                        }
                    }

                    Button(
                        enabled = !isSavingProfile,
                        onClick = {
                            val validation = viewModel.userRepository.validateProfileInput(
                                displayName = displayName,
                                username = username,
                                bio = bio,
                                phoneNumber = phone,
                                email = email
                            )
                            if (!validation.isValid) {
                                fieldErrors = validation.fieldErrors
                                viewModel.showMessage(validation.fieldErrors.values.firstOrNull() ?: "Vérifiez les champs du profil")
                                return@Button
                            }
                            isSavingProfile = true
                            saveSuccessBanner = false
                            scope.launch {
                                val res = viewModel.userRepository.updateProfile(
                                    uid = viewModel.currentUserId,
                                    displayName = displayName,
                                    username = username,
                                    bio = bio,
                                    locationCity = locationCity,
                                    locationDetails = locationDetails,
                                    phoneNumber = phone,
                                    email = email
                                )
                                isSavingProfile = false
                                if (res.isSuccess) {
                                    fieldErrors = emptyMap()
                                    saveSuccessBanner = true
                                    viewModel.showMessage("Profil enregistré avec succès")
                                } else {
                                    val msg = res.exceptionOrNull()?.localizedMessage ?: "Échec d'enregistrement"
                                    if (msg.contains("utilisateur", ignoreCase = true)) {
                                        fieldErrors = fieldErrors + ("username" to msg)
                                    }
                                    viewModel.showMessage(msg)
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BravPurple, contentColor = Color.White),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_profile_button")
                    ) {
                        if (isSavingProfile) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                        } else {
                            Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                        }
                        Text("Enregistrer les modifications", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section B: Informations du compte
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SectionHeaderRow(
                        icon = Icons.Rounded.VerifiedUser,
                        title = "Informations du compte",
                        subtitle = "Données techniques et état d'enregistrement de votre compte."
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Identifiant utilisateur (UID)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = viewModel.currentUserId,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            cm?.setPrimaryClip(ClipData.newPlainText("BRAV UID", viewModel.currentUserId))
                            viewModel.showMessage("Identifiant copié")
                        }) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier l'identifiant utilisateur")
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    val createdFormatted = currentUser?.createdAt?.let { ts ->
                        SimpleDateFormat("dd MMMM yyyy à HH:mm", Locale.FRENCH).format(Date(ts.seconds * 1000L))
                    } ?: "Synchronisation en cours..."
                    AccountMetaRow("Date de création", createdFormatted)

                    val accountStatus = when {
                        currentUser?.isSuspended == true -> "Suspendu"
                        else -> "Actif • ${availabilityLabel(currentUser?.availabilityStatus ?: "online")}"
                    }
                    AccountMetaRow("Statut du compte", accountStatus)

                    val roleLabel = if (currentUser?.role == "provider") "Prestataire" else "Membre standard"
                    AccountMetaRow("Type de compte", roleLabel)
                    AccountMetaRow("Authentification", "Google Sign-In vérifié")

                    val savedEmail = privateInfo?.email.orEmpty().ifBlank { firebaseEmail.ifBlank { "Non renseignée" } }
                    val savedPhone = privateInfo?.phoneNumber.orEmpty().ifBlank { "Non renseigné" }
                    AccountMetaRow("E-mail enregistré", savedEmail)
                    AccountMetaRow("Téléphone enregistré", savedPhone)

                    val pubKey = currentUser?.publicKey.orEmpty()
                    if (pubKey.isNotBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.Key, contentDescription = null, tint = StatusOnlineGreen, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Clé E2EE active : ${pubKey.take(16)}...",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    // Aperçu avant validation de la photo de profil
    pendingPreview?.let { preview ->
        val previewBitmap = remember(preview.bytes) {
            runCatching {
                BitmapFactory.decodeByteArray(preview.bytes, 0, preview.bytes.size)?.asImageBitmap()
            }.getOrNull()
        }
        AlertDialog(
            onDismissRequest = { if (!isUploadingPhoto) pendingPreview = null },
            title = { Text("Aperçu de votre photo", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (previewBitmap != null) {
                        Image(
                            bitmap = previewBitmap,
                            contentDescription = "Aperçu nouvelle photo de profil",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(156.dp)
                                .clip(CircleShape)
                                .border(2.5.dp, BravPurple, CircleShape)
                        )
                    } else {
                        Box(
                            modifier = Modifier.size(156.dp).clip(CircleShape).background(BravPurple.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.PhotoCamera, contentDescription = null, tint = BravPurple, modifier = Modifier.size(44.dp))
                        }
                    }
                    Text(
                        text = "Cette photo sera visible par vos contacts lors des discussions et pendant les appels audio et vidéo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = !isUploadingPhoto,
                    colors = ButtonDefaults.buttonColors(containerColor = BravPurple, contentColor = Color.White),
                    onClick = {
                        val uid = viewModel.currentUserId
                        isUploadingPhoto = true
                        scope.launch {
                            val up = viewModel.workerApiClient.uploadMedia(
                                conversationId = "profile_$uid",
                                bytes = preview.bytes,
                                mimeType = preview.mimeType,
                                fileName = "avatar_$uid.jpg"
                            )
                            up.onSuccess { res ->
                                val updateRes = viewModel.userRepository.updateProfile(
                                    uid = uid,
                                    displayName = displayName.ifBlank { currentUser?.displayName.orEmpty().ifBlank { "Membre BRAV" } },
                                    username = username.ifBlank { currentUser?.username.orEmpty() },
                                    bio = bio,
                                    locationCity = locationCity,
                                    locationDetails = locationDetails,
                                    avatarUrl = res.url
                                )
                                isUploadingPhoto = false
                                pendingPreview = null
                                if (updateRes.isSuccess) {
                                    viewModel.showMessage("Photo de profil mise à jour")
                                } else {
                                    viewModel.showMessage(updateRes.exceptionOrNull()?.localizedMessage ?: "Échec sauvegarde photo")
                                }
                            }.onFailure { err ->
                                isUploadingPhoto = false
                                pendingPreview = null
                                viewModel.showMessage(err.localizedMessage ?: "Échec upload photo")
                            }
                        }
                    },
                    modifier = Modifier.testTag("confirm_photo_upload_button")
                ) {
                    if (isUploadingPhoto) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(Modifier.width(6.dp))
                    }
                    Text("Valider la photo")
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isUploadingPhoto,
                    onClick = { pendingPreview = null }
                ) {
                    Text("Annuler")
                }
            }
        )
    }

    if (showRemovePhotoConfirm) {
        AlertDialog(
            onDismissRequest = { showRemovePhotoConfirm = false },
            title = { Text("Supprimer la photo de profil ?") },
            text = { Text("Vos initiales s'afficheront à la place de votre photo sur votre profil et pendant vos appels.") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = BravRed, contentColor = Color.White),
                    onClick = {
                        showRemovePhotoConfirm = false
                        viewModel.removeProfilePhoto()
                    }
                ) { Text("Supprimer") }
            },
            dismissButton = {
                TextButton(onClick = { showRemovePhotoConfirm = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
private fun SectionHeaderRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = BravPurple.copy(alpha = 0.12f),
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = BravPurple, modifier = Modifier.size(20.dp))
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AccountMetaRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private fun availabilityLabel(status: String): String = when (status) {
    "online" -> "En ligne"
    "busy" -> "Occupé"
    "dnd" -> "Ne pas déranger"
    "invisible" -> "Invisible"
    else -> "Hors ligne"
}

private suspend fun compressProfileImageIfNeeded(rawBytes: ByteArray, mimeType: String): Pair<ByteArray, String> =
    withContext(Dispatchers.IO) {
        if (rawBytes.size <= 450 * 1024) return@withContext rawBytes to mimeType
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, bounds)
        var sampleSize = 1
        while (bounds.outWidth / sampleSize > 1024 || bounds.outHeight / sampleSize > 1024) {
            sampleSize *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, opts)
            ?: return@withContext rawBytes to mimeType
        val out = ByteArrayOutputStream()
        decoded.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
        decoded.recycle()
        out.toByteArray() to "image/jpeg"
    }
