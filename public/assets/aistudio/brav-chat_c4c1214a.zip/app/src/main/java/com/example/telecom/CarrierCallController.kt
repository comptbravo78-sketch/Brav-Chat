package com.example.telecom

import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CarrierCallUiState(
    val hasCall: Boolean = false,
    val number: String = "",
    val callerDisplayName: String = "",
    val state: Int = Call.STATE_DISCONNECTED,
    val connectTimeMillis: Long = 0L,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false
) {
    val isRinging: Boolean
        get() = state == Call.STATE_RINGING

    val isActive: Boolean
        get() = state == Call.STATE_ACTIVE

    val isHolding: Boolean
        get() = state == Call.STATE_HOLDING

    val statusLabel: String
        get() = when (state) {
            Call.STATE_RINGING -> "Appel entrant"
            Call.STATE_DIALING -> "Numérotation..."
            Call.STATE_CONNECTING -> "Connexion..."
            Call.STATE_ACTIVE -> "En communication"
            Call.STATE_HOLDING -> "En attente"
            Call.STATE_DISCONNECTING -> "Raccrochage..."
            else -> "Terminé"
        }
}

object CarrierCallController {
    private val _uiState = MutableStateFlow(CarrierCallUiState())
    val uiState: StateFlow<CarrierCallUiState> = _uiState.asStateFlow()

    @Volatile
    private var currentCall: Call? = null

    @Volatile
    private var serviceRef: BravInCallService? = null

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            publish(call, state)
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            val state = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                call.details.state
            } else {
                @Suppress("DEPRECATION")
                call.state
            }
            publish(call, state)
        }
    }

    internal fun attachService(service: BravInCallService) {
        serviceRef = service
    }

    internal fun detachService(service: BravInCallService) {
        if (serviceRef === service) {
            serviceRef = null
        }
    }

    internal fun onCallAdded(call: Call) {
        currentCall?.unregisterCallback(callback)
        currentCall = call
        call.registerCallback(callback)
        val initialState = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            call.details.state
        } else {
            @Suppress("DEPRECATION")
            call.state
        }
        publish(call, initialState)
    }

    internal fun onCallRemoved(call: Call) {
        call.unregisterCallback(callback)
        if (currentCall === call) {
            currentCall = null
            _uiState.value = CarrierCallUiState()
        }
    }

    internal fun onAudioStateChanged(isMuted: Boolean, route: Int) {
        _uiState.value = _uiState.value.copy(
            isMuted = isMuted,
            isSpeakerOn = route == CallAudioState.ROUTE_SPEAKER
        )
    }

    fun answer() {
        currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }

    fun rejectOrHangup() {
        val call = currentCall ?: return
        val state = _uiState.value.state
        if (state == Call.STATE_RINGING) {
            call.reject(false, null)
        } else {
            call.disconnect()
        }
    }

    fun toggleHold() {
        val call = currentCall ?: return
        if (_uiState.value.isHolding) call.unhold() else call.hold()
    }

    fun toggleMute() {
        val next = !_uiState.value.isMuted
        serviceRef?.setMuted(next)
        _uiState.value = _uiState.value.copy(isMuted = next)
    }

    fun toggleSpeaker() {
        val nextSpeaker = !_uiState.value.isSpeakerOn
        val route = if (nextSpeaker) {
            CallAudioState.ROUTE_SPEAKER
        } else {
            CallAudioState.ROUTE_EARPIECE or CallAudioState.ROUTE_BLUETOOTH or CallAudioState.ROUTE_WIRED_HEADSET
        }
        serviceRef?.setAudioRoute(route)
        _uiState.value = _uiState.value.copy(isSpeakerOn = nextSpeaker)
    }

    fun playDtmf(digit: Char) {
        val call = currentCall ?: return
        call.playDtmfTone(digit)
        call.stopDtmfTone()
    }

    private fun publish(call: Call, state: Int) {
        if (state == Call.STATE_DISCONNECTED) {
            _uiState.value = CarrierCallUiState()
            return
        }
        val details = call.details
        val handleNumber = details?.handle?.schemeSpecificPart.orEmpty()
        val displayName = details?.callerDisplayName.orEmpty().ifBlank {
            details?.contactDisplayName.orEmpty()
        }
        val connectTime = details?.connectTimeMillis ?: 0L
        val current = _uiState.value
        _uiState.value = current.copy(
            hasCall = true,
            number = handleNumber,
            callerDisplayName = displayName,
            state = state,
            connectTimeMillis = connectTime
        )
    }
}
