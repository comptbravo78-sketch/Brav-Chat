package com.example.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.File
import java.security.MessageDigest
import java.util.UUID

private val Context.bravPrefsDataStore: DataStore<Preferences> by preferencesDataStore(name = "brav_chat_prefs")

enum class ThemeMode(val key: String, val label: String) {
    SYSTEM("system", "Système"),
    LIGHT("light", "Clair"),
    DARK("dark", "Sombre");

    companion object {
        fun fromKey(key: String?): ThemeMode = entries.firstOrNull { it.key == key } ?: SYSTEM
    }
}

data class AppPreferencesState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val compactLayoutEnabled: Boolean = false,
    val dataSaverEnabled: Boolean = false,
    val autoDownloadWifiOnly: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val notifyMessages: Boolean = true,
    val notifyCalls: Boolean = true,
    val notifyMissedCalls: Boolean = true,
    val notifyGroups: Boolean = true,
    val notifyStatuses: Boolean = true,
    val notifySoundEnabled: Boolean = true,
    val notifyVibrationEnabled: Boolean = true,
    val hideNotificationContent: Boolean = false,
    val noiseSuppressionEnabled: Boolean = true,
    val echoCancellationEnabled: Boolean = true,
    val autoGainControlEnabled: Boolean = true,
    val voicePriorityEnabled: Boolean = true,
    val defaultSpeakerAudio: Boolean = false,
    val startCallMuted: Boolean = false,
    val chatLockPinHash: String = "",
    val deviceId: String = ""
)

class AppPreferencesRepository(private val context: Context) {

    private val dataStore = context.applicationContext.bravPrefsDataStore

    val state: Flow<AppPreferencesState> = dataStore.data.map { prefs ->
        AppPreferencesState(
            themeMode = ThemeMode.fromKey(prefs[KEY_THEME_MODE]),
            compactLayoutEnabled = prefs[KEY_COMPACT_LAYOUT] ?: false,
            dataSaverEnabled = prefs[KEY_DATA_SAVER] ?: false,
            autoDownloadWifiOnly = prefs[KEY_WIFI_ONLY_MEDIA] ?: true,
            notificationsEnabled = prefs[KEY_NOTIF_MASTER] ?: true,
            notifyMessages = prefs[KEY_NOTIFY_MESSAGES] ?: true,
            notifyCalls = prefs[KEY_NOTIFY_CALLS] ?: true,
            notifyMissedCalls = prefs[KEY_NOTIFY_MISSED_CALLS] ?: true,
            notifyGroups = prefs[KEY_NOTIFY_GROUPS] ?: true,
            notifyStatuses = prefs[KEY_NOTIFY_STATUSES] ?: true,
            notifySoundEnabled = prefs[KEY_NOTIFY_SOUND] ?: true,
            notifyVibrationEnabled = prefs[KEY_NOTIFY_VIBRATION] ?: true,
            hideNotificationContent = prefs[KEY_HIDE_NOTIF_CONTENT] ?: false,
            noiseSuppressionEnabled = prefs[KEY_NOISE_SUPPRESSION] ?: true,
            echoCancellationEnabled = prefs[KEY_ECHO_CANCELLATION] ?: true,
            autoGainControlEnabled = prefs[KEY_AUTO_GAIN_CONTROL] ?: true,
            voicePriorityEnabled = prefs[KEY_VOICE_PRIORITY] ?: true,
            defaultSpeakerAudio = prefs[KEY_DEFAULT_SPEAKER_AUDIO] ?: false,
            startCallMuted = prefs[KEY_START_CALL_MUTED] ?: false,
            chatLockPinHash = prefs[KEY_LOCK_PIN_HASH] ?: "",
            deviceId = prefs[KEY_DEVICE_ID] ?: ""
        )
    }

    suspend fun getOrCreateDeviceId(): String {
        val current = dataStore.data.first()[KEY_DEVICE_ID]
        if (!current.isNullOrBlank()) return current
        val generated = "android_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        dataStore.edit { it[KEY_DEVICE_ID] = generated }
        return generated
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[KEY_THEME_MODE] = mode.key }
    }

    suspend fun setCompactLayout(enabled: Boolean) {
        dataStore.edit { it[KEY_COMPACT_LAYOUT] = enabled }
    }

    suspend fun setDataSaver(enabled: Boolean) {
        dataStore.edit { it[KEY_DATA_SAVER] = enabled }
    }

    suspend fun setAutoDownloadWifiOnly(enabled: Boolean) {
        dataStore.edit { it[KEY_WIFI_ONLY_MEDIA] = enabled }
    }

    suspend fun setNotificationSettings(
        master: Boolean? = null,
        messages: Boolean? = null,
        calls: Boolean? = null,
        missedCalls: Boolean? = null,
        groups: Boolean? = null,
        statuses: Boolean? = null,
        sound: Boolean? = null,
        vibration: Boolean? = null,
        hideContent: Boolean? = null
    ) {
        dataStore.edit { prefs ->
            master?.let { prefs[KEY_NOTIF_MASTER] = it }
            messages?.let { prefs[KEY_NOTIFY_MESSAGES] = it }
            calls?.let { prefs[KEY_NOTIFY_CALLS] = it }
            missedCalls?.let { prefs[KEY_NOTIFY_MISSED_CALLS] = it }
            groups?.let { prefs[KEY_NOTIFY_GROUPS] = it }
            statuses?.let { prefs[KEY_NOTIFY_STATUSES] = it }
            sound?.let { prefs[KEY_NOTIFY_SOUND] = it }
            vibration?.let { prefs[KEY_NOTIFY_VIBRATION] = it }
            hideContent?.let { prefs[KEY_HIDE_NOTIF_CONTENT] = it }
        }
    }

    suspend fun setCallAudioSettings(
        noiseSuppression: Boolean? = null,
        echoCancellation: Boolean? = null,
        autoGainControl: Boolean? = null,
        voicePriority: Boolean? = null,
        defaultSpeakerAudio: Boolean? = null,
        startMuted: Boolean? = null
    ) {
        dataStore.edit { prefs ->
            noiseSuppression?.let { prefs[KEY_NOISE_SUPPRESSION] = it }
            echoCancellation?.let { prefs[KEY_ECHO_CANCELLATION] = it }
            autoGainControl?.let { prefs[KEY_AUTO_GAIN_CONTROL] = it }
            voicePriority?.let { prefs[KEY_VOICE_PRIORITY] = it }
            defaultSpeakerAudio?.let { prefs[KEY_DEFAULT_SPEAKER_AUDIO] = it }
            startMuted?.let { prefs[KEY_START_CALL_MUTED] = it }
        }
    }

    suspend fun setChatLockPin(rawPin: String) {
        val hash = if (rawPin.isBlank()) "" else hashPin(rawPin)
        dataStore.edit { it[KEY_LOCK_PIN_HASH] = hash }
    }

    suspend fun verifyChatLockPin(rawPin: String): Boolean {
        val stored = dataStore.data.first()[KEY_LOCK_PIN_HASH].orEmpty()
        if (stored.isBlank()) return false
        return stored == hashPin(rawPin)
    }

    fun computeLocalCacheSizeBytes(): Long {
        fun dirSize(dir: File?): Long {
            if (dir == null || !dir.exists()) return 0L
            return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        }
        return dirSize(context.cacheDir) + dirSize(File(context.filesDir, "brav_media_cache"))
    }

    fun clearLocalMediaCache(): Long {
        var deleted = 0L
        listOf(context.cacheDir, File(context.filesDir, "brav_media_cache")).forEach { dir ->
            if (dir.exists()) {
                dir.listFiles()?.forEach { child ->
                    deleted += if (child.isFile) child.length() else child.walkTopDown().filter { it.isFile }.sumOf { it.length() }
                    child.deleteRecursively()
                }
            }
        }
        return deleted
    }

    private fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest("brav-pin-v1:$pin".toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private companion object {
        val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        val KEY_COMPACT_LAYOUT = booleanPreferencesKey("compact_layout")
        val KEY_DATA_SAVER = booleanPreferencesKey("data_saver")
        val KEY_WIFI_ONLY_MEDIA = booleanPreferencesKey("wifi_only_media")
        val KEY_NOTIF_MASTER = booleanPreferencesKey("notif_master")
        val KEY_NOTIFY_MESSAGES = booleanPreferencesKey("notify_messages")
        val KEY_NOTIFY_CALLS = booleanPreferencesKey("notify_calls")
        val KEY_NOTIFY_MISSED_CALLS = booleanPreferencesKey("notify_missed_calls")
        val KEY_NOTIFY_GROUPS = booleanPreferencesKey("notify_groups")
        val KEY_NOTIFY_STATUSES = booleanPreferencesKey("notify_statuses")
        val KEY_NOTIFY_SOUND = booleanPreferencesKey("notify_sound")
        val KEY_NOTIFY_VIBRATION = booleanPreferencesKey("notify_vibration")
        val KEY_HIDE_NOTIF_CONTENT = booleanPreferencesKey("hide_notif_content")
        val KEY_NOISE_SUPPRESSION = booleanPreferencesKey("call_noise_suppression")
        val KEY_ECHO_CANCELLATION = booleanPreferencesKey("call_echo_cancellation")
        val KEY_AUTO_GAIN_CONTROL = booleanPreferencesKey("call_auto_gain_control")
        val KEY_VOICE_PRIORITY = booleanPreferencesKey("call_voice_priority")
        val KEY_DEFAULT_SPEAKER_AUDIO = booleanPreferencesKey("call_default_speaker_audio")
        val KEY_START_CALL_MUTED = booleanPreferencesKey("call_start_muted")
        val KEY_LOCK_PIN_HASH = stringPreferencesKey("chat_lock_pin_hash")
        val KEY_DEVICE_ID = stringPreferencesKey("device_id")
    }
}
