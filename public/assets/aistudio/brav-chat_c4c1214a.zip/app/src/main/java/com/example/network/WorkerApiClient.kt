package com.example.network

import android.content.Context
import android.util.Log
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class WorkerApiClient {

    private val auth = Firebase.auth

    private val _cachedConfig = MutableStateFlow<WorkerConfig?>(null)
    val cachedConfig: StateFlow<WorkerConfig?> = _cachedConfig.asStateFlow()
    @Volatile
    private var lastConfigFetchMs: Long = 0L

    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()

    val mediaAuthorizedClient: OkHttpClient = httpClient.newBuilder()
        .addInterceptor { chain ->
            val original = chain.request()
            val url = original.url.toString()
            if (url.startsWith(WorkerConstants.BASE_URL)) {
                val token = fetchBlockingToken(forceRefresh = false)
                val req = if (!token.isNullOrBlank()) {
                    original.newBuilder().header("Authorization", "Bearer $token").build()
                } else {
                    original
                }
                val response = chain.proceed(req)
                if (response.code == 401) {
                    val refreshed = fetchBlockingToken(forceRefresh = true)
                    if (!refreshed.isNullOrBlank()) {
                        response.close()
                        val retryReq = original.newBuilder()
                            .header("Authorization", "Bearer $refreshed")
                            .build()
                        return@addInterceptor chain.proceed(retryReq)
                    }
                }
                return@addInterceptor response
            }
            chain.proceed(original)
        }
        .build()

    private fun fetchBlockingToken(forceRefresh: Boolean): String? {
        return runCatching {
            val user = auth.currentUser ?: return@runCatching null
            com.google.android.gms.tasks.Tasks.await(user.getIdToken(forceRefresh)).token
        }.getOrNull()
    }

    fun createCoilImageLoader(context: Context): ImageLoader {
        val appCtx = context.applicationContext
        return ImageLoader.Builder(appCtx)
            .okHttpClient(mediaAuthorizedClient)
            .memoryCache {
                MemoryCache.Builder(appCtx)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(appCtx.cacheDir, "brav_image_cache"))
                    .maxSizeBytes(64L * 1024L * 1024L)
                    .build()
            }
            .crossfade(true)
            .build()
    }

    suspend fun getFreshIdToken(forceRefresh: Boolean = false): String? {
        val user = auth.currentUser ?: return null
        return try {
            user.getIdToken(forceRefresh).await().token
        } catch (e: Exception) {
            Log.w(TAG, "Failed to get Firebase ID token: ${e.message}")
            null
        }
    }

    private suspend fun authorizedRequest(
        path: String,
        method: String = "GET",
        jsonBody: JSONObject? = null
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        try {
            var token = getFreshIdToken(false)
                ?: return@withContext Result.failure(IllegalStateException("Non authentifié"))
            var response = executeJsonRequest(path, method, jsonBody, token)
            if (response.first == 401) {
                token = getFreshIdToken(true) ?: token
                response = executeJsonRequest(path, method, jsonBody, token)
            }
            val (code, bodyText) = response
            val json = runCatching { JSONObject(bodyText) }.getOrElse { JSONObject() }
            if (code in 200..299) {
                Result.success(json)
            } else {
                val rawErr = json.optString("error", "HTTP_$code")
                Result.failure(IOException(formatWorkerError(rawErr, code)))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun formatWorkerError(errorCode: String, statusCode: Int): String {
        return when (errorCode) {
            "MEDIA_NOT_CONFIGURED" -> "Stockage R2 (bravchat) non activé sur le Worker Cloudflare."
            "USER_HUBS_BINDING_MISSING",
            "CALL_ROOMS_BINDING_MISSING" -> "Signalisation Worker non activée (bascule automatique active)."
            "SFU_NOT_CONFIGURED" -> "Cloudflare SFU non activé sur le Worker."
            "FILE_TOO_LARGE" -> "Fichier trop volumineux pour l'envoi."
            "UNSUPPORTED_MEDIA_TYPE" -> "Format de fichier non pris en charge."
            else -> "Worker ($statusCode): $errorCode"
        }
    }

    private fun executeJsonRequest(
        path: String,
        method: String,
        jsonBody: JSONObject?,
        token: String
    ): Pair<Int, String> {
        val url = if (path.startsWith("http")) path else "${WorkerConstants.BASE_URL}$path"
        val body: RequestBody? = when {
            method == "GET" || method == "HEAD" -> null
            jsonBody != null -> jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
            else -> "".toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
        }
        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .method(method, body)
            .build()
        httpClient.newCall(req).execute().use { res ->
            return res.code to (res.body?.string() ?: "{}")
        }
    }

    suspend fun getOrFetchConfig(forceRefresh: Boolean = false): WorkerConfig? {
        val current = _cachedConfig.value
        val fresh = System.currentTimeMillis() - lastConfigFetchMs < 60_000L
        if (!forceRefresh && current != null && fresh) return current
        return fetchConfig().getOrNull() ?: current
    }

    suspend fun fetchConfig(): Result<WorkerConfig> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("${WorkerConstants.BASE_URL}/v1/config").get().build()
            httpClient.newCall(req).execute().use { res ->
                val raw = res.body?.string() ?: "{}"
                if (!res.isSuccessful) return@withContext Result.failure(IOException("Config HTTP ${res.code}"))
                val j = JSONObject(raw)
                val hb = j.optJSONObject("heartbeat")
                val lim = j.optJSONObject("limits")
                val feat = j.optJSONObject("features")
                val mTypesArr = j.optJSONArray("mediaTypes")
                val mediaTypes = mutableListOf<String>()
                if (mTypesArr != null) {
                    for (i in 0 until mTypesArr.length()) mediaTypes.add(mTypesArr.optString(i))
                }
                val config = WorkerConfig(
                    version = j.optString("version", "3.0.0"),
                    baseUrl = j.optString("baseUrl", WorkerConstants.BASE_URL),
                    realtimeUrl = j.optString("realtimeUrl", "${WorkerConstants.WS_BASE_URL}/v1/realtime"),
                    callSignalUrlTemplate = j.optString("callSignalUrlTemplate", "${WorkerConstants.WS_BASE_URL}/v1/calls/{callId}/signal"),
                    websocketSubprotocol = j.optString("websocketSubprotocol", WorkerConstants.WS_PROTOCOL),
                    heartbeatEveryMs = hb?.optLong("everyMs", 25_000L) ?: 25_000L,
                    sfuAppId = j.optString("sfuAppId", WorkerConstants.SFU_APP_ID).ifBlank { WorkerConstants.SFU_APP_ID },
                    limits = WorkerLimits(
                        signalBytes = lim?.optInt("signalBytes", 32768) ?: 32768,
                        uploadMB = lim?.optInt("uploadMB", 25) ?: 25,
                        presenceUidsPerQuery = lim?.optInt("presenceUidsPerQuery", 100) ?: 100,
                        ringTimeoutMs = lim?.optLong("ringTimeoutMs", 45_000L) ?: 45_000L
                    ),
                    mediaTypes = mediaTypes,
                    features = WorkerFeatures(
                        auth = feat?.optBoolean("auth", true) ?: true,
                        realtimeHub = feat?.optBoolean("realtimeHub", false) ?: false,
                        callSignaling = feat?.optBoolean("callSignaling", false) ?: false,
                        turn = feat?.opt("turn")?.toString() ?: "false",
                        sfu = feat?.optBoolean("sfu", false) ?: false,
                        media = feat?.optBoolean("media", false) ?: false,
                        push = feat?.optBoolean("push", false) ?: false,
                        presenceSync = feat?.optBoolean("presenceSync", false) ?: false,
                        missedCalls = feat?.optBoolean("missedCalls", false) ?: false,
                        search = feat?.optBoolean("search", true) ?: true
                    )
                )
                _cachedConfig.value = config
                lastConfigFetchMs = System.currentTimeMillis()
                Result.success(config)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun whoami(): Result<JSONObject> = authorizedRequest("/v1/whoami")

    suspend fun fetchTurnCredentials(ttlSeconds: Int = 14400): Result<TurnCredentialsResponse> {
        return authorizedRequest("/v1/turn-credentials?ttl=$ttlSeconds").map { j ->
            val arr = j.optJSONArray("iceServers") ?: JSONArray()
            val servers = mutableListOf<IceServerSpec>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val urlsAny = item.opt("urls")
                val urls = when (urlsAny) {
                    is JSONArray -> (0 until urlsAny.length()).map { urlsAny.optString(it) }.filter { it.isNotBlank() }
                    is String -> listOf(urlsAny)
                    else -> emptyList()
                }
                if (urls.isNotEmpty()) {
                    servers.add(
                        IceServerSpec(
                            urls = urls,
                            username = item.optString("username").takeIf { it.isNotBlank() },
                            credential = item.optString("credential").takeIf { it.isNotBlank() }
                        )
                    )
                }
            }
            TurnCredentialsResponse(
                provider = j.optString("provider", "stun-only"),
                relay = j.optBoolean("relay", false),
                iceServers = servers,
                expiresAt = j.optLong("expiresAt", 0L),
                warning = j.optString("warning").takeIf { it.isNotBlank() }
            )
        }
    }

    suspend fun createSfuSession(callId: String, offerSdp: String): Result<SfuSessionResponse> {
        val body = JSONObject().apply {
            put("appId", _cachedConfig.value?.sfuAppId ?: WorkerConstants.SFU_APP_ID)
            put("sessionDescription", JSONObject().apply {
                put("type", "offer")
                put("sdp", offerSdp)
            })
        }
        return authorizedRequest("/v1/sfu/calls/$callId/sessions", method = "POST", jsonBody = body).map { j ->
            parseSfuSessionResponse(j)
        }
    }

    suspend fun pushSfuTracks(
        callId: String,
        sessionId: String,
        tracks: List<SfuTrackSpec>,
        offerSdp: String? = null
    ): Result<SfuSessionResponse> {
        val arr = JSONArray()
        tracks.forEach { t ->
            arr.put(JSONObject().apply {
                put("location", t.location)
                put("trackName", t.trackName)
                if (!t.sessionId.isNullOrBlank()) put("sessionId", t.sessionId)
                if (!t.mid.isNullOrBlank()) put("mid", t.mid)
            })
        }
        val body = JSONObject().apply {
            put("tracks", arr)
            if (!offerSdp.isNullOrBlank()) {
                put("sessionDescription", JSONObject().apply {
                    put("type", "offer")
                    put("sdp", offerSdp)
                })
            }
        }
        return authorizedRequest("/v1/sfu/calls/$callId/sessions/$sessionId/tracks", method = "POST", jsonBody = body).map { j ->
            parseSfuSessionResponse(j, fallbackSessionId = sessionId)
        }
    }

    suspend fun renegotiateSfuSession(callId: String, sessionId: String, answerSdp: String): Result<Unit> {
        val body = JSONObject().apply {
            put("sessionDescription", JSONObject().apply {
                put("type", "answer")
                put("sdp", answerSdp)
            })
        }
        return authorizedRequest("/v1/sfu/calls/$callId/sessions/$sessionId/renegotiate", method = "PUT", jsonBody = body).map { }
    }

    suspend fun listCallSfuTracks(callId: String): Result<List<SfuTrackSpec>> {
        return authorizedRequest("/v1/sfu/calls/$callId/tracks").map { j ->
            parseSfuTracks(j.optJSONArray("tracks"))
        }
    }

    private fun parseSfuSessionResponse(j: JSONObject, fallbackSessionId: String = ""): SfuSessionResponse {
        val sd = j.optJSONObject("sessionDescription")
        return SfuSessionResponse(
            sessionId = j.optString("sessionId", fallbackSessionId),
            sdpType = sd?.optString("type", "answer") ?: "answer",
            sdp = sd?.optString("sdp", "").orEmpty(),
            requiresImmediateRenegotiation = j.optBoolean("requiresImmediateRenegotiation", false),
            tracks = parseSfuTracks(j.optJSONArray("tracks"))
        )
    }

    private fun parseSfuTracks(arr: JSONArray?): List<SfuTrackSpec> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            SfuTrackSpec(
                location = o.optString("location", "remote"),
                trackName = o.optString("trackName"),
                sessionId = o.optString("sessionId").takeIf { it.isNotBlank() },
                mid = o.optString("mid").takeIf { it.isNotBlank() }
            )
        }
    }

    suspend fun ringCall(
        callId: String,
        receiverId: String = "",
        callerName: String = "",
        callType: String = "audio"
    ): Result<JSONObject> =
        authorizedRequest(
            "/v1/calls/$callId/ring",
            method = "POST",
            jsonBody = JSONObject().apply {
                if (receiverId.isNotBlank()) put("receiverId", receiverId)
                if (callerName.isNotBlank()) put("callerName", callerName)
                put("callType", callType)
            }
        )

    suspend fun notifyChatMessage(conversationId: String, messageId: String): Result<JSONObject> =
        authorizedRequest(
            "/v1/chat/notify",
            method = "POST",
            jsonBody = JSONObject().apply {
                put("conversationId", conversationId)
                put("messageId", messageId)
            }
        )

    suspend fun registerDeviceToken(fcmToken: String, platform: String = "android"): Result<JSONObject> =
        authorizedRequest(
            "/v1/devices",
            method = "POST",
            jsonBody = JSONObject().apply {
                put("token", fcmToken)
                put("platform", platform)
            }
        )

    suspend fun unregisterDeviceToken(fcmToken: String): Result<JSONObject> =
        authorizedRequest(
            "/v1/devices",
            method = "DELETE",
            jsonBody = JSONObject().apply { put("token", fcmToken) }
        )

    suspend fun queryPresence(uids: List<String>): Result<List<PresenceStatus>> {
        if (uids.isEmpty()) return Result.success(emptyList())
        val joined = URLEncoder.encode(uids.take(100).joinToString(","), "UTF-8")
        return authorizedRequest("/v1/presence?uids=$joined").map { j ->
            val arr = j.optJSONArray("users") ?: JSONArray()
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                PresenceStatus(
                    uid = o.optString("uid"),
                    online = o.optBoolean("online", false),
                    lastSeen = o.optLong("lastSeen", 0L)
                )
            }
        }
    }

    suspend fun uploadMedia(
        conversationId: String,
        bytes: ByteArray,
        mimeType: String,
        fileName: String = "",
        onProgress: (Float) -> Unit = {}
    ): Result<MediaUploadResponse> = withContext(Dispatchers.IO) {
        try {
            val maxBytes = (_cachedConfig.value?.limits?.uploadMB ?: 25).toLong() * 1024L * 1024L
            if (bytes.size.toLong() > maxBytes) {
                return@withContext Result.failure(
                    IOException("Fichier trop volumineux (max ${maxBytes / (1024L * 1024L)} Mo).")
                )
            }
            var token = getFreshIdToken(false)
                ?: return@withContext Result.failure(IllegalStateException("Non authentifié"))
            val url = buildString {
                append("${WorkerConstants.BASE_URL}/v1/media?conversationId=")
                append(URLEncoder.encode(conversationId, "UTF-8"))
                if (fileName.isNotBlank()) {
                    append("&fileName=").append(URLEncoder.encode(fileName.take(120), "UTF-8"))
                }
            }
            val mediaType = mimeType.toMediaTypeOrNull()

            fun executeUpload(bearer: String): Pair<Int, String> {
                val body = object : RequestBody() {
                    override fun contentType() = mediaType
                    override fun contentLength() = bytes.size.toLong()
                    override fun writeTo(sink: BufferedSink) {
                        val chunkSize = 8192
                        var offset = 0
                        while (offset < bytes.size) {
                            val len = minOf(chunkSize, bytes.size - offset)
                            sink.write(bytes, offset, len)
                            offset += len
                            onProgress(offset.toFloat() / bytes.size.coerceAtLeast(1))
                        }
                    }
                }
                val req = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $bearer")
                    .header("X-Brav-Bucket", WorkerConstants.R2_BUCKET_NAME)
                    .post(body)
                    .build()
                return httpClient.newCall(req).execute().use { res ->
                    res.code to (res.body?.string() ?: "{}")
                }
            }

            var (code, text) = executeUpload(token)
            if (code == 401) {
                token = getFreshIdToken(true) ?: token
                val retried = executeUpload(token)
                code = retried.first
                text = retried.second
            }
            val j = runCatching { JSONObject(text) }.getOrElse { JSONObject() }
            if (code in 200..299) {
                val rawUrl = j.optString("url")
                val resolvedUrl = if (rawUrl.startsWith("/")) "${WorkerConstants.BASE_URL}$rawUrl" else rawUrl
                Result.success(
                    MediaUploadResponse(
                        ok = j.optBoolean("ok", true),
                        key = j.optString("key"),
                        url = resolvedUrl,
                        size = j.optLong("size", bytes.size.toLong()),
                        contentType = j.optString("contentType", mimeType)
                    )
                )
            } else {
                val errCode = j.optString("error", "UPLOAD_FAILED_$code")
                Result.failure(IOException(formatWorkerError(errCode, code)))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteMedia(conversationId: String, fileName: String): Result<JSONObject> =
        authorizedRequest("/v1/media/c/$conversationId/$fileName", method = "DELETE")

    suspend fun downloadAuthorizedBytes(mediaUrl: String): Result<ByteArray> = withContext(Dispatchers.IO) {
        try {
            var token = getFreshIdToken(false)
                ?: return@withContext Result.failure(IllegalStateException("Non authentifié"))
            val resolvedUrl = if (mediaUrl.startsWith("/")) "${WorkerConstants.BASE_URL}$mediaUrl" else mediaUrl

            fun executeGet(bearer: String): Pair<Int, ByteArray?> {
                val req = Request.Builder()
                    .url(resolvedUrl)
                    .apply {
                        if (resolvedUrl.startsWith(WorkerConstants.BASE_URL)) {
                            header("Authorization", "Bearer $bearer")
                        }
                    }
                    .get()
                    .build()
                return httpClient.newCall(req).execute().use { res ->
                    if (res.isSuccessful) res.code to (res.body?.bytes() ?: ByteArray(0))
                    else res.code to null
                }
            }

            var (code, data) = executeGet(token)
            if (code == 401 && resolvedUrl.startsWith(WorkerConstants.BASE_URL)) {
                token = getFreshIdToken(true) ?: token
                val retried = executeGet(token)
                code = retried.first
                data = retried.second
            }
            if (code in 200..299 && data != null) {
                Result.success(data)
            } else {
                Result.failure(IOException("HTTP $code"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun downloadMediaToCache(
        context: Context,
        mediaUrl: String,
        fileNameHint: String = ""
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            if (mediaUrl.startsWith("file://") || mediaUrl.startsWith("/data/")) {
                return@withContext Result.success(File(mediaUrl.removePrefix("file://")))
            }
            val cacheDir = File(context.cacheDir, "brav_media_cache").apply { mkdirs() }
            val ext = fileNameHint.substringAfterLast('.', "")
                .ifBlank { mediaUrl.substringBefore('?').substringAfterLast('.', "") }
                .lowercase()
                .replace(Regex("[^a-z0-9]"), "")
                .take(8)
                .ifBlank { "bin" }
            val key = MessageDigest.getInstance("SHA-256")
                .digest(mediaUrl.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
                .take(28)
            val targetFile = File(cacheDir, "m_$key.$ext")
            if (targetFile.exists() && targetFile.length() > 0L) {
                return@withContext Result.success(targetFile)
            }
            val bytes = downloadAuthorizedBytes(mediaUrl).getOrElse { return@withContext Result.failure(it) }
            if (bytes.isEmpty()) return@withContext Result.failure(IOException("Fichier vide"))
            val tmpFile = File(cacheDir, "m_$key.tmp")
            tmpFile.writeBytes(bytes)
            if (!tmpFile.renameTo(targetFile)) {
                targetFile.writeBytes(bytes)
                tmpFile.delete()
            }
            Result.success(targetFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun syncUserDirectoryToD1(
        userId: String,
        displayName: String,
        username: String,
        city: String,
        avatarUrl: String
    ) {
        val body = JSONObject().apply {
            put("userId", userId)
            put("displayName", displayName)
            put("username", username)
            put("locationCity", city)
            put("avatarUrl", avatarUrl)
        }
        runCatching { authorizedRequest("/v1/users/sync", method = "POST", jsonBody = body) }
    }

    suspend fun syncOfferToD1(
        offerId: String,
        userId: String,
        title: String,
        category: String,
        description: String,
        city: String,
        priceOrSalary: String,
        authorName: String
    ) {
        val body = JSONObject().apply {
            put("id", offerId)
            put("userId", userId)
            put("title", title)
            put("category", category)
            put("description", description)
            put("locationCity", city)
            put("priceOrSalary", priceOrSalary)
            put("authorName", authorName)
            put("status", "published")
            put("paymentStatus", "free")
        }
        runCatching { authorizedRequest("/v1/offers/sync", method = "POST", jsonBody = body) }
    }

    suspend fun search(
        query: String,
        type: String = "all",
        city: String = "",
        category: String = "",
        limit: Int = 20
    ): Result<WorkerSearchResult> {
        val params = buildString {
            append("?q=").append(URLEncoder.encode(query, "UTF-8"))
            append("&type=").append(URLEncoder.encode(type, "UTF-8"))
            if (city.isNotBlank()) append("&city=").append(URLEncoder.encode(city, "UTF-8"))
            if (category.isNotBlank()) append("&category=").append(URLEncoder.encode(category, "UTF-8"))
            append("&limit=").append(limit)
        }
        return authorizedRequest("/v1/search$params").map { j ->
            val usersArr = j.optJSONArray("users") ?: JSONArray()
            val offersArr = j.optJSONArray("offers") ?: JSONArray()
            WorkerSearchResult(
                users = jsonArrayToList(usersArr),
                offers = jsonArrayToList(offersArr)
            )
        }
    }

    private fun jsonArrayToList(arr: JSONArray): List<Map<String, Any?>> {
        val list = mutableListOf<Map<String, Any?>>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val map = mutableMapOf<String, Any?>()
            obj.keys().forEach { k -> map[k] = obj.opt(k) }
            list.add(map)
        }
        return list
    }

    companion object {
        private const val TAG = "WorkerApiClient"
    }
}
