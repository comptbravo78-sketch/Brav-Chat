package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.User
import com.example.ui.components.UserAvatarWithStatus
import com.example.ui.theme.BravPurple
import com.example.ui.theme.BravRed
import com.example.viewmodel.BravViewModel
import kotlinx.coroutines.launch

@Composable
fun ContactsScreen(
    viewModel: BravViewModel,
    onOpenConversation: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val savedContacts by viewModel.savedContactUsers.collectAsStateWithLifecycle()
    val incomingRequests by viewModel.incomingRequests.collectAsStateWithLifecycle()
    val phoneContacts by viewModel.phoneContacts.collectAsStateWithLifecycle()
    val isSyncing by viewModel.isSyncingContacts.collectAsStateWithLifecycle()
    val presenceMap by viewModel.presenceMap.collectAsStateWithLifecycle()

    var query by remember { mutableStateOf("") }

    val contactsPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) viewModel.syncDeviceContacts()
        else viewModel.showMessage("Permission répertoire refusée.")
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Contacts & Découverte", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    viewModel.searchUsers(it)
                },
                placeholder = { Text("Numéro, e-mail, @username ou nom...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().testTag("contacts_search_input")
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Mon identifiant BRAV", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "@${currentUser?.username.orEmpty().ifBlank { currentUser?.userId?.take(8).orEmpty() }}",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    IconButton(onClick = {
                        val idText = "@${currentUser?.username.orEmpty()}"
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("BRAV ID", idText))
                        viewModel.showMessage("Identifiant $idText copié")
                    }) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier ID", tint = BravPurple)
                    }
                    IconButton(onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "Rejoins-moi sur BRAV Chat ! Mon identifiant : @${currentUser?.username.orEmpty()} (ID: ${currentUser?.userId.orEmpty()})"
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Partager mon profil BRAV"))
                    }) {
                        Icon(Icons.Rounded.Share, contentDescription = "Partager mon profil", tint = BravRed)
                    }
                }
            }
        }

        item {
            OutlinedButton(
                onClick = {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
                    if (granted) viewModel.syncDeviceContacts()
                    else contactsPermLauncher.launch(Manifest.permission.READ_CONTACTS)
                },
                enabled = !isSyncing,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (isSyncing) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Synchronisation du répertoire...")
                } else {
                    Icon(Icons.Rounded.Sync, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Synchroniser les contacts du téléphone")
                }
            }
        }

        if (incomingRequests.isNotEmpty()) {
            item {
                Text("Invitations reçues (${incomingRequests.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            items(incomingRequests, key = { it.id }) { req ->
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(req.fromName, fontWeight = FontWeight.Bold)
                            Text("@${req.fromUsername}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { viewModel.declineRequest(req) }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Refuser", tint = BravRed)
                        }
                        IconButton(onClick = { viewModel.acceptRequest(req) }) {
                            Icon(Icons.Rounded.Check, contentDescription = "Accepter", tint = BravPurple)
                        }
                    }
                }
            }
        }

        if (query.isNotBlank()) {
            item {
                Text("Résultats de recherche (${searchResults.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            if (searchResults.isEmpty()) {
                item {
                    Text("Aucun membre trouvé pour \"$query\".", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(searchResults, key = { "search_${it.userId}" }) { user ->
                    UserDiscoveryRow(
                        user = user,
                        isOnline = presenceMap[user.userId]?.online == true,
                        isSaved = savedContacts.any { it.userId == user.userId },
                        onChat = {
                            scope.launch {
                                viewModel.openOrCreateDirectChat(user).onSuccess { conv ->
                                    onOpenConversation(conv.id)
                                }
                            }
                        },
                        onInvite = { viewModel.sendContactRequest(user) },
                        onBlock = {
                            scope.launch {
                                viewModel.userRepository.blockUser(viewModel.currentUserId, user.userId)
                                viewModel.showMessage("${user.displayName} bloqué")
                            }
                        }
                    )
                }
            }
        }

        val phoneMatches = phoneContacts.filter { it.isBravUser }
        if (phoneMatches.isNotEmpty()) {
            item {
                Text("Membres BRAV dans votre répertoire (${phoneMatches.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            items(phoneMatches, key = { "phone_${it.id}" }) { contact ->
                val u = contact.bravUser!!
                UserDiscoveryRow(
                    user = u,
                    isOnline = presenceMap[u.userId]?.online == true,
                    isSaved = savedContacts.any { it.userId == u.userId },
                    subtitleOverride = contact.phoneDisplayName,
                    onChat = {
                        scope.launch {
                            viewModel.openOrCreateDirectChat(u).onSuccess { onOpenConversation(it.id) }
                        }
                    },
                    onInvite = {
                        scope.launch {
                            viewModel.contactRepository.addContactDirectly(viewModel.currentUserId, u)
                            viewModel.showMessage("${u.displayName} ajouté")
                        }
                    },
                    onBlock = {
                        scope.launch { viewModel.userRepository.blockUser(viewModel.currentUserId, u.userId) }
                    }
                )
            }
        }

        item {
            Text("Mes contacts (${savedContacts.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        if (savedContacts.isEmpty()) {
            item {
                Text(
                    "Aucun contact enregistré. Recherchez un ami ou synchronisez votre répertoire.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(savedContacts, key = { "saved_${it.userId}" }) { user ->
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatarWithStatus(
                            name = user.displayName,
                            avatarUrl = user.avatarUrl,
                            availabilityStatus = user.availabilityStatus,
                            isOnlineRealtime = presenceMap[user.userId]?.online == true,
                            size = 46.dp
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(user.displayName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("@${user.username} ${if (user.locationCity.isNotBlank()) "• ${user.locationCity}" else ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = {
                            scope.launch {
                                viewModel.openOrCreateDirectChat(user).onSuccess { onOpenConversation(it.id) }
                            }
                        }) {
                            Icon(Icons.Rounded.ChatBubble, contentDescription = "Discuter", tint = BravPurple)
                        }
                        IconButton(onClick = { viewModel.removeContact(user.userId) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Supprimer contact", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UserDiscoveryRow(
    user: User,
    isOnline: Boolean,
    isSaved: Boolean,
    subtitleOverride: String? = null,
    onChat: () -> Unit,
    onInvite: () -> Unit,
    onBlock: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatarWithStatus(
                name = user.displayName,
                avatarUrl = user.avatarUrl,
                availabilityStatus = user.availabilityStatus,
                isOnlineRealtime = isOnline,
                size = 46.dp
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(user.displayName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    text = subtitleOverride ?: "@${user.username.ifBlank { user.userId.take(6) }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!isSaved) {
                Button(
                    onClick = onInvite,
                    colors = ButtonDefaults.buttonColors(containerColor = BravPurple, contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.PersonAdd, contentDescription = "Inviter", modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Inviter", style = MaterialTheme.typography.labelMedium)
                }
            }
            IconButton(onClick = onChat) {
                Icon(Icons.Rounded.ChatBubble, contentDescription = "Message", tint = BravPurple)
            }
            IconButton(onClick = onBlock) {
                Icon(Icons.Rounded.Block, contentDescription = "Bloquer", tint = BravRed)
            }
        }
    }
}
