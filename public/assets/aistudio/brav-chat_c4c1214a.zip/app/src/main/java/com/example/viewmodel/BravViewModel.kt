package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.local.AppPreferencesRepository
import com.example.local.AppPreferencesState
import com.example.local.ThemeMode
import com.example.media.VoiceProcessingConfig
import com.example.media.VoiceRecorderPlayer
import com.example.media.WebRtcCallManager
import com.example.media.WebRtcConnectionState
import com.example.messaging.BravFirebaseMessagingService
import com.example.model.AbuseReport
import com.example.model.BlockedEntry
import com.example.model.Call
import com.example.model.Contact
import com.example.model.ContactRequest
import com.example.model.Conversation
import com.example.model.ConversationPref
import com.example.model.LiveLocationShare
import com.example.model.Message
import com.example.model.OfferListing
import com.example.model.StatusPost
import com.example.model.User
import com.example.model.UserDevice
import com.example.model.UserPrivateInfo
import com.example.network.PresenceStatus
import com.example.network.RealtimeEvent
import com.example.network.WorkerApiClient
import com.example.network.WorkerRealtimeClient
import com.example.repository.AiTranslationRepository
import com.example.repository.CallRepository
import com.example.repository.ChatRepository
import com.example.repository.ContactSyncRepository
import com.example.repository.DecryptedCoordinates
import com.example.repository.SocialRepository
import com.example.repository.UserRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BravViewModel(
    val currentUserId: String,
    val userRepository: UserRepository,
    val contactRepository: ContactSyncRepository,
    val chatRepository: ChatRepository,
    val callRepository: CallRepository,
    val socialRepository: SocialRepository,
    val aiTranslationRepository: AiTranslationRepository,
    val prefsRepository: AppPreferencesRepository,
    val workerApiClient: WorkerApiClient,
    val realtimeClient: WorkerRealtimeClient,
    val voicePlayer: VoiceRecorderPlayer,
    val webRtcCallManager: WebRtcCallManager,
    private val appContext: Context? = null
) : ViewModel() {

    val appPrefs: StateFlow<AppPreferencesState> = prefsRepository.state
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppPreferencesState())

    val currentUser: StateFlow<User?> = userRepository.observeUser(currentUserId)
        .catch { handleFlowError(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val privateInfo: StateFlow<UserPrivateInfo?> = userRepository.observePrivateInfo(currentUserId)
        .catch { handleFlowError(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val devices: StateFlow<List<UserDevice>> = userRepository.observeDevices(currentUserId)
        .catch { handleFlowError(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val blockedUsers: StateFlow<List<BlockedEntry>> = userRepository.observeBlockedUsers(currentUserId)
        .catch { handleFlowError(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversations: StateFlow<List<Conversation>> = chatRepository.observeConversations(currentUserId)
        .catch { handleFlowError(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversationPrefs: StateFlow<Map<String, ConversationPref>> =
        chatRepository.observeConversationPrefs(currentUserId)
            .catch { handleFlowError(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val callHistory: StateFlow<List<Call>> = callRepository.observeCallHistory(currentUserId)
        .catch { handleFlowError(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _realtimeIncomingCall = MutableStateFlow<Call?>(null)
    private var lastNotifiedCallId: String? = null

    val incomingCall: StateFlow<Call?> = combine(
        callRepository.observeIncomingCalls(currentUserId)
            .catch {
                handleFlowError(it)
                emit(emptyList())
            },
        _realtimeIncomingCall
    ) { fsList, wsCall ->
        fsList.firstOrNull() ?: wsCall?.takeIf { it.status == "calling" }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val statuses: StateFlow<List<StatusPost>> = socialRepository.observeStatuses(currentUserId)
        .catch { handleFlowError(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val myLiveLocations: StateFlow<List<LiveLocationShare>> =
        socialRepository.observeMySharedLocations(currentUserId)
            .catch { handleFlowError(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sharedLiveLocations: StateFlow<List<LiveLocationShare>> =
        socialRepository.observeLocationsSharedWithMe(currentUserId)
            .catch { handleFlowError(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val offers: StateFlow<List<OfferListing>> = socialRepository.observeOffers()
        .catch { handleFlowError(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val incomingRequests: StateFlow<List<ContactRequest>> =
        contactRepository.observeIncomingRequests(currentUserId)
            .catch { handleFlowError(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val outgoingRequests: StateFlow<List<ContactRequest>> =
        contactRepository.observeOutgoingRequests(currentUserId)
            .catch { handleFlowError(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedContactUsers: StateFlow<List<User>> =
        contactRepository.observeSavedContactUids(currentUserId)
            .map { pairs ->
                val users = contactRepository.fetchUsersByIds(pairs.map { it.first })
                val map = users.associateBy { it.userId }
                pairs.mapNotNull { map[it.first] }
            }
            .catch { handleFlowError(it) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val presenceMap: StateFlow<Map<String, PresenceStatus>> = realtimeClient.presenceMap
    val typingConversations: StateFlow<Map<String, Set<String>>> = realtimeClient.typingConversations
    val isRealtimeConnected: StateFlow<Boolean> = realtimeClient.isConnected

    private val _searchResults = MutableStateFlow<List<User>>(emptyList())
    val searchResults: StateFlow<List<User>> = _searchResults.asStateFlow()

    private val _phoneContacts = MutableStateFlow<List<Contact>>(emptyList())
    val phoneContacts: StateFlow<List<Contact>> = _phoneContacts.asStateFlow()

    private val _isSyncingContacts = MutableStateFlow(false)
    val isSyncingContacts: StateFlow<Boolean> = _isSyncingContacts.asStateFlow()

    private val _translations = MutableStateFlow<Map<String, String>>(emptyMap())
    val translations: StateFlow<Map<String, String>> = _translations.asStateFlow()

    private val _uploadProgress = MutableStateFlow<Float?>(null)
    val uploadProgress: StateFlow<Float?> = _uploadProgress.asStateFlow()

    private val _activeCall = MutableStateFlow<Call?>(null)
    val activeCall: StateFlow<Call?> = _activeCall.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val incomingCallPeer: StateFlow<User?> = incomingCall
        .flatMapLatest { call ->
            if (call == null || call.callerId.isBlank()) flowOf(null)
            else userRepository.observeUser(call.callerId).catch { emit(null) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeCallPeer: StateFlow<User?> = _activeCall
        .flatMapLatest { call ->
            if (call == null) flowOf(null)
            else {
                val peerUid = if (call.callerId == currentUserId) call.receiverId else call.callerId
                if (peerUid.isBlank()) flowOf(null)
                else userRepository.observeUser(peerUid).catch { emit(null) }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _terminalCallState = MutableStateFlow<Pair<Call, String>?>(null)
    val terminalCallState: StateFlow<Pair<Call, String>?> = _terminalCallState.asStateFlow()

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _adminReports = MutableStateFlow<List<AbuseReport>>(emptyList())
    val adminReports: StateFlow<List<AbuseReport>> = _adminReports.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private var activeCallObserverJob: Job? = null
    private var ringTimeoutJob: Job? = null
    private var terminalBannerJob: Job? = null

    init {
        viewModelScope.launch {
            chatRepository.flushOfflineOutbox()
        }
        viewModelScope.launch {
            appPrefs.collect { prefs ->
                webRtcCallManager.updateProcessingConfig(
                    VoiceProcessingConfig(
                        noiseSuppressionEnabled = prefs.noiseSuppressionEnabled,
                        echoCancellationEnabled = prefs.echoCancellationEnabled,
                        autoGainControlEnabled = prefs.autoGainControlEnabled,
                        voicePriorityEnabled = prefs.voicePriorityEnabled
                    )
                )
            }
        }
        viewModelScope.launch {
            conversations.collect { list ->
                val uids = list.flatMap { it.participants }.filter { it != currentUserId }.distinct()
                if (uids.isNotEmpty()) realtimeClient.watchUsers(uids)
            }
        }
        viewModelScope.launch {
            incomingCall.collect { call ->
                val ctx = appContext
                val prefs = appPrefs.value
                if (call != null && _activeCall.value == null) {
                    if (ctx != null && lastNotifiedCallId != call.id &&
                        prefs.notificationsEnabled && prefs.notifyCalls
                    ) {
                        lastNotifiedCallId = call.id
                        val resolvedAvatar = call.callerAvatar.ifBlank {
                            userRepository.getUserById(call.callerId)?.avatarUrl.orEmpty()
                        }
                        BravFirebaseMessagingService.showIncomingCallNotification(
                            context = ctx,
                            callId = call.id,
                            callerName = call.callerName,
                            callerAvatarUrl = resolvedAvatar,
                            isVideo = call.callType == "video",
                            soundEnabled = prefs.notifySoundEnabled,
                            vibrationEnabled = prefs.notifyVibrationEnabled
                        )
                    }
                } else {
                    if (ctx != null && lastNotifiedCallId != null) {
                        BravFirebaseMessagingService.cancelIncomingCallNotification(ctx, lastNotifiedCallId!!)
                        lastNotifiedCallId = null
                    }
                }
            }
        }
        viewModelScope.launch {
            realtimeClient.events.collect { ev ->
                when (ev) {
                    is RealtimeEvent.IncomingCall -> {
                        if (_activeCall.value == null && ev.callId.isNotBlank() && ev.callerId != currentUserId) {
                            val fetched = callRepository.getCall(ev.callId) ?: Call(
                                id = ev.callId,
                                callerId = ev.callerId,
                                callerName = ev.callerName,
                                receiverId = currentUserId,
                                participantIds = listOf(ev.callerId, currentUserId),
                                callType = ev.callType,
                                status = "calling"
                            )
                            if (fetched.status == "calling") {
                                _realtimeIncomingCall.value = fetched
                            }
                        }
                    }
                    is RealtimeEvent.CallEnded -> {
                        if (_realtimeIncomingCall.value?.id == ev.callId) {
                            _realtimeIncomingCall.value = null
                        }
                        val active = _activeCall.value
                        if (active?.id == ev.callId) {
                            activeCallObserverJob?.cancel()
                            ringTimeoutJob?.cancel()
                            webRtcCallManager.endSession(sendHangup = false)
                            _activeCall.value = null
                            showTerminalCallBanner(active, "Appel terminé")
                        }
                    }
                    is RealtimeEvent.MissedCall -> {
                        val incoming = _realtimeIncomingCall.value
                        if (incoming?.id == ev.callId) {
                            _realtimeIncomingCall.value = null
                            val prefs = appPrefs.value
                            if (appContext != null && prefs.notificationsEnabled && prefs.notifyMissedCalls) {
                                BravFirebaseMessagingService.showMissedCallNotification(
                                    context = appContext,
                                    callId = incoming.id,
                                    callerName = incoming.callerName,
                                    callerAvatarUrl = incoming.callerAvatar,
                                    isVideo = incoming.callType == "video",
                                    soundEnabled = prefs.notifySoundEnabled,
                                    vibrationEnabled = prefs.notifyVibrationEnabled
                                )
                            }
                        }
                        val active = _activeCall.value
                        if (active?.id == ev.callId) {
                            activeCallObserverJob?.cancel()
                            ringTimeoutJob?.cancel()
                            webRtcCallManager.endSession(sendHangup = false)
                            _activeCall.value = null
                            showTerminalCallBanner(active, "Appel manqué")
                        }
                    }
                    else -> Unit
                }
            }
        }
    }

    fun checkAdmin(email: String?) {
        viewModelScope.launch {
            val admin = userRepository.checkIsAdmin(currentUserId, email)
            _isAdmin.value = admin
            if (admin) {
                socialRepository.observeAllReportsForAdmin()
                    .catch { handleFlowError(it) }
                    .collect { _adminReports.value = it }
            }
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun searchUsers(query: String) {
        viewModelScope.launch {
            if (query.isBlank()) {
                _searchResults.value = emptyList()
                return@launch
            }
            _searchResults.value = contactRepository.searchUsers(query, currentUserId)
        }
    }

    fun syncDeviceContacts() {
        viewModelScope.launch {
            _isSyncingContacts.value = true
            _phoneContacts.value = contactRepository.syncPhoneContacts(currentUserId)
            _isSyncingContacts.value = false
        }
    }

    fun sendContactRequest(target: User) {
        val me = currentUser.value ?: return
        viewModelScope.launch {
            val res = contactRepository.sendContactRequest(me, target)
            _snackbarMessage.value = if (res.isSuccess) {
                "Invitation envoyée à ${target.displayName}"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Échec d'envoi"
            }
        }
    }

    fun acceptRequest(request: ContactRequest) {
        viewModelScope.launch {
            val res = contactRepository.acceptContactRequest(request, currentUserId)
            if (res.isSuccess) _snackbarMessage.value = "${request.fromName} ajouté à vos contacts"
        }
    }

    fun declineRequest(request: ContactRequest) {
        viewModelScope.launch { contactRepository.declineContactRequest(request) }
    }

    fun removeContact(uid: String) {
        viewModelScope.launch {
            contactRepository.removeContact(currentUserId, uid)
            _snackbarMessage.value = "Contact supprimé"
        }
    }

    suspend fun openOrCreateDirectChat(peer: User): Result<Conversation> {
        val me = currentUser.value ?: return Result.failure(IllegalStateException("Profil en cours de chargement"))
        return chatRepository.getOrCreateDirectConversation(me, peer)
    }

    suspend fun createGroup(members: List<User>, name: String, desc: String): Result<Conversation> {
        val me = currentUser.value ?: return Result.failure(IllegalStateException("Profil manquant"))
        return chatRepository.createGroupConversation(me, members, name, desc)
    }

    fun joinGroupByCode(code: String, onOpened: (String) -> Unit) {
        val me = currentUser.value ?: return
        viewModelScope.launch {
            val res = chatRepository.joinGroupByInviteCode(code, me)
            if (res.isSuccess) {
                onOpened(res.getOrThrow().id)
            } else {
                _snackbarMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Code invalide"
            }
        }
    }

    fun translateMessage(messageId: String, originalText: String, targetLanguage: String) {
        viewModelScope.launch {
            val res = aiTranslationRepository.translateMessage(originalText, targetLanguage)
            if (res.isSuccess) {
                _translations.value = _translations.value + (messageId to "[$targetLanguage] ${res.getOrThrow()}")
            } else {
                _snackbarMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Erreur de traduction"
            }
        }
    }

    fun handleDeepLinkCall(callId: String?) {
        if (callId.isNullOrBlank()) return
        viewModelScope.launch {
            val call = callRepository.getCall(callId) ?: return@launch
            if (call.status == "calling" && call.receiverId == currentUserId && _activeCall.value == null) {
                _realtimeIncomingCall.value = call
            }
        }
    }

    fun startOutgoingCall(peerUid: String, peerName: String, isVideo: Boolean) {
        val me = currentUser.value
        val myName = me?.displayName ?: "Membre BRAV"
        val prefs = appPrefs.value
        val procConfig = VoiceProcessingConfig(
            noiseSuppressionEnabled = prefs.noiseSuppressionEnabled,
            echoCancellationEnabled = prefs.echoCancellationEnabled,
            autoGainControlEnabled = prefs.autoGainControlEnabled,
            voicePriorityEnabled = prefs.voicePriorityEnabled
        )
        viewModelScope.launch {
            val knownPeer = savedContactUsers.value.firstOrNull { it.userId == peerUid }
                ?: userRepository.getUserById(peerUid)
            val res = callRepository.startCall(
                callerId = currentUserId,
                callerName = myName,
                receiverId = peerUid,
                receiverName = peerName,
                callType = if (isVideo) "video" else "audio",
                callerAvatar = me?.avatarUrl.orEmpty(),
                callerUsername = me?.username.orEmpty(),
                receiverAvatar = knownPeer?.avatarUrl.orEmpty(),
                receiverUsername = knownPeer?.username.orEmpty()
            )
            if (res.isSuccess) {
                val call = res.getOrThrow()
                _activeCall.value = call
                observeActiveCallRemotely(call.id)
                startRingTimeout(call.id)
                webRtcCallManager.startSession(
                    callId = call.id,
                    isCaller = true,
                    isVideo = isVideo,
                    myUid = currentUserId,
                    processingConfig = procConfig,
                    defaultSpeakerOn = if (isVideo) true else prefs.defaultSpeakerAudio,
                    startMuted = prefs.startCallMuted
                ) {
                    endActiveCall(missed = false)
                }
            } else {
                _snackbarMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Impossible de lancer l'appel"
            }
        }
    }

    fun acceptIncomingCall(call: Call) {
        _realtimeIncomingCall.value = null
        appContext?.let { BravFirebaseMessagingService.cancelIncomingCallNotification(it, call.id) }
        val prefs = appPrefs.value
        val procConfig = VoiceProcessingConfig(
            noiseSuppressionEnabled = prefs.noiseSuppressionEnabled,
            echoCancellationEnabled = prefs.echoCancellationEnabled,
            autoGainControlEnabled = prefs.autoGainControlEnabled,
            voicePriorityEnabled = prefs.voicePriorityEnabled
        )
        val isVideo = call.callType == "video"
        viewModelScope.launch {
            callRepository.updateCallStatus(call.id, "accepted")
            _activeCall.value = call.copy(status = "accepted")
            observeActiveCallRemotely(call.id)
            webRtcCallManager.startSession(
                callId = call.id,
                isCaller = false,
                isVideo = isVideo,
                myUid = currentUserId,
                processingConfig = procConfig,
                defaultSpeakerOn = if (isVideo) true else prefs.defaultSpeakerAudio,
                startMuted = prefs.startCallMuted
            ) {
                endActiveCall(missed = false)
            }
        }
    }

    fun rejectIncomingCall(call: Call) {
        _realtimeIncomingCall.value = null
        appContext?.let { BravFirebaseMessagingService.cancelIncomingCallNotification(it, call.id) }
        viewModelScope.launch {
            callRepository.updateCallStatus(call.id, "rejected", missed = true)
        }
    }

    fun toggleCallHold() {
        val call = _activeCall.value ?: return
        val session = webRtcCallManager.session.value
        val nextHeld = !session.isOnHold
        webRtcCallManager.setHold(nextHeld)
        _activeCall.value = call.copy(
            status = if (nextHeld) "on_hold" else "accepted",
            heldByUid = if (nextHeld) currentUserId else ""
        )
        viewModelScope.launch {
            callRepository.setCallHold(call.id, nextHeld, currentUserId)
        }
    }

    fun endActiveCall(missed: Boolean = false) {
        activeCallObserverJob?.cancel()
        ringTimeoutJob?.cancel()
        val call = _activeCall.value
        val duration = webRtcCallManager.session.value.elapsedSeconds
        webRtcCallManager.endSession(sendHangup = true)
        _activeCall.value = null
        if (call != null) {
            val wasStillCalling = call.status == "calling"
            val isMissed = missed && wasStillCalling && duration == 0L
            showTerminalCallBanner(call, if (isMissed) "Aucune réponse" else "Appel terminé")
            viewModelScope.launch {
                callRepository.updateCallStatus(
                    callId = call.id,
                    status = "ended",
                    missed = isMissed,
                    durationSeconds = duration
                )
            }
        }
    }

    private fun observeActiveCallRemotely(callId: String) {
        activeCallObserverJob?.cancel()
        activeCallObserverJob = viewModelScope.launch {
            callRepository.observeCall(callId)
                .catch { handleFlowError(it) }
                .collect { remote ->
                    if (remote == null) return@collect
                    when (remote.status) {
                        "accepted" -> {
                            ringTimeoutJob?.cancel()
                            if (_activeCall.value?.id == callId) {
                                _activeCall.value = remote
                            }
                            webRtcCallManager.setRemoteHold(false)
                            webRtcCallManager.notifyPeerAccepted()
                        }
                        "on_hold" -> {
                            if (_activeCall.value?.id == callId) {
                                _activeCall.value = remote
                            }
                            val remoteHeld = remote.heldByUid.isNotBlank() && remote.heldByUid != currentUserId
                            webRtcCallManager.setRemoteHold(remoteHeld)
                        }
                        "rejected", "ended" -> {
                            if (_activeCall.value?.id == callId) {
                                ringTimeoutJob?.cancel()
                                webRtcCallManager.endSession(sendHangup = false)
                                _activeCall.value = null
                                showTerminalCallBanner(
                                    remote,
                                    if (remote.status == "rejected") "Appel refusé" else "Appel terminé"
                                )
                            }
                            activeCallObserverJob?.cancel()
                        }
                    }
                }
        }
    }

    private fun startRingTimeout(callId: String) {
        ringTimeoutJob?.cancel()
        ringTimeoutJob = viewModelScope.launch {
            delay(45_000L)
            val current = _activeCall.value
            if (current?.id == callId && current.status == "calling") {
                endActiveCall(missed = true)
            }
        }
    }

    private fun showTerminalCallBanner(call: Call, reason: String) {
        terminalBannerJob?.cancel()
        _terminalCallState.value = call to reason
        terminalBannerJob = viewModelScope.launch {
            delay(1800L)
            _terminalCallState.value = null
        }
    }

    fun dismissTerminalCallBanner() {
        terminalBannerJob?.cancel()
        _terminalCallState.value = null
    }

    fun publishLiveLocation(recipients: List<User>, lat: Double, lng: Double, acc: Float, durationMin: Int) {
        val me = currentUser.value ?: return
        viewModelScope.launch {
            val res = socialRepository.publishEncryptedLocation(me, recipients, lat, lng, acc, durationMin)
            _snackbarMessage.value = if (res.isSuccess) {
                "Position chiffrée partagée ($durationMin min)"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Erreur de partage GPS"
            }
        }
    }

    fun stopLiveLocation() {
        viewModelScope.launch {
            socialRepository.stopLocationSharing(currentUserId)
            _snackbarMessage.value = "Partage de position arrêté"
        }
    }

    fun decryptPeerLocation(share: LiveLocationShare): DecryptedCoordinates? {
        return socialRepository.decryptLocation(share, currentUserId)
    }

    fun deleteConversation(conversationId: String, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            val res = chatRepository.deleteConversation(conversationId, currentUserId)
            if (res.isSuccess) {
                _snackbarMessage.value = "Conversation supprimée"
                onDeleted()
            } else {
                _snackbarMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Impossible de supprimer la conversation"
            }
        }
    }

    fun createFreeListing(
        title: String,
        category: String,
        description: String,
        city: String,
        price: String
    ) {
        val me = currentUser.value ?: return
        viewModelScope.launch {
            val res = socialRepository.createFreeOffer(me, title, category, description, city, price)
            _snackbarMessage.value = if (res.isSuccess) {
                "Annonce publiée gratuitement !"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Erreur lors de la publication"
            }
        }
    }

    fun deleteListing(offerId: String) {
        viewModelScope.launch {
            val res = socialRepository.deleteOffer(offerId)
            _snackbarMessage.value = if (res.isSuccess) "Annonce supprimée" else "Suppression impossible"
        }
    }

    fun deleteCallHistoryItem(callId: String) {
        viewModelScope.launch {
            val res = callRepository.deleteCallFromHistory(callId, currentUserId)
            _snackbarMessage.value = if (res.isSuccess) {
                "Appel retiré de l'historique"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Suppression impossible"
            }
        }
    }

    fun clearAllCallHistory() {
        val ids = callHistory.value.map { it.id }.filter { it.isNotBlank() }
        if (ids.isEmpty()) return
        viewModelScope.launch {
            val res = callRepository.clearCallHistory(currentUserId, ids)
            _snackbarMessage.value = if (res.isSuccess) {
                "Historique d'appels effacé"
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Impossible d'effacer l'historique"
            }
        }
    }

    fun toggleStatusLike(status: StatusPost) {
        viewModelScope.launch {
            val res = socialRepository.toggleStatusLike(status, currentUserId)
            if (res.isFailure) {
                _snackbarMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Action impossible"
            }
        }
    }

    fun toggleStatusReaction(status: StatusPost, reactionKey: String) {
        viewModelScope.launch {
            val res = socialRepository.toggleStatusReaction(status, currentUserId, reactionKey)
            if (res.isFailure) {
                _snackbarMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Réaction impossible"
            }
        }
    }

    fun addStatusComment(statusId: String, text: String, reactionKey: String = "", onAdded: () -> Unit = {}) {
        val me = currentUser.value ?: return
        viewModelScope.launch {
            val res = socialRepository.addStatusComment(statusId, me, text, reactionKey)
            if (res.isSuccess) {
                onAdded()
            } else {
                _snackbarMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Commentaire impossible"
            }
        }
    }

    fun deleteStatusComment(statusId: String, commentId: String) {
        viewModelScope.launch {
            val res = socialRepository.deleteStatusComment(statusId, commentId)
            if (res.isFailure) {
                _snackbarMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Suppression impossible"
            }
        }
    }

    fun removeProfilePhoto(onComplete: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val res = userRepository.removeProfilePhoto(currentUserId)
            _snackbarMessage.value = if (res.isSuccess) {
                onComplete(true)
                "Photo de profil supprimée"
            } else {
                onComplete(false)
                res.exceptionOrNull()?.localizedMessage ?: "Suppression de photo impossible"
            }
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefsRepository.setThemeMode(mode) }
    }

    fun uploadProgressValue(value: Float?) {
        _uploadProgress.value = value
    }

    private fun handleFlowError(err: Throwable) {
        val ffe = generateSequence(err) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (ffe == null && err is CancellationException) throw err
    }

    override fun onCleared() {
        super.onCleared()
        voicePlayer.release()
        webRtcCallManager.endSession(sendHangup = false)
    }
}
