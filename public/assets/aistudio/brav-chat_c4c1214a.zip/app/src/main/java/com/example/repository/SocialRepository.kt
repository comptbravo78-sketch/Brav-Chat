package com.example.repository

import android.content.Context
import com.example.R
import com.example.crypto.E2eeCryptoManager
import com.example.model.AbuseReport
import com.example.model.LiveLocationShare
import com.example.model.OfferListing
import com.example.model.StatusComment
import com.example.model.StatusPost
import com.example.model.User
import com.example.network.WorkerApiClient
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.util.UUID

data class DecryptedCoordinates(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float = 0f
)

class SocialRepository(
    private val db: FirebaseFirestore,
    private val workerApiClient: WorkerApiClient? = null,
    private val cryptoManager: E2eeCryptoManager? = null
) {
    constructor(context: Context, workerApiClient: WorkerApiClient? = null) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        workerApiClient = workerApiClient,
        cryptoManager = E2eeCryptoManager(context.applicationContext)
    )

    // =========================================================================
    // 24H EPHEMERAL STATUSES
    // =========================================================================
    fun observeStatuses(myUid: String = ""): Flow<List<StatusPost>> {
        val publicFlow = db.collection("statuses")
            .whereEqualTo("audienceType", "all")
            .snapshots()
            .map { it.toObjects(StatusPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

        if (myUid.isBlank()) {
            return publicFlow.map { list ->
                val nowMs = System.currentTimeMillis()
                list.filter { it.expiresAtMs > nowMs }
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
        }

        val mineFlow = db.collection("statuses")
            .whereEqualTo("userId", myUid)
            .snapshots()
            .map { it.toObjects(StatusPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

        val targetedFlow = db.collection("statuses")
            .whereArrayContains("allowedUids", myUid)
            .snapshots()
            .map { it.toObjects(StatusPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }

        return combine(publicFlow, mineFlow, targetedFlow) { pub, mine, targeted ->
            val nowMs = System.currentTimeMillis()
            (pub + mine + targeted)
                .distinctBy { it.id }
                .filter { it.expiresAtMs > nowMs }
                .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
        }
    }

    suspend fun createTextStatus(
        user: User,
        text: String,
        backgroundColor: String,
        audienceType: String = "all",
        allowedUids: List<String> = emptyList()
    ): Result<String> {
        val id = "st_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val ref = db.collection("statuses").document(id)
        val expires = System.currentTimeMillis() + 24L * 3600L * 1000L
        return try {
            ref.set(
                mapOf(
                    "userId" to user.userId,
                    "userName" to user.displayName.take(120),
                    "userAvatar" to user.avatarUrl,
                    "type" to "text",
                    "text" to text.trim().take(1000),
                    "caption" to "",
                    "mediaUrl" to "",
                    "backgroundColor" to backgroundColor,
                    "audienceType" to if (audienceType == "selected") "selected" else "all",
                    "allowedUids" to allowedUids.take(100),
                    "viewerIds" to emptyList<String>(),
                    "likedByUids" to emptyList<String>(),
                    "reactions" to emptyMap<String, List<String>>(),
                    "commentCount" to 0L,
                    "expiresAtMs" to expires,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun createMediaStatus(
        user: User,
        bytes: ByteArray,
        mimeType: String,
        isVideo: Boolean,
        caption: String,
        audienceType: String = "all",
        allowedUids: List<String> = emptyList()
    ): Result<String> {
        val client = workerApiClient ?: return Result.failure(IllegalStateException("Client Worker indisponible"))
        val statusId = "st_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val uploaded = client.uploadMedia("status_${user.userId}", bytes, mimeType).getOrElse {
            return Result.failure(it)
        }
        val ref = db.collection("statuses").document(statusId)
        val expires = System.currentTimeMillis() + 24L * 3600L * 1000L
        return try {
            ref.set(
                mapOf(
                    "userId" to user.userId,
                    "userName" to user.displayName.take(120),
                    "userAvatar" to user.avatarUrl,
                    "type" to if (isVideo) "video" else "image",
                    "text" to "",
                    "caption" to caption.trim().take(500),
                    "mediaUrl" to uploaded.url,
                    "backgroundColor" to "#570CA2",
                    "audienceType" to if (audienceType == "selected") "selected" else "all",
                    "allowedUids" to allowedUids.take(100),
                    "viewerIds" to emptyList<String>(),
                    "likedByUids" to emptyList<String>(),
                    "reactions" to emptyMap<String, List<String>>(),
                    "commentCount" to 0L,
                    "expiresAtMs" to expires,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(statusId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun markStatusViewed(statusId: String, viewerUid: String) {
        val ref = db.collection("statuses").document(statusId)
        runCatching {
            ref.update("viewerIds", FieldValue.arrayUnion(viewerUid)).await()
        }
    }

    suspend fun deleteStatus(statusId: String): Result<Unit> {
        val ref = db.collection("statuses").document(statusId)
        return try {
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun toggleStatusLike(status: StatusPost, myUid: String): Result<Unit> {
        val ref = db.collection("statuses").document(status.id)
        val alreadyLiked = myUid in status.likedByUids
        return try {
            val op = if (alreadyLiked) FieldValue.arrayRemove(myUid) else FieldValue.arrayUnion(myUid)
            ref.update("likedByUids", op).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun toggleStatusReaction(status: StatusPost, myUid: String, reactionKey: String): Result<Unit> {
        val ref = db.collection("statuses").document(status.id)
        val updated = status.reactions.toMutableMap()
        val currentList = updated[reactionKey].orEmpty().toMutableList()
        if (myUid in currentList) {
            currentList.remove(myUid)
        } else {
            currentList.add(myUid)
        }
        if (currentList.isEmpty()) updated.remove(reactionKey) else updated[reactionKey] = currentList
        return try {
            ref.update("reactions", updated).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            Result.failure(e)
        }
    }

    fun observeStatusComments(statusId: String): Flow<List<StatusComment>> {
        return db.collection("statuses").document(statusId)
            .collection("comments")
            .snapshots()
            .map { snap ->
                snap.toObjects(StatusComment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp(0, 0) }
            }
    }

    suspend fun addStatusComment(
        statusId: String,
        author: User,
        text: String,
        reactionKey: String = ""
    ): Result<String> {
        val trimmed = text.trim().take(500)
        if (trimmed.isBlank() && reactionKey.isBlank()) {
            return Result.failure(IllegalArgumentException("Commentaire vide"))
        }
        val commentId = "cmt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val statusRef = db.collection("statuses").document(statusId)
        val commentRef = statusRef.collection("comments").document(commentId)
        return try {
            commentRef.set(
                mapOf(
                    "statusId" to statusId,
                    "authorId" to author.userId,
                    "authorName" to author.displayName.take(120),
                    "authorAvatar" to author.avatarUrl,
                    "text" to trimmed,
                    "reactionKey" to reactionKey.take(32),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            runCatching {
                statusRef.update("commentCount", FieldValue.increment(1L)).await()
            }
            Result.success(commentId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, commentRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteStatusComment(statusId: String, commentId: String): Result<Unit> {
        val statusRef = db.collection("statuses").document(statusId)
        val commentRef = statusRef.collection("comments").document(commentId)
        return try {
            commentRef.delete().await()
            runCatching {
                val snap = statusRef.get().await()
                val current = (snap.getLong("commentCount") ?: 1L).coerceAtLeast(1L)
                statusRef.update("commentCount", current - 1L).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, commentRef.path)
            Result.failure(e)
        }
    }

    // =========================================================================
    // ENCRYPTED REAL-TIME LIVE LOCATION SHARING
    // =========================================================================
    fun observeMySharedLocations(uid: String): Flow<List<LiveLocationShare>> {
        return db.collection("live_locations")
            .whereEqualTo("ownerId", uid)
            .snapshots()
            .map { snap ->
                snap.toObjects(LiveLocationShare::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.active && it.expiresAtMs > System.currentTimeMillis() }
            }
    }

    fun observeLocationsSharedWithMe(uid: String): Flow<List<LiveLocationShare>> {
        return db.collection("live_locations")
            .whereArrayContains("recipientUids", uid)
            .snapshots()
            .map { snap ->
                snap.toObjects(LiveLocationShare::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.active && it.expiresAtMs > System.currentTimeMillis() }
            }
    }

    suspend fun publishEncryptedLocation(
        owner: User,
        recipients: List<User>,
        latitude: Double,
        longitude: Double,
        accuracyMeters: Float,
        durationMinutes: Int
    ): Result<String> {
        val shareId = "loc_${owner.userId}"
        val ref = db.collection("live_locations").document(shareId)
        val crypto = cryptoManager ?: return Result.failure(IllegalStateException("Chiffrement indisponible"))
        val expires = System.currentTimeMillis() + durationMinutes * 60_000L

        val coordsPlain = JSONObject().apply {
            put("lat", latitude)
            put("lng", longitude)
            put("acc", accuracyMeters.toDouble())
        }.toString()

        val symKey = crypto.generateGroupKeyBase64()
        val (cipher, iv) = crypto.encryptWithSymmetricKey(symKey, coordsPlain)
        val ownerPub = crypto.getPublicKeyBase64(owner.userId)
        val wrappedKeys = JSONObject()

        val allTargets = (listOf(owner) + recipients).distinctBy { it.userId }.take(20)
        for (target in allTargets) {
            val pub = if (target.userId == owner.userId) ownerPub else target.publicKey
            if (pub.isNotBlank()) {
                val encKey = crypto.encryptForPeer(owner.userId, pub, shareId, symKey)
                wrappedKeys.put(
                    target.userId,
                    JSONObject().apply {
                        put("k", encKey.ciphertextBase64)
                        put("iv", encKey.ivBase64)
                    }
                )
            }
        }

        val envelope = JSONObject().apply {
            put("c", cipher)
            put("iv", iv)
            put("pk", ownerPub)
            put("keys", wrappedKeys)
        }.toString()

        return try {
            ref.set(
                mapOf(
                    "ownerId" to owner.userId,
                    "ownerName" to owner.displayName.take(120),
                    "recipientUids" to recipients.map { it.userId }.take(50),
                    "encryptedCoords" to envelope.take(4000),
                    "encryptionIv" to iv,
                    "senderPublicKey" to ownerPub,
                    "isEncrypted" to true,
                    "active" to true,
                    "expiresAtMs" to expires,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(shareId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun stopLocationSharing(ownerId: String): Result<Unit> {
        val shareId = "loc_$ownerId"
        val ref = db.collection("live_locations").document(shareId)
        return try {
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path)
            Result.failure(e)
        }
    }

    fun decryptLocation(share: LiveLocationShare, myUid: String): DecryptedCoordinates? {
        val crypto = cryptoManager ?: return null
        return try {
            val env = JSONObject(share.encryptedCoords)
            val cipher = env.getString("c")
            val iv = env.getString("iv")
            val senderPub = env.optString("pk").ifBlank { share.senderPublicKey }
            val keysObj = env.optJSONObject("keys") ?: return null
            val myWrapped = keysObj.optJSONObject(myUid) ?: return null
            val symKey = crypto.decryptFromPeer(
                myUid = myUid,
                peerPublicKeyBase64 = senderPub,
                contextId = share.id.ifBlank { "loc_${share.ownerId}" },
                ciphertextBase64 = myWrapped.getString("k"),
                ivBase64 = myWrapped.getString("iv")
            ) ?: return null
            val plain = crypto.decryptWithSymmetricKey(symKey, cipher, iv) ?: return null
            val j = JSONObject(plain)
            DecryptedCoordinates(
                latitude = j.getDouble("lat"),
                longitude = j.getDouble("lng"),
                accuracyMeters = j.optDouble("acc", 0.0).toFloat()
            )
        } catch (_: Exception) {
            null
        }
    }

    // =========================================================================
    // FREE OFFERS / LISTINGS (100% GRATUIT)
    // =========================================================================
    fun observeOffers(): Flow<List<OfferListing>> {
        return db.collection("offers")
            .snapshots()
            .map { snap ->
                snap.toObjects(OfferListing::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
    }

    suspend fun createFreeOffer(
        user: User,
        title: String,
        category: String,
        description: String,
        locationCity: String,
        priceOrSalary: String
    ): Result<String> {
        val offerId = "off_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val ref = db.collection("offers").document(offerId)
        return try {
            ref.set(
                mapOf(
                    "userId" to user.userId,
                    "authorName" to user.displayName.take(120),
                    "title" to title.trim().take(160),
                    "category" to category.trim().take(80),
                    "description" to description.trim().take(2000),
                    "locationCity" to locationCity.trim().take(120),
                    "priceOrSalary" to priceOrSalary.trim().take(80),
                    "status" to "published",
                    "paymentStatus" to "free",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            workerApiClient?.syncOfferToD1(
                offerId = offerId,
                userId = user.userId,
                title = title.trim().take(160),
                category = category.trim().take(80),
                description = description.trim().take(2000),
                city = locationCity.trim().take(120),
                priceOrSalary = priceOrSalary.trim().take(80),
                authorName = user.displayName.take(120)
            )
            Result.success(offerId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun deleteOffer(offerId: String): Result<Unit> {
        val ref = db.collection("offers").document(offerId)
        return try {
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path)
            Result.failure(e)
        }
    }

    // =========================================================================
    // MODERATION / REPORTS / ADMIN MONITORING
    // =========================================================================
    suspend fun submitReport(
        reporterId: String,
        targetUid: String = "",
        conversationId: String = "",
        messageId: String = "",
        reason: String,
        details: String
    ): Result<Unit> {
        val id = "rep_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val ref = db.collection("reports").document(id)
        return try {
            ref.set(
                mapOf(
                    "reporterId" to reporterId,
                    "targetUid" to targetUid.take(128),
                    "conversationId" to conversationId.take(128),
                    "messageId" to messageId.take(128),
                    "reason" to reason.trim().take(120),
                    "details" to details.trim().take(1000),
                    "status" to "pending",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            Result.failure(e)
        }
    }

    fun observeAllReportsForAdmin(): Flow<List<AbuseReport>> {
        return db.collection("reports")
            .snapshots()
            .map { snap ->
                snap.toObjects(AbuseReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
    }

    suspend fun adminUpdateReportStatus(reportId: String, status: String): Result<Unit> {
        val ref = db.collection("reports").document(reportId)
        return try {
            ref.update("status", status).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun adminToggleUserSuspension(targetUid: String, suspended: Boolean): Result<Unit> {
        val ref = db.collection("users").document(targetUid)
        return try {
            ref.update(
                mapOf(
                    "isSuspended" to suspended,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            Result.failure(e)
        }
    }
}
