package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Official BRAV Chat Brand Colors (preserved from official logo)
val BravPurplePrimary = Color(0xFF570CA2)
val BravPurpleDeep = Color(0xFF3E0678)
val BravPurpleBright = Color(0xFFA855F7)
val BravRedSecondary = Color(0xFFEA0D1B)
val BravRedBright = Color(0xFFFF5252)

// Light Scheme Colors
val PrimaryLight = Color(0xFF570CA2)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFF3E8FF)
val OnPrimaryContainerLight = Color(0xFF2E0061)
val SecondaryLight = Color(0xFFEA0D1B)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFE4E6)
val OnSecondaryContainerLight = Color(0xFF6B0007)
val TertiaryLight = Color(0xFF047857)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFD1FAE5)
val OnTertiaryContainerLight = Color(0xFF064E3B)

val SlateBackgroundLight = Color(0xFFF7F8FC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateSurfaceVariantLight = Color(0xFFEEF1F7)
val SlateOnSurfaceLight = Color(0xFF0F172A)
val SlateOnSurfaceVariantLight = Color(0xFF475569)

// Dark Scheme Colors
val PrimaryDark = Color(0xFFB366FF)
val OnPrimaryDark = Color(0xFF270052)
val PrimaryContainerDark = Color(0xFF4A0D8A)
val OnPrimaryContainerDark = Color(0xFFF3E8FF)
val SecondaryDark = Color(0xFFFF5C66)
val OnSecondaryDark = Color(0xFF4D0004)
val SecondaryContainerDark = Color(0xFF8B000B)
val OnSecondaryContainerDark = Color(0xFFFFD8D8)
val TertiaryDark = Color(0xFF34D399)
val OnTertiaryDark = Color(0xFF064E3B)
val TertiaryContainerDark = Color(0xFF065F46)
val OnTertiaryContainerDark = Color(0xFFA7F3D0)

val SlateBackgroundDark = Color(0xFF0A0D16)
val SlateSurfaceDark = Color(0xFF141B2B)
val SlateSurfaceVariantDark = Color(0xFF1F293D)
val SlateOnSurfaceDark = Color(0xFFF8FAFC)
val SlateOnSurfaceVariantDark = Color(0xFF94A3B8)

// Semantic Status & Action Colors
val OnlineGreen = Color(0xFF10B981)
val BusyAmber = Color(0xFFF59E0B)
val DndRed = Color(0xFFEF4444)
val LocationPinColor = Color(0xFF059669)
val CallActionGreen = Color(0xFF16A34A)
val EndCallRed = Color(0xFFDC2626)

// Convenience Aliases
val BravPurple = BravPurplePrimary
val BravRed = BravRedSecondary
val StatusOnlineGreen = OnlineGreen
val StatusBusyAmber = BusyAmber
val StatusDndRed = DndRed
val StatusOfflineGray = Color(0xFF94A3B8)

