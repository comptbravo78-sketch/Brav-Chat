package com.example.util

import java.security.MessageDigest

object PhoneUtils {
    fun normalize(rawNumber: String): String {
        val trimmed = rawNumber.trim()
        if (trimmed.isBlank()) return ""
        val hasPlus = trimmed.startsWith("+")
        val digits = trimmed.filter { it.isDigit() }
        if (digits.isEmpty()) return ""

        return if (hasPlus) {
            "+$digits"
        } else if (digits.startsWith("00") && digits.length > 2) {
            "+${digits.substring(2)}"
        } else if (digits.length == 10 && (digits.startsWith("07") || digits.startsWith("05") || digits.startsWith("01"))) {
            "+225$digits"
        } else if (digits.length == 8 && (digits.startsWith("0") || digits.startsWith("4") || digits.startsWith("5") || digits.startsWith("7"))) {
            "+225$digits"
        } else {
            digits
        }
    }

    fun matches(phoneA: String, phoneB: String): Boolean {
        val normA = normalize(phoneA)
        val normB = normalize(phoneB)
        if (normA.isEmpty() || normB.isEmpty()) return false
        if (normA == normB) return true
        val digitsA = normA.filter { it.isDigit() }
        val digitsB = normB.filter { it.isDigit() }
        if (digitsA == digitsB) return true
        val minLen = minOf(digitsA.length, digitsB.length)
        if (minLen >= 8 && digitsA.takeLast(8) == digitsB.takeLast(8)) return true
        return false
    }

    fun formatDisplay(phoneNumber: String): String {
        val norm = normalize(phoneNumber)
        if (norm.startsWith("+225") && norm.length == 14) {
            return "${norm.substring(0, 4)} ${norm.substring(4, 6)} ${norm.substring(6, 8)} ${norm.substring(8, 10)} ${norm.substring(10, 12)} ${norm.substring(12, 14)}"
        }
        return phoneNumber
    }

    fun maskPhone(phoneNumber: String): String {
        val norm = normalize(phoneNumber)
        if (norm.length <= 4) return ""
        return "${norm.take(4)} •••• ${norm.takeLast(4)}"
    }

    fun sha256LookupHash(input: String): String {
        if (input.isBlank()) return ""
        val digest = MessageDigest.getInstance("SHA-256").digest(input.trim().lowercase().toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
