package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.PhoneInTalk
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.local.AppPreferencesState
import com.example.media.VoiceAudioTelemetry
import com.example.media.WebRtcCallManager
import com.example.media.WebRtcConnectionState
import com.example.media.WebRtcSessionState
import com.example.model.Call
import com.example.model.User
import com.example.ui.theme.BravPurple
import com.example.ui.theme.CallActionGreen
import com.example.ui.theme.EndCallRed
import com.example.ui.theme.StatusBusyAmber
import com.example.ui.theme.StatusOnlineGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer

@Composable
fun ActiveCallOverlay(
    call: Call,
    currentUserId: String,
    peerUser: User? = null,
    appPrefs: AppPreferencesState = AppPreferencesState(),
    webRtcCallManager: WebRtcCallManager,
    onToggleHold: () -> Unit = {},
    onHangup: () -> Unit
) {
    CallScreen(
        call = call,
        currentUserId = currentUserId,
        peerUser = peerUser,
        appPrefs = appPrefs,
        webRtcCallManager = webRtcCallManager,
        onToggleHold = onToggleHold,
        onHangup = onHangup
    )
}

/**
 * Full-screen CallScreen wired directly to [WebRtcCallManager] real-time audio/video streams,
 * permissions, ringback tone, and hardware renderers.
 */
@Composable
fun CallScreen(
    call: Call,
    currentUserId: String,
    peerUser: User? = null,
    appPrefs: AppPreferencesState = AppPreferencesState(),
    webRtcCallManager: WebRtcCallManager,
    onToggleHold: () -> Unit = {},
    onHangup: () -> Unit
) {
    val context = LocalContext.current
    val session by webRtcCallManager.session.collectAsStateWithLifecycle()
    val audioTelemetry by webRtcCallManager.audioTelemetry.collectAsStateWithLifecycle()
    val isCaller = call.callerId == currentUserId

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        webRtcCallManager.refreshLocalMediaAfterPermissions()
    }
    LaunchedEffect(call.id) {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (call.callType == "video" && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA)
        }
        if (needed.isNotEmpty()) permLauncher.launch(needed.toTypedArray())
    }

    val shouldPlayRingback = isCaller &&
        call.status == "calling" &&
        session.connectionState == WebRtcConnectionState.SIGNALING &&
        appPrefs.notifySoundEnabled
    LaunchedEffect(call.id, shouldPlayRingback) {
        if (!shouldPlayRingback) return@LaunchedEffect
        val toneGen = runCatching { ToneGenerator(AudioManager.STREAM_VOICE_CALL, 58) }.getOrNull()
        try {
            while (isActive) {
                runCatching { toneGen?.startTone(ToneGenerator.TONE_SUP_RINGTONE, 1100) }
                delay(3400L)
            }
        } finally {
            runCatching { toneGen?.stopTone() }
            runCatching { toneGen?.release() }
        }
    }

    val isVideo = call.callType == "video"
    val videoSlot: (@Composable BoxWithConstraintsScope.(String, String, String) -> Unit)? = if (isVideo) {
        val remoteRenderer = remember { SurfaceViewRenderer(context) }
        val localRenderer = remember { SurfaceViewRenderer(context) }
        DisposableEffect(call.id) {
            webRtcCallManager.attachRenderers(localRenderer, remoteRenderer)
            onDispose { webRtcCallManager.detachRenderers(localRenderer, remoteRenderer) }
        }
        val slot: @Composable BoxWithConstraintsScope.(String, String, String) -> Unit = { peerName, peerAvatarUrl, statusText ->
            val showBackgroundFeed = if (session.isVideoSwapped) session.isCameraEnabled else session.hasRemoteVideo
            AndroidView(
                factory = {
                    remoteRenderer.apply {
                        setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            if (!showBackgroundFeed) {
                VideoStagePlaceholder(
                    displayName = if (session.isVideoSwapped) "Votre caméra" else peerName,
                    avatarUrl = if (session.isVideoSwapped) "" else peerAvatarUrl,
                    statusText = when {
                        session.isOnHold || call.status == "on_hold" -> "Appel vidéo en attente"
                        session.isVideoSwapped -> "Caméra locale en pause"
                        call.status == "calling" -> "Sonnerie vidéo chez $peerName..."
                        else -> statusText
                    }
                )
            }
            CallVideoPipFrame(
                maxWidth = maxWidth,
                maxHeight = maxHeight,
                localRenderer = localRenderer,
                session = session,
                peerName = peerName,
                onSwapFeeds = { webRtcCallManager.setVideoSwapped(!session.isVideoSwapped) }
            )
        }
        slot
    } else null

    CallScreenContent(
        call = call,
        currentUserId = currentUserId,
        peerUser = peerUser,
        session = session,
        audioTelemetry = audioTelemetry,
        onToggleMute = { webRtcCallManager.toggleMute() },
        onToggleSpeaker = { webRtcCallManager.toggleSpeaker() },
        onToggleHold = onToggleHold,
        onToggleCamera = { webRtcCallManager.toggleCamera() },
        onSwitchCamera = { webRtcCallManager.switchCamera() },
        onHangup = onHangup,
        videoStageContent = videoSlot
    )
}

/**
 * Stateless presentation component for [CallScreen], rendering peer identity details, live WebRTC
 * chronometer, real-time audio DSP status, and responsive audio/video control docks.
 */
@Composable
fun CallScreenContent(
    call: Call,
    currentUserId: String,
    peerUser: User? = null,
    session: WebRtcSessionState,
    audioTelemetry: VoiceAudioTelemetry = VoiceAudioTelemetry(),
    onToggleMute: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onToggleHold: () -> Unit,
    onToggleCamera: () -> Unit = {},
    onSwitchCamera: () -> Unit = {},
    onHangup: () -> Unit,
    videoStageContent: (@Composable BoxWithConstraintsScope.(peerName: String, peerAvatarUrl: String, statusText: String) -> Unit)? = null
) {
    val isCaller = call.callerId == currentUserId
    val peerUid = if (isCaller) call.receiverId else call.callerId
    val verifiedPeer = peerUser?.takeIf { it.userId == peerUid }
    val peerName = verifiedPeer?.displayName?.ifBlank { null }
        ?: (if (isCaller) call.receiverName else call.callerName).ifBlank { "Correspondant BRAV" }
    val peerAvatarUrl = verifiedPeer?.avatarUrl?.ifBlank { null }
        ?: (if (isCaller) call.receiverAvatar else call.callerAvatar)
    val peerUsername = verifiedPeer?.username?.ifBlank { null }
        ?: if (isCaller) call.receiverUsername else call.callerUsername
    val peerPhone = verifiedPeer?.phoneMasked?.ifBlank { null }
    val peerCity = verifiedPeer?.locationCity?.ifBlank { null }
    val peerSubtitle = buildList {
        if (peerUsername.isNotBlank()) add("@$peerUsername")
        if (peerPhone != null) add(peerPhone)
        if (isEmpty() && peerUid.isNotBlank()) add("ID : ${peerUid.take(8)}...")
    }.joinToString(" • ").ifBlank { "Membre BRAV CHAT" }

    val isEstablished = session.connectionState == WebRtcConnectionState.CONNECTED || session.elapsedSeconds > 0L
    val chronometerText = formatCallChronometer(session.elapsedSeconds)
    val stateLabel = when {
        session.isOnHold -> "Appel en attente"
        session.isRemoteOnHold || call.status == "on_hold" -> "Mis en attente par $peerName"
        session.connectionState == WebRtcConnectionState.FAILED -> session.errorMessage ?: "Connexion interrompue"
        session.connectionState == WebRtcConnectionState.RECONNECTING -> "Reconnexion en cours..."
        session.connectionState == WebRtcConnectionState.CONNECTED ->
            if (session.usingRelayTurn) "Connecté • Relais sécurisé" else "Connecté • Audio HD"
        call.status == "calling" -> "Sonnerie en cours..."
        session.connectionState == WebRtcConnectionState.CONNECTING -> "Connexion WebRTC..."
        else -> "Établissement sécurisé..."
    }

    var showDetailsPanel by remember { mutableStateOf(false) }

    if (call.callType == "video") {
        Surface(modifier = Modifier.fillMaxSize().zIndex(101f), color = Color(0xFF0B1120)) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0B1120))
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    if (videoStageContent != null) {
                        videoStageContent(peerName, peerAvatarUrl, stateLabel)
                    } else {
                        VideoStagePlaceholder(
                            displayName = peerName,
                            avatarUrl = peerAvatarUrl,
                            statusText = stateLabel
                        )
                    }
                }

                // Top detailed peer identity & chronometer card
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xDF0F172A),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 12.dp, start = 16.dp, end = 16.dp)
                        .widthIn(max = 560.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(22.dp))
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CallPeerPhotoAvatar(
                                name = peerName,
                                avatarUrl = peerAvatarUrl,
                                size = 46.dp,
                                ringAnimated = call.status == "calling",
                                isLightSurface = false
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = peerName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.testTag("call_peer_name")
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = if (isEstablished) chronometerText else stateLabel,
                                        style = TextStyle(
                                            fontFeatureSettings = "tnum",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = if (session.isOnHold) StatusBusyAmber else Color(0xFF86EFAC),
                                        modifier = Modifier.testTag("call_chronometer_text")
                                    )
                                    Text(
                                        text = "• $peerSubtitle",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFCBD5E1),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .clip(CircleShape)
                                    .clickable { showDetailsPanel = !showDetailsPanel }
                                    .padding(6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (showDetailsPanel) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                    contentDescription = "Détails du correspondant",
                                    tint = Color(0xFFCBD5E1),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Rounded.Lock, contentDescription = null, tint = StatusOnlineGreen, modifier = Modifier.size(13.dp))
                                Text(
                                    text = "Vidéo E2EE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                            AudioDspBadge(
                                telemetry = audioTelemetry,
                                isLightSurface = false,
                                onClick = { showDetailsPanel = !showDetailsPanel }
                            )
                        }

                        AnimatedVisibility(
                            visible = showDetailsPanel,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            CallDetailsExpandedCard(
                                peerSubtitle = peerSubtitle,
                                peerCity = peerCity,
                                stateLabel = stateLabel,
                                telemetry = audioTelemetry,
                                isLightSurface = false
                            )
                        }
                    }
                }

                // Bottom adaptive video & audio WebRTC control dock
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color(0xEB1E293B),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp, start = 12.dp, end = 12.dp)
                        .widthIn(max = 580.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(28.dp))
                ) {
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp)) {
                        val wideDock = maxWidth >= 460.dp
                        if (wideDock) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.Top
                            ) {
                                VideoMediaButtons(session, onToggleMute, onToggleSpeaker, onToggleHold, onToggleCamera, onSwitchCamera, buttonSize = 50.dp)
                                HangupCommandButton(isLightSurface = false, size = 50.dp, onHangup = onHangup)
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    VideoMediaButtons(session, onToggleMute, onToggleSpeaker, onToggleHold, onToggleCamera, onSwitchCamera, buttonSize = 48.dp)
                                }
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = EndCallRed,
                                    onClick = onHangup,
                                    modifier = Modifier
                                        .fillMaxWidth(0.68f)
                                        .height(48.dp)
                                        .testTag("hangup_call_button")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(Icons.Rounded.CallEnd, contentDescription = "Raccrocher", tint = Color.White, modifier = Modifier.size(22.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text("Terminer l'appel", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        Surface(modifier = Modifier.fillMaxSize().zIndex(101f), color = CallLightBg) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                CallLightBg,
                                Color(0xFFEEF2FF).copy(alpha = 0.55f),
                                CallLightBg
                            )
                        )
                    )
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                // Top security & real-time WebRTC audio status bar
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .widthIn(max = 540.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = CallLightCard,
                        shadowElevation = 1.dp,
                        modifier = Modifier.border(1.dp, CallLightBorder, RoundedCornerShape(999.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, tint = StatusOnlineGreen, modifier = Modifier.size(14.dp))
                            Text(
                                text = "Audio E2EE",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = CallMutedText
                            )
                        }
                    }
                    AudioDspBadge(
                        telemetry = audioTelemetry,
                        isLightSurface = true,
                        onClick = { showDetailsPanel = !showDetailsPanel }
                    )
                }

                // Center detailed profile portrait, contact metadata, live chronometer & optional inspector
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 48.dp, bottom = 104.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val compactHeight = maxHeight < 420.dp
                    val avatarSize = if (compactHeight) 88.dp else 148.dp
                    val topSpacer = if (compactHeight) 10.dp else 20.dp
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 460.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CallPeerPhotoAvatar(
                            name = peerName,
                            avatarUrl = peerAvatarUrl,
                            size = avatarSize,
                            ringAnimated = call.status == "calling",
                            isLightSurface = true,
                            modifier = Modifier.clickable { showDetailsPanel = !showDetailsPanel }
                        )
                        Spacer(Modifier.height(topSpacer))
                        Text(
                            text = peerName,
                            style = if (compactHeight) MaterialTheme.typography.titleLarge else MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = CallSlateText,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("call_peer_name")
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .clickable { showDetailsPanel = !showDetailsPanel }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = peerSubtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CallMutedText,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(
                                imageVector = if (showDetailsPanel) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                contentDescription = "Détails du contact",
                                tint = CallMutedText,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Spacer(Modifier.height(if (compactHeight) 8.dp else 14.dp))

                        // Status chip
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = when {
                                session.isOnHold || session.isRemoteOnHold || call.status == "on_hold" -> StatusBusyAmber.copy(alpha = 0.14f)
                                session.connectionState == WebRtcConnectionState.FAILED -> EndCallRed.copy(alpha = 0.12f)
                                session.connectionState == WebRtcConnectionState.CONNECTED -> CallActionGreen.copy(alpha = 0.12f)
                                else -> BravPurple.copy(alpha = 0.1f)
                            },
                            modifier = Modifier.testTag("call_status_pill")
                        ) {
                            Text(
                                text = stateLabel,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    session.isOnHold || session.isRemoteOnHold || call.status == "on_hold" -> Color(0xFFB45309)
                                    session.connectionState == WebRtcConnectionState.FAILED -> EndCallRed
                                    session.connectionState == WebRtcConnectionState.CONNECTED -> CallActionGreen
                                    else -> BravPurple
                                },
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                            )
                        }

                        // Dedicated tabular chronometer when connected or non-zero
                        if (isEstablished) {
                            Spacer(Modifier.height(if (compactHeight) 6.dp else 10.dp))
                            Text(
                                text = chronometerText,
                                style = TextStyle(
                                    fontFeatureSettings = "tnum",
                                    fontSize = if (compactHeight) 26.sp else 32.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                ),
                                color = if (session.isOnHold || session.isRemoteOnHold) Color(0xFFB45309) else CallSlateText,
                                modifier = Modifier.testTag("call_chronometer_text")
                            )
                        }

                        AnimatedVisibility(
                            visible = showDetailsPanel,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            CallDetailsExpandedCard(
                                peerSubtitle = peerSubtitle,
                                peerCity = peerCity,
                                stateLabel = stateLabel,
                                telemetry = audioTelemetry,
                                isLightSurface = true
                            )
                        }
                    }
                }

                // Elevated bottom dock for Audio WebRTC controls
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = CallLightCard,
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .widthIn(max = 500.dp)
                        .border(1.dp, CallLightBorder, RoundedCornerShape(28.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Top
                    ) {
                        CallCommandButton(
                            icon = if (session.isMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                            label = if (session.isMuted) "Coupé" else "Micro",
                            active = session.isMuted,
                            activeBg = EndCallRed,
                            isLightSurface = true,
                            testTag = "toggle_mic_button",
                            onClick = onToggleMute
                        )
                        CallCommandButton(
                            icon = if (session.isSpeakerOn) Icons.AutoMirrored.Rounded.VolumeUp else Icons.Rounded.PhoneInTalk,
                            label = if (session.isSpeakerOn) "HP actif" else "Haut-parleur",
                            active = session.isSpeakerOn,
                            activeBg = BravPurple,
                            isLightSurface = true,
                            testTag = "toggle_speaker_button",
                            onClick = onToggleSpeaker
                        )
                        CallCommandButton(
                            icon = if (session.isOnHold) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                            label = if (session.isOnHold) "Reprendre" else "Attente",
                            active = session.isOnHold,
                            activeBg = StatusBusyAmber,
                            isLightSurface = true,
                            testTag = "toggle_hold_button",
                            onClick = onToggleHold
                        )
                        HangupCommandButton(isLightSurface = true, onHangup = onHangup)
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoMediaButtons(
    session: WebRtcSessionState,
    onToggleMute: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onToggleHold: () -> Unit,
    onToggleCamera: () -> Unit,
    onSwitchCamera: () -> Unit,
    buttonSize: Dp
) {
    CallCommandButton(
        icon = if (session.isMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
        label = if (session.isMuted) "Coupé" else "Micro",
        active = session.isMuted,
        activeBg = EndCallRed,
        isLightSurface = false,
        size = buttonSize,
        testTag = "toggle_mic_button",
        onClick = onToggleMute
    )
    CallCommandButton(
        icon = if (session.isSpeakerOn) Icons.AutoMirrored.Rounded.VolumeUp else Icons.Rounded.PhoneInTalk,
        label = "HP",
        active = session.isSpeakerOn,
        activeBg = BravPurple,
        isLightSurface = false,
        size = buttonSize,
        testTag = "toggle_speaker_button",
        onClick = onToggleSpeaker
    )
    CallCommandButton(
        icon = if (session.isOnHold) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
        label = if (session.isOnHold) "Reprendre" else "Attente",
        active = session.isOnHold,
        activeBg = StatusBusyAmber,
        isLightSurface = false,
        size = buttonSize,
        testTag = "toggle_hold_button",
        onClick = onToggleHold
    )
    CallCommandButton(
        icon = if (session.isCameraEnabled) Icons.Rounded.Videocam else Icons.Rounded.VideocamOff,
        label = "Caméra",
        active = !session.isCameraEnabled,
        activeBg = Color(0xFF475569),
        isLightSurface = false,
        size = buttonSize,
        testTag = "toggle_camera_button",
        onClick = onToggleCamera
    )
    CallCommandButton(
        icon = Icons.Rounded.Cameraswitch,
        label = "Inverser",
        active = false,
        enabled = session.isCameraEnabled,
        isLightSurface = false,
        size = buttonSize,
        testTag = "switch_camera_button",
        onClick = onSwitchCamera
    )
}

@Composable
private fun CallDetailsExpandedCard(
    peerSubtitle: String,
    peerCity: String?,
    stateLabel: String,
    telemetry: VoiceAudioTelemetry,
    isLightSurface: Boolean
) {
    val bg = if (isLightSurface) CallLightCard else Color(0xFF1E293B)
    val fg = if (isLightSurface) CallSlateText else Color.White
    val sub = if (isLightSurface) CallMutedText else Color(0xFFCBD5E1)
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = bg,
        shadowElevation = if (isLightSurface) 2.dp else 0.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp)
            .border(1.dp, if (isLightSurface) CallLightBorder else Color.White.copy(alpha = 0.12f), RoundedCornerShape(18.dp))
            .testTag("call_details_panel")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Rounded.Phone, contentDescription = null, tint = BravPurple, modifier = Modifier.size(15.dp))
                Text(
                    text = listOfNotNull(peerSubtitle, peerCity).joinToString(" • "),
                    style = MaterialTheme.typography.labelMedium,
                    color = fg,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = "État flux : $stateLabel",
                style = MaterialTheme.typography.labelSmall,
                color = sub
            )
            LinearProgressIndicator(
                progress = { telemetry.inputLevel.coerceIn(0f, 1f) },
                color = if (telemetry.speechDetected) StatusOnlineGreen else BravPurple,
                trackColor = if (isLightSurface) Color(0xFFE2E8F0) else Color.White.copy(alpha = 0.15f),
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(999.dp))
            )
            val aecMode = if (telemetry.hwAecEnabled) "AEC Matériel" else if (telemetry.echoCancellationActive) "AEC WebRTC" else "Désactivé"
            val nsMode = if (telemetry.hwNsEnabled) "NS Matériel + DSP" else if (telemetry.noiseSuppressionActive) "DSP BRAV" else "Désactivé"
            Text(
                text = "AEC : $aecMode • NS : $nsMode • Trames transmises : ${telemetry.processedCaptureFrames}",
                style = MaterialTheme.typography.labelSmall,
                color = sub
            )
        }
    }
}

@Composable
private fun AudioDspBadge(
    telemetry: VoiceAudioTelemetry,
    isLightSurface: Boolean,
    onClick: () -> Unit = {}
) {
    val aecActive = telemetry.hwAecEnabled || telemetry.echoCancellationActive
    val nsActive = telemetry.hwNsEnabled || telemetry.noiseSuppressionActive
    val aecTag = if (telemetry.hwAecEnabled) "AEC Matériel" else if (aecActive) "AEC WebRTC" else null
    val label = when {
        telemetry.voicePriorityActive && nsActive && aecActive ->
            if (telemetry.noiseReductionDb >= 2f && !telemetry.speechDetected) {
                "Voix prioritaire • NS (-${telemetry.noiseReductionDb.toInt()} dB) • $aecTag"
            } else {
                "Voix prioritaire • NS + $aecTag"
            }
        nsActive && aecActive -> "Anti-bruit + $aecTag actifs"
        nsActive -> "Réduction du bruit active"
        aecActive -> "$aecTag actif"
        telemetry.voicePriorityActive -> "Priorité vocale active"
        else -> "Audio standard"
    }
    val tint = if (telemetry.speechDetected) CallActionGreen else if (isLightSurface) BravPurple else Color(0xFFA7F3D0)
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = if (isLightSurface) CallLightCard else Color.White.copy(alpha = 0.1f),
        onClick = onClick,
        modifier = Modifier
            .testTag("audio_dsp_badge")
            .then(if (isLightSurface) Modifier.border(1.dp, CallLightBorder, RoundedCornerShape(999.dp)) else Modifier)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(Icons.Rounded.GraphicEq, contentDescription = "Détails du traitement audio", tint = tint, modifier = Modifier.size(14.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isLightSurface) CallMutedText else Color.White.copy(alpha = 0.9f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CallCommandButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    activeBg: Color = BravPurple,
    enabled: Boolean = true,
    isLightSurface: Boolean,
    size: Dp = 54.dp,
    testTag: String,
    onClick: () -> Unit
) {
    val bgColor = when {
        !enabled -> if (isLightSurface) Color(0xFFE2E8F0) else Color.White.copy(alpha = 0.06f)
        active -> activeBg
        isLightSurface -> Color(0xFFF1F5F9)
        else -> Color.White.copy(alpha = 0.14f)
    }
    val iconTint = when {
        !enabled -> if (isLightSurface) Color(0xFF94A3B8) else Color.White.copy(alpha = 0.35f)
        active -> Color.White
        isLightSurface -> CallSlateText
        else -> Color.White
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            shape = CircleShape,
            color = bgColor,
            enabled = enabled,
            onClick = onClick,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .size(size)
                .testTag(testTag)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = iconTint, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            color = if (isLightSurface) CallMutedText else Color.White.copy(alpha = 0.85f),
            maxLines = 1
        )
    }
}

@Composable
private fun HangupCommandButton(
    isLightSurface: Boolean,
    size: Dp = 54.dp,
    onHangup: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            shape = CircleShape,
            color = EndCallRed,
            onClick = onHangup,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .size(size)
                .testTag("hangup_call_button")
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.CallEnd, contentDescription = "Raccrocher", tint = Color.White, modifier = Modifier.size(25.dp))
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Terminer",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isLightSurface) EndCallRed else Color(0xFFFCA5A5),
            maxLines = 1
        )
    }
}

fun formatCallChronometer(elapsedSeconds: Long): String {
    val safe = elapsedSeconds.coerceAtLeast(0L)
    val h = safe / 3600L
    val m = (safe % 3600L) / 60L
    val s = safe % 60L
    return if (h > 0L) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
