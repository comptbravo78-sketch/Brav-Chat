package com.example.repository

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

class AiTranslationRepository {

    private val model by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    suspend fun translateMessage(text: String, targetLanguage: String): Result<String> {
        if (text.isBlank()) return Result.failure(IllegalArgumentException("Message vide"))
        return try {
            val prompt = """
                Traduis fidèlement le message suivant vers "$targetLanguage".
                Retourne uniquement la traduction exacte, sans préambule ni explication, en conservant les émojis et le ton d'origine.

                Message:
                $text
            """.trimIndent()

            val response = withTimeout(60_000L) {
                model.generateContent(prompt)
            }
            val translated = response.text?.trim()
            if (translated.isNullOrBlank()) {
                Result.failure(IllegalStateException("Réponse vide du modèle de traduction."))
            } else {
                Result.success(translated)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Translation timed out", e)
            Result.failure(IllegalStateException("Délai de traduction dépassé (60s). Réessayez."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI translation failed", e)
            Result.failure(e)
        }
    }

    companion object {
        private const val TAG = "AiTranslationRepo"
        val supportedLanguages = listOf(
            "Français",
            "Anglais",
            "Espagnol",
            "Arabe",
            "Portugais",
            "Allemand",
            "Chinois"
        )
    }
}
