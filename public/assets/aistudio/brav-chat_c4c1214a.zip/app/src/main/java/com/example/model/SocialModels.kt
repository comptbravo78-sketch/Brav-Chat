package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class StatusPost(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userAvatar: String = "",
    val type: String = "text", // text | image | video
    val text: String = "",
    val caption: String = "",
    val mediaUrl: String = "",
    val backgroundColor: String = "#570CA2",
    val audienceType: String = "all", // all | selected
    val allowedUids: List<String> = emptyList(),
    val viewerIds: List<String> = emptyList(),
    val likedByUids: List<String> = emptyList(),
    val reactions: Map<String, List<String>> = emptyMap(),
    val commentCount: Long = 0L,
    val expiresAtMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StatusComment(
    @DocumentId val id: String = "",
    val statusId: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorAvatar: String = "",
    val text: String = "",
    val reactionKey: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class LiveLocationShare(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val ownerName: String = "",
    val recipientUids: List<String> = emptyList(),
    val encryptedCoords: String = "",
    val encryptionIv: String = "",
    val senderPublicKey: String = "",
    @get:PropertyName("isEncrypted") @field:PropertyName("isEncrypted")
    val isEncrypted: Boolean = true,
    val active: Boolean = true,
    val expiresAtMs: Long = 0L,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class OfferListing(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorName: String = "",
    val title: String = "",
    val category: String = "",
    val description: String = "",
    val locationCity: String = "",
    val priceOrSalary: String = "",
    val imageUrl: String = "",
    val status: String = "published",
    val paymentStatus: String = "free",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AbuseReport(
    @DocumentId val id: String = "",
    val reporterId: String = "",
    val targetUid: String = "",
    val conversationId: String = "",
    val messageId: String = "",
    val reason: String = "",
    val details: String = "",
    val status: String = "pending",
    @ServerTimestamp val createdAt: Timestamp? = null
)
