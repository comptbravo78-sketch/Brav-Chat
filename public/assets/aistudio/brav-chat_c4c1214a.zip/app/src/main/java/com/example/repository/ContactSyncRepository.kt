package com.example.repository

import android.content.Context
import android.provider.ContactsContract
import com.example.R
import com.example.model.Contact
import com.example.model.ContactRequest
import com.example.model.User
import com.example.network.WorkerApiClient
import com.example.util.OperationType
import com.example.util.PhoneUtils
import com.example.util.handleFirestoreError
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class ContactSyncRepository(
    private val db: FirebaseFirestore,
    private val workerApiClient: WorkerApiClient? = null,
    private val appContext: Context? = null
) {
    constructor(context: Context, workerApiClient: WorkerApiClient? = null) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        workerApiClient = workerApiClient,
        appContext = context.applicationContext
    )

    fun observeSavedContactUids(myUid: String): Flow<List<Pair<String, Timestamp?>>> {
        return db.collection("users").document(myUid).collection("contacts")
            .snapshots()
            .map { snap ->
                snap.documents.map { doc ->
                    doc.id to doc.getTimestamp("addedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedByDescending { it.second ?: Timestamp(0, 0) }
            }
    }

    fun observeIncomingRequests(myUid: String): Flow<List<ContactRequest>> {
        return db.collection("contact_requests")
            .whereEqualTo("toUid", myUid)
            .snapshots()
            .map { snap ->
                snap.toObjects(ContactRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.status == "pending" }
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
    }

    fun observeOutgoingRequests(myUid: String): Flow<List<ContactRequest>> {
        return db.collection("contact_requests")
            .whereEqualTo("fromUid", myUid)
            .snapshots()
            .map { snap ->
                snap.toObjects(ContactRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.status == "pending" }
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
    }

    suspend fun fetchUsersByIds(uids: List<String>): List<User> {
        if (uids.isEmpty()) return emptyList()
        val results = mutableListOf<User>()
        for (chunk in uids.distinct().chunked(10)) {
            runCatching {
                val snap = db.collection("users").whereIn("userId", chunk).get().await()
                results.addAll(snap.toObjects(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE))
            }
        }
        return results
    }

    /**
     * Real smart search by:
     * 1. Exact phone number (SHA-256 lookup hash)
     * 2. Exact email (SHA-256 lookup hash)
     * 3. Exact @username or prefix
     * 4. Display name / city search via Firestore & Cloudflare Worker /v1/search
     */
    suspend fun searchUsers(query: String, myUid: String): List<User> {
        val q = query.trim()
        if (q.isBlank()) return emptyList()

        val found = linkedMapOf<String, User>()

        // 1. Phone hash lookup
        val normalizedPhone = PhoneUtils.normalize(q)
        if (normalizedPhone.count { it.isDigit() } >= 6) {
            val phoneHash = PhoneUtils.sha256LookupHash(normalizedPhone)
            runCatching {
                val snap = db.collection("users")
                    .whereEqualTo("phoneLookupHash", phoneHash)
                    .limit(10)
                    .get()
                    .await()
                snap.toObjects(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .forEach { found[it.userId] = it }
            }
        }

        // 2. Email hash lookup
        if (q.contains("@") && q.contains(".")) {
            val emailHash = PhoneUtils.sha256LookupHash(q)
            runCatching {
                val snap = db.collection("users")
                    .whereEqualTo("emailLookupHash", emailHash)
                    .limit(10)
                    .get()
                    .await()
                snap.toObjects(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .forEach { found[it.userId] = it }
            }
        }

        // 3. @username lookup
        val cleanUsername = q.removePrefix("@").lowercase()
        if (cleanUsername.length >= 2) {
            runCatching {
                val snap = db.collection("users")
                    .whereGreaterThanOrEqualTo("username", cleanUsername)
                    .whereLessThanOrEqualTo("username", "$cleanUsername\uf8ff")
                    .limit(15)
                    .get()
                    .await()
                snap.toObjects(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .forEach { found[it.userId] = it }
            }
        }

        // 4. Worker full-text user search (/v1/search?type=users)
        if (workerApiClient != null) {
            workerApiClient.search(query = q, type = "users", limit = 20).getOrNull()?.users?.forEach { map ->
                val uid = map["userId"]?.toString() ?: map["id"]?.toString() ?: ""
                if (uid.isNotBlank() && uid !in found) {
                    val user = getUserSafe(uid)
                    if (user != null) found[uid] = user
                }
            }
        }

        // 5. Fallback Firestore directory prefix/substring match (authenticated users only)
        if (found.size < 10) {
            runCatching {
                val snap = db.collection("users").limit(60).get().await()
                snap.toObjects(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter {
                        it.displayName.contains(q, ignoreCase = true) ||
                            it.username.contains(cleanUsername, ignoreCase = true) ||
                            it.locationCity.contains(q, ignoreCase = true)
                    }
                    .forEach { found[it.userId] = it }
            }
        }

        found.remove(myUid)
        return found.values.toList()
    }

    private suspend fun getUserSafe(uid: String): User? {
        return runCatching {
            db.collection("users").document(uid).get().await()
                .toObject(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        }.getOrNull()
    }

    /**
     * Reads real device contacts (only when READ_CONTACTS permission is granted) and matches them
     * securely against BRAV Chat users using phoneLookupHash (never exposing raw numbers publicly).
     */
    suspend fun syncPhoneContacts(myUid: String): List<Contact> = withContext(Dispatchers.IO) {
        val ctx = appContext ?: return@withContext emptyList()
        val rawContacts = mutableListOf<Triple<String, String, String>>() // name, raw, normalized
        val seenNormalized = mutableSetOf<String>()

        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx).orEmpty() else ""
                    val raw = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else ""
                    val norm = PhoneUtils.normalize(raw)
                    if (norm.isNotBlank() && seenNormalized.add(norm)) {
                        rawContacts.add(Triple(name, raw, norm))
                    }
                }
            }
        } catch (e: SecurityException) {
            return@withContext emptyList()
        }

        if (rawContacts.isEmpty()) return@withContext emptyList()

        val hashToUser = mutableMapOf<String, User>()
        val hashes = rawContacts.map { PhoneUtils.sha256LookupHash(it.third) }.distinct()
        for (chunk in hashes.chunked(10)) {
            runCatching {
                val snap = db.collection("users").whereIn("phoneLookupHash", chunk).get().await()
                snap.toObjects(User::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.userId != myUid }
                    .forEach { u ->
                        if (u.phoneLookupHash.isNotBlank()) hashToUser[u.phoneLookupHash] = u
                    }
            }
        }

        rawContacts.map { (name, raw, norm) ->
            val hash = PhoneUtils.sha256LookupHash(norm)
            val matchedUser = hashToUser[hash]
            Contact(
                id = matchedUser?.userId ?: norm,
                phoneDisplayName = name,
                rawPhoneNumber = raw,
                normalizedPhoneNumber = norm,
                bravUser = matchedUser
            )
        }.sortedWith(compareByDescending<Contact> { it.isBravUser }.thenBy { it.preferredDisplayName })
    }

    suspend fun sendContactRequest(fromUser: User, toUser: User): Result<Unit> {
        val requestId = "${fromUser.userId}_${toUser.userId}".replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val ref = db.collection("contact_requests").document(requestId)
        return try {
            ref.set(
                mapOf(
                    "fromUid" to fromUser.userId,
                    "fromName" to fromUser.displayName.take(120),
                    "fromUsername" to fromUser.username.take(64),
                    "toUid" to toUser.userId,
                    "toName" to toUser.displayName.take(120),
                    "status" to "pending",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun acceptContactRequest(request: ContactRequest, myUid: String): Result<Unit> {
        val reqRef = db.collection("contact_requests").document(request.id)
        val myContactRef = db.collection("users").document(myUid).collection("contacts").document(request.fromUid)
        return try {
            reqRef.update(
                mapOf(
                    "status" to "accepted",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            myContactRef.set(
                mapOf(
                    "contactUid" to request.fromUid,
                    "alias" to request.fromName.take(100),
                    "addedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, reqRef.path)
            Result.failure(e)
        }
    }

    suspend fun declineContactRequest(request: ContactRequest): Result<Unit> {
        val reqRef = db.collection("contact_requests").document(request.id)
        return try {
            reqRef.update(
                mapOf(
                    "status" to "declined",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, reqRef.path)
            Result.failure(e)
        }
    }

    suspend fun addContactDirectly(myUid: String, targetUser: User): Result<Unit> {
        val ref = db.collection("users").document(myUid).collection("contacts").document(targetUser.userId)
        return try {
            ref.set(
                mapOf(
                    "contactUid" to targetUser.userId,
                    "alias" to targetUser.displayName.take(100),
                    "addedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            Result.failure(e)
        }
    }

    suspend fun removeContact(myUid: String, contactUid: String): Result<Unit> {
        val ref = db.collection("users").document(myUid).collection("contacts").document(contactUid)
        return try {
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path)
            Result.failure(e)
        }
    }
}
