package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.example.media.VoiceAudioTelemetry
import com.example.media.WebRtcConnectionState
import com.example.media.WebRtcSessionState
import com.example.model.Call
import com.example.model.User
import com.example.ui.screens.CallScreenContent
import com.example.ui.screens.formatCallChronometer
import com.example.ui.theme.BravChatTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CallScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun formatCallChronometer_formatsMinutesSecondsAndHours() {
        assertEquals("00:00", formatCallChronometer(0L))
        assertEquals("02:05", formatCallChronometer(125L))
        assertEquals("01:02:03", formatCallChronometer(3723L))
    }

    @Test
    fun audioCallScreen_displaysPeerDetailsChronometerAndAudioControls() {
        var micClicked = 0
        var speakerClicked = 0
        var holdClicked = 0
        var hangupClicked = 0

        val call = Call(
            id = "call_audio_1",
            callerId = "me_uid",
            callerName = "Moi",
            receiverId = "peer_uid",
            receiverName = "Amina Diallo",
            receiverUsername = "amina.d",
            callType = "audio",
            status = "accepted"
        )
        val peer = User(
            userId = "peer_uid",
            displayName = "Amina Diallo",
            username = "amina.d",
            phoneMasked = "+33 6 •• •• 56 78",
            locationCity = "Lyon"
        )
        val session = WebRtcSessionState(
            callId = "call_audio_1",
            isVideoCall = false,
            isCaller = true,
            connectionState = WebRtcConnectionState.CONNECTED,
            elapsedSeconds = 125L
        )
        val telemetry = VoiceAudioTelemetry(
            hwAecEnabled = true,
            hwNsEnabled = true,
            noiseSuppressionActive = true,
            echoCancellationActive = true,
            voicePriorityActive = true,
            processedCaptureFrames = 320L
        )

        composeTestRule.setContent {
            BravChatTheme(darkTheme = false) {
                CallScreenContent(
                    call = call,
                    currentUserId = "me_uid",
                    peerUser = peer,
                    session = session,
                    audioTelemetry = telemetry,
                    onToggleMute = { micClicked++ },
                    onToggleSpeaker = { speakerClicked++ },
                    onToggleHold = { holdClicked++ },
                    onHangup = { hangupClicked++ }
                )
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("call_peer_name").assertIsDisplayed().assertTextContains("Amina Diallo")
        composeTestRule.onNodeWithTag("call_chronometer_text").assertIsDisplayed().assertTextContains("02:05")
        composeTestRule.onNodeWithText("@amina.d • +33 6 •• •• 56 78").assertIsDisplayed()
        composeTestRule.onNodeWithTag("audio_dsp_badge").assertIsDisplayed()

        // Tap DSP badge to open detailed peer & WebRTC telemetry card
        composeTestRule.onNodeWithTag("audio_dsp_badge").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("call_details_panel").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithText("Trames transmises : 320", substring = true).performScrollTo().assertIsDisplayed()

        composeTestRule.onNodeWithTag("toggle_mic_button").performClick()
        composeTestRule.onNodeWithTag("toggle_speaker_button").performClick()
        composeTestRule.onNodeWithTag("toggle_hold_button").performClick()
        composeTestRule.onNodeWithTag("hangup_call_button").performClick()
        composeTestRule.waitForIdle()

        assertEquals(1, micClicked)
        assertEquals(1, speakerClicked)
        assertEquals(1, holdClicked)
        assertEquals(1, hangupClicked)
    }

    @Test
    fun videoCallScreen_displaysVideoControlsAndTriggersCameraActions() {
        var camClicked = 0
        var switchClicked = 0
        var hangupClicked = 0

        val call = Call(
            id = "call_video_1",
            callerId = "peer_uid",
            callerName = "Marc Kouassi",
            callerUsername = "marck",
            receiverId = "me_uid",
            receiverName = "Moi",
            callType = "video",
            status = "accepted"
        )
        val session = WebRtcSessionState(
            callId = "call_video_1",
            isVideoCall = true,
            isCaller = false,
            connectionState = WebRtcConnectionState.CONNECTED,
            isCameraEnabled = true,
            elapsedSeconds = 64L
        )

        composeTestRule.setContent {
            BravChatTheme(darkTheme = true) {
                CallScreenContent(
                    call = call,
                    currentUserId = "me_uid",
                    session = session,
                    audioTelemetry = VoiceAudioTelemetry(),
                    onToggleMute = {},
                    onToggleSpeaker = {},
                    onToggleHold = {},
                    onToggleCamera = { camClicked++ },
                    onSwitchCamera = { switchClicked++ },
                    onHangup = { hangupClicked++ }
                )
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("call_peer_name").assertIsDisplayed().assertTextContains("Marc Kouassi")
        composeTestRule.onNodeWithTag("call_chronometer_text").assertIsDisplayed().assertTextContains("01:04")
        composeTestRule.onNodeWithTag("toggle_camera_button").performClick()
        composeTestRule.onNodeWithTag("switch_camera_button").performClick()
        composeTestRule.onNodeWithTag("hangup_call_button").performClick()
        composeTestRule.waitForIdle()

        assertTrue(camClicked == 1)
        assertTrue(switchClicked == 1)
        assertTrue(hangupClicked == 1)
    }
}
