# Configuration Cloudflare Worker — BRAV Chat

Ce dossier contient la configuration prête à déployer pour relier votre Worker Cloudflare (`bold-darkness-7957.kolopay-ci.workers.dev`) à vos ressources :

- **Bucket R2** : `bravchat` (WEUR)
- **Base D1** : `brav_chat` (`005a0119-2bb4-40ce-a50c-b3c3a461bc19`)
- **Realtime Serverless SFU App** : `brav_chat` (`00e84148168d52e644ef50bc3824ff3b`)
- **Projet Firebase** : `brav-chat`

## Commandes de déploiement (depuis `/cloudflare`)

1. Initialiser les tables D1 :
   ```bash
   npx wrangler d1 execute brav_chat --remote --file=schema.sql
   ```

2. Enregistrer vos jetons secrets Cloudflare Calls / TURN (ne jamais les mettre dans le code Android) :
   ```bash
   npx wrangler secret put SFU_API_TOKEN
   npx wrangler secret put TURN_TOKEN_ID
   npx wrangler secret put TURN_API_TOKEN
   ```

3. Déployer le Worker et activer R2 + D1 + Durable Objects + SFU :
   ```bash
   npx wrangler deploy
   ```

4. Vérifier que tous les services sont actifs :
   ```bash
   curl https://bold-darkness-7957.kolopay-ci.workers.dev/v1/config
   ```
   `"media": true`, `"realtimeHub": true`, `"callSignaling": true`, `"sfu": true`, `"search": true` doivent tous passer à `true`.
