-- BRAV Chat Cloudflare D1 Schema (database: brav_chat / 005a0119-2bb4-40ce-a50c-b3c3a461bc19)

CREATE TABLE IF NOT EXISTS users_index (
  user_id TEXT PRIMARY KEY,
  display_name TEXT NOT NULL DEFAULT '',
  username TEXT NOT NULL DEFAULT '',
  location_city TEXT NOT NULL DEFAULT '',
  avatar_url TEXT NOT NULL DEFAULT '',
  online INTEGER NOT NULL DEFAULT 0,
  last_seen_ms INTEGER NOT NULL DEFAULT 0,
  updated_at_ms INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_users_username ON users_index(username);
CREATE INDEX IF NOT EXISTS idx_users_display_name ON users_index(display_name);

CREATE TABLE IF NOT EXISTS offers_index (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  location_city TEXT NOT NULL DEFAULT '',
  price_or_salary TEXT NOT NULL DEFAULT 'Gratuit',
  author_name TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'published',
  payment_status TEXT NOT NULL DEFAULT 'free',
  created_at_ms INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_offers_category ON offers_index(category);
CREATE INDEX IF NOT EXISTS idx_offers_city ON offers_index(location_city);

CREATE TABLE IF NOT EXISTS media_objects (
  object_key TEXT PRIMARY KEY,
  owner_uid TEXT NOT NULL,
  conversation_id TEXT NOT NULL,
  file_name TEXT NOT NULL DEFAULT '',
  content_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  created_at_ms INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_media_conv ON media_objects(conversation_id);
CREATE INDEX IF NOT EXISTS idx_media_owner ON media_objects(owner_uid);

CREATE TABLE IF NOT EXISTS device_tokens (
  token TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  platform TEXT NOT NULL DEFAULT 'android',
  updated_at_ms INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_devices_user ON device_tokens(user_id);

CREATE TABLE IF NOT EXISTS call_sfu_sessions (
  call_id TEXT NOT NULL,
  session_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  tracks_json TEXT NOT NULL DEFAULT '[]',
  updated_at_ms INTEGER NOT NULL,
  PRIMARY KEY (call_id, session_id)
);
