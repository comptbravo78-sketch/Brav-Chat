/**
 * BRAV Chat Cloudflare Worker v3.1.0
 * - R2 Bucket: bravchat (WEUR)
 * - D1 Database: brav_chat (005a0119-2bb4-40ce-a50c-b3c3a461bc19)
 * - Serverless SFU App: brav_chat (00e84148168d52e644ef50bc3824ff3b)
 * - Firebase Auth JWT verification for project: brav-chat
 */

const WS_SUBPROTOCOL = "brav.v1";
const ALLOWED_MEDIA_TYPES = [
  "image/jpeg", "image/png", "image/webp", "image/gif",
  "audio/mpeg", "audio/mp4", "audio/aac", "audio/ogg", "audio/webm", "audio/wav", "audio/x-wav", "audio/3gpp", "audio/amr",
  "video/mp4", "video/webm", "video/3gpp", "video/quicktime",
  "application/pdf", "application/octet-stream"
];

let cachedJwks = null;
let cachedJwksExpiresAt = 0;

function corsHeaders(request) {
  const origin = request.headers.get("Origin") || "*";
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Authorization, Content-Type, Range, X-Request-Id, X-Brav-Bucket",
    "Access-Control-Expose-Headers": "Content-Range, Accept-Ranges, Content-Length, ETag, X-Request-Id",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}

function jsonResponse(request, data, status = 200, requestId = crypto.randomUUID()) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders(request),
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "X-Request-Id": requestId
    }
  });
}

function base64UrlToUint8Array(str) {
  const pad = "=".repeat((4 - (str.length % 4)) % 4);
  const b64 = (str + pad).replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function decodeJwtPart(part) {
  const bytes = base64UrlToUint8Array(part);
  return JSON.parse(new TextDecoder().decode(bytes));
}

async function fetchFirebaseJwks() {
  const now = Date.now();
  if (cachedJwks && now < cachedJwksExpiresAt) return cachedJwks;
  const res = await fetch(
    "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"
  );
  if (!res.ok) throw new Error("JWKS_FETCH_FAILED");
  const jwks = await res.json();
  cachedJwks = jwks.keys || [];
  cachedJwksExpiresAt = now + 3600_000;
  return cachedJwks;
}

async function verifyFirebaseAuth(request, env) {
  const auth = request.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return null;
  const token = auth.slice(7).trim();
  const parts = token.split(".");
  if (parts.length !== 3) return null;

  try {
    const header = decodeJwtPart(parts[0]);
    const payload = decodeJwtPart(parts[1]);
    const projectId = env.FIREBASE_PROJECT_ID || "brav-chat";
    const nowSec = Math.floor(Date.now() / 1000);

    if (header.alg !== "RS256" || !header.kid) return null;
    if (payload.aud !== projectId) return null;
    if (payload.iss !== `https://securetoken.google.com/${projectId}`) return null;
    if (!payload.sub || typeof payload.sub !== "string") return null;
    if (typeof payload.exp !== "number" || payload.exp <= nowSec) return null;

    const keys = await fetchFirebaseJwks();
    const jwk = keys.find((k) => k.kid === header.kid);
    if (!jwk) return null;

    const cryptoKey = await crypto.subtle.importKey(
      "jwk",
      jwk,
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false,
      ["verify"]
    );
    const sig = base64UrlToUint8Array(parts[2]);
    const data = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
    const valid = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", cryptoKey, sig, data);
    if (!valid) return null;

    return {
      uid: payload.sub,
      email: payload.email || "",
      emailVerified: Boolean(payload.email_verified)
    };
  } catch {
    return null;
  }
}

function extFromMime(mime, fallbackName = "") {
  const fromName = fallbackName.includes(".") ? fallbackName.split(".").pop().toLowerCase().replace(/[^a-z0-9]/g, "") : "";
  if (fromName) return fromName.slice(0, 8);
  const map = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
    "audio/mp4": "m4a",
    "audio/aac": "aac",
    "audio/mpeg": "mp3",
    "audio/ogg": "ogg",
    "audio/webm": "webm",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "application/pdf": "pdf"
  };
  return map[mime] || "bin";
}

export default {
  async fetch(request, env) {
    const requestId = crypto.randomUUID();
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders(request) });
    }

    const url = new URL(request.url);
    const path = url.pathname;
    const baseUrl = `${url.protocol}//${url.host}`;
    const wsBaseUrl = baseUrl.replace(/^http/, "ws");
    const sfuAppId = env.SFU_APP_ID || "00e84148168d52e644ef50bc3824ff3b";

    // Public configuration endpoint
    if (request.method === "GET" && path === "/v1/config") {
      const maxUploadMb = Number(env.MAX_UPLOAD_MB || "25");
      return jsonResponse(request, {
        version: "3.1.0",
        baseUrl,
        realtimeUrl: `${wsBaseUrl}/v1/realtime`,
        callSignalUrlTemplate: `${wsBaseUrl}/v1/calls/{callId}/signal`,
        websocketSubprotocol: WS_SUBPROTOCOL,
        sfuAppId,
        r2Bucket: env.R2_BUCKET_NAME || "bravchat",
        d1Database: env.D1_DATABASE_NAME || "brav_chat",
        heartbeat: { clientSends: "ping", serverReplies: "pong", everyMs: 25000 },
        limits: { signalBytes: 32768, uploadMB: maxUploadMb, presenceUidsPerQuery: 100, ringTimeoutMs: 45000 },
        mediaTypes: ALLOWED_MEDIA_TYPES,
        features: {
          auth: true,
          realtimeHub: Boolean(env.USER_HUBS),
          callSignaling: Boolean(env.CALL_ROOMS),
          turn: env.TURN_TOKEN_ID && env.TURN_API_TOKEN ? "cloudflare" : "stun",
          sfu: Boolean(sfuAppId && env.SFU_API_TOKEN),
          media: Boolean(env.R2),
          push: Boolean(env.DB),
          presenceSync: Boolean(env.USER_HUBS),
          missedCalls: Boolean(env.USER_HUBS),
          search: Boolean(env.DB),
          payments: false,
          paymentFinalization: false
        }
      }, 200, requestId);
    }

    // All remaining /v1 routes require Firebase Authentication
    const user = await verifyFirebaseAuth(request, env);
    if (!user) {
      return jsonResponse(request, { error: "UNAUTHORIZED", requestId }, 401, requestId);
    }

    if (request.method === "GET" && path === "/v1/whoami") {
      return jsonResponse(request, { ok: true, uid: user.uid, email: user.email }, 200, requestId);
    }

    // =========================================================================
    // CLOUDFLARE R2 MEDIA STORAGE (bucket: bravchat)
    // =========================================================================
    if (path === "/v1/media" && request.method === "POST") {
      if (!env.R2) {
        return jsonResponse(request, { error: "MEDIA_NOT_CONFIGURED", requestId }, 503, requestId);
      }
      const conversationId = (url.searchParams.get("conversationId") || `user_${user.uid}`).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 128);
      const fileName = (url.searchParams.get("fileName") || "").slice(0, 128);
      const contentType = (request.headers.get("Content-Type") || "application/octet-stream").split(";")[0].trim().toLowerCase();
      const maxBytes = Number(env.MAX_UPLOAD_MB || "25") * 1024 * 1024;
      const bodyBytes = await request.arrayBuffer();

      if (!bodyBytes || bodyBytes.byteLength === 0) {
        return jsonResponse(request, { error: "EMPTY_FILE", requestId }, 400, requestId);
      }
      if (bodyBytes.byteLength > maxBytes) {
        return jsonResponse(request, { error: "FILE_TOO_LARGE", requestId }, 413, requestId);
      }

      const ext = extFromMime(contentType, fileName);
      const objectKey = `c/${conversationId}/${crypto.randomUUID()}.${ext}`;
      await env.R2.put(objectKey, bodyBytes, {
        httpMetadata: {
          contentType,
          cacheControl: "private, max-age=86400"
        },
        customMetadata: {
          ownerUid: user.uid,
          conversationId,
          fileName
        }
      });

      if (env.DB) {
        await env.DB.prepare(
          "INSERT OR REPLACE INTO media_objects (object_key, owner_uid, conversation_id, file_name, content_type, size_bytes, created_at_ms) VALUES (?, ?, ?, ?, ?, ?, ?)"
        ).bind(objectKey, user.uid, conversationId, fileName, contentType, bodyBytes.byteLength, Date.now()).run();
      }

      return jsonResponse(request, {
        ok: true,
        key: objectKey,
        url: `${baseUrl}/v1/media/${objectKey}`,
        size: bodyBytes.byteLength,
        contentType
      }, 201, requestId);
    }

    if (path.startsWith("/v1/media/") && (request.method === "GET" || request.method === "HEAD")) {
      if (!env.R2) {
        return jsonResponse(request, { error: "MEDIA_NOT_CONFIGURED", requestId }, 503, requestId);
      }
      const objectKey = decodeURIComponent(path.slice("/v1/media/".length));
      if (!objectKey) {
        return jsonResponse(request, { error: "NOT_FOUND", requestId }, 404, requestId);
      }
      const rangeHeader = request.headers.get("Range");
      let r2Obj;
      if (rangeHeader) {
        r2Obj = await env.R2.get(objectKey, { range: request.headers });
      } else {
        r2Obj = await env.R2.get(objectKey);
      }
      if (!r2Obj) {
        return jsonResponse(request, { error: "NOT_FOUND", requestId }, 404, requestId);
      }
      const headers = new Headers(corsHeaders(request));
      r2Obj.writeHttpMetadata(headers);
      headers.set("ETag", r2Obj.httpEtag);
      headers.set("Accept-Ranges", "bytes");
      headers.set("X-Content-Type-Options", "nosniff");
      if (r2Obj.range && "offset" in r2Obj.range) {
        const start = r2Obj.range.offset;
        const end = start + r2Obj.range.length - 1;
        headers.set("Content-Range", `bytes ${start}-${end}/${r2Obj.size}`);
        headers.set("Content-Length", String(r2Obj.range.length));
        return new Response(request.method === "HEAD" ? null : r2Obj.body, { status: 206, headers });
      }
      headers.set("Content-Length", String(r2Obj.size));
      return new Response(request.method === "HEAD" ? null : r2Obj.body, { status: 200, headers });
    }

    if (path.startsWith("/v1/media/") && request.method === "DELETE") {
      if (!env.R2) {
        return jsonResponse(request, { error: "MEDIA_NOT_CONFIGURED", requestId }, 503, requestId);
      }
      const objectKey = decodeURIComponent(path.slice("/v1/media/".length));
      const head = await env.R2.head(objectKey);
      if (!head) return jsonResponse(request, { ok: true }, 200, requestId);
      if (head.customMetadata?.ownerUid && head.customMetadata.ownerUid !== user.uid) {
        return jsonResponse(request, { error: "FORBIDDEN", requestId }, 403, requestId);
      }
      await env.R2.delete(objectKey);
      if (env.DB) {
        await env.DB.prepare("DELETE FROM media_objects WHERE object_key = ?").bind(objectKey).run();
      }
      return jsonResponse(request, { ok: true }, 200, requestId);
    }

    // =========================================================================
    // CLOUDFLARE TURN CREDENTIALS
    // =========================================================================
    if (request.method === "GET" && path === "/v1/turn-credentials") {
      const ttl = Math.min(86400, Math.max(60, Number(url.searchParams.get("ttl") || "14400")));
      if (env.TURN_TOKEN_ID && env.TURN_API_TOKEN) {
        const res = await fetch(
          `https://rtc.live.cloudflare.com/v1/turn/keys/${env.TURN_TOKEN_ID}/credentials/generate-ice-servers`,
          {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${env.TURN_API_TOKEN}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ ttl })
          }
        );
        if (res.ok) {
          const data = await res.json();
          return jsonResponse(request, {
            provider: "cloudflare",
            relay: true,
            iceServers: data.iceServers || [],
            expiresAt: Date.now() + ttl * 1000
          }, 200, requestId);
        }
      }
      return jsonResponse(request, {
        provider: "stun-only",
        relay: false,
        iceServers: [{ urls: ["stun:stun.cloudflare.com:3478", "stun:stun.l.google.com:19302"] }],
        expiresAt: Date.now() + ttl * 1000
      }, 200, requestId);
    }

    // =========================================================================
    // CLOUDFLARE REALTIME SERVERLESS SFU (App ID: 00e84148168d52e644ef50bc3824ff3b)
    // =========================================================================
    const sfuSessionMatch = path.match(/^\/v1\/sfu\/calls\/([a-zA-Z0-9_-]+)\/sessions$/);
    if (sfuSessionMatch && request.method === "POST") {
      if (!env.SFU_API_TOKEN) {
        return jsonResponse(request, { error: "SFU_NOT_CONFIGURED", requestId }, 503, requestId);
      }
      const callId = sfuSessionMatch[1];
      const payload = await request.json();
      const cfRes = await fetch(`https://rtc.live.cloudflare.com/v1/apps/${sfuAppId}/sessions/new`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.SFU_API_TOKEN}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ sessionDescription: payload.sessionDescription })
      });
      const cfJson = await cfRes.json();
      if (!cfRes.ok) {
        return jsonResponse(request, { error: "SFU_SESSION_ERROR", details: cfJson, requestId }, cfRes.status, requestId);
      }
      if (env.DB && cfJson.sessionId) {
        await env.DB.prepare(
          "INSERT OR REPLACE INTO call_sfu_sessions (call_id, session_id, user_id, tracks_json, updated_at_ms) VALUES (?, ?, ?, '[]', ?)"
        ).bind(callId, cfJson.sessionId, user.uid, Date.now()).run();
      }
      return jsonResponse(request, cfJson, 200, requestId);
    }

    const sfuTracksMatch = path.match(/^\/v1\/sfu\/calls\/([a-zA-Z0-9_-]+)\/sessions\/([a-zA-Z0-9_-]+)\/tracks$/);
    if (sfuTracksMatch && request.method === "POST") {
      if (!env.SFU_API_TOKEN) {
        return jsonResponse(request, { error: "SFU_NOT_CONFIGURED", requestId }, 503, requestId);
      }
      const [, callId, sessionId] = sfuTracksMatch;
      const payload = await request.json();
      const cfRes = await fetch(`https://rtc.live.cloudflare.com/v1/apps/${sfuAppId}/sessions/${sessionId}/tracks/new`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.SFU_API_TOKEN}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const cfJson = await cfRes.json();
      if (!cfRes.ok) {
        return jsonResponse(request, { error: "SFU_TRACKS_ERROR", details: cfJson, requestId }, cfRes.status, requestId);
      }
      if (env.DB && Array.isArray(payload.tracks)) {
        const localTracks = payload.tracks.filter((t) => t.location === "local");
        if (localTracks.length > 0) {
          await env.DB.prepare(
            "INSERT OR REPLACE INTO call_sfu_sessions (call_id, session_id, user_id, tracks_json, updated_at_ms) VALUES (?, ?, ?, ?, ?)"
          ).bind(callId, sessionId, user.uid, JSON.stringify(localTracks), Date.now()).run();
        }
      }
      return jsonResponse(request, cfJson, 200, requestId);
    }

    const sfuRenegMatch = path.match(/^\/v1\/sfu\/calls\/([a-zA-Z0-9_-]+)\/sessions\/([a-zA-Z0-9_-]+)\/renegotiate$/);
    if (sfuRenegMatch && request.method === "PUT") {
      if (!env.SFU_API_TOKEN) {
        return jsonResponse(request, { error: "SFU_NOT_CONFIGURED", requestId }, 503, requestId);
      }
      const [, , sessionId] = sfuRenegMatch;
      const payload = await request.json();
      const cfRes = await fetch(`https://rtc.live.cloudflare.com/v1/apps/${sfuAppId}/sessions/${sessionId}/renegotiate`, {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${env.SFU_API_TOKEN}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const cfJson = await cfRes.json();
      return jsonResponse(request, cfJson, cfRes.status, requestId);
    }

    const sfuListTracksMatch = path.match(/^\/v1\/sfu\/calls\/([a-zA-Z0-9_-]+)\/tracks$/);
    if (sfuListTracksMatch && request.method === "GET") {
      if (!env.DB) return jsonResponse(request, { tracks: [] }, 200, requestId);
      const callId = sfuListTracksMatch[1];
      const rows = await env.DB.prepare(
        "SELECT session_id, user_id, tracks_json FROM call_sfu_sessions WHERE call_id = ? AND user_id != ?"
      ).bind(callId, user.uid).all();
      const tracks = [];
      for (const row of (rows.results || [])) {
        try {
          const parsed = JSON.parse(row.tracks_json || "[]");
          for (const t of parsed) {
            tracks.push({ location: "remote", sessionId: row.session_id, trackName: t.trackName });
          }
        } catch {}
      }
      return jsonResponse(request, { tracks }, 200, requestId);
    }

    // =========================================================================
    // REALTIME HUB + CALL SIGNALING DURABLE OBJECTS
    // =========================================================================
    if (path === "/v1/realtime") {
      if (!env.USER_HUBS) {
        return jsonResponse(request, { error: "USER_HUBS_BINDING_MISSING", requestId }, 503, requestId);
      }
      const stub = env.USER_HUBS.get(env.USER_HUBS.idFromName(user.uid));
      const fwd = new Request(request.url, request);
      fwd.headers.set("X-Brav-Uid", user.uid);
      return stub.fetch(fwd);
    }

    const callSignalMatch = path.match(/^\/v1\/calls\/([a-zA-Z0-9_-]+)\/signal$/);
    if (callSignalMatch) {
      if (!env.CALL_ROOMS) {
        return jsonResponse(request, { error: "CALL_ROOMS_BINDING_MISSING", requestId }, 503, requestId);
      }
      const stub = env.CALL_ROOMS.get(env.CALL_ROOMS.idFromName(callSignalMatch[1]));
      const fwd = new Request(request.url, request);
      fwd.headers.set("X-Brav-Uid", user.uid);
      return stub.fetch(fwd);
    }

    const callRingMatch = path.match(/^\/v1\/calls\/([a-zA-Z0-9_-]+)\/ring$/);
    if (callRingMatch && request.method === "POST") {
      const callId = callRingMatch[1];
      let body = {};
      try { body = await request.json(); } catch {}
      if (env.USER_HUBS && body.receiverId) {
        try {
          const hub = env.USER_HUBS.get(env.USER_HUBS.idFromName(String(body.receiverId)));
          await hub.fetch(new Request(`${baseUrl}/internal/push`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              type: "incoming_call",
              callId,
              callType: body.callType || "audio",
              callerId: user.uid,
              callerName: body.callerName || "",
              sentAt: Date.now()
            })
          }));
        } catch {}
      }
      return jsonResponse(request, { ok: true, callId }, 200, requestId);
    }

    // =========================================================================
    // D1 DATABASE SYNC & SEARCH (brav_chat)
    // =========================================================================
    if (path === "/v1/users/sync" && request.method === "POST") {
      if (!env.DB) return jsonResponse(request, { ok: false }, 200, requestId);
      const b = await request.json();
      await env.DB.prepare(
        "INSERT OR REPLACE INTO users_index (user_id, display_name, username, location_city, avatar_url, online, last_seen_ms, updated_at_ms) VALUES (?, ?, ?, ?, ?, 1, ?, ?)"
      ).bind(
        user.uid,
        String(b.displayName || "").slice(0, 100),
        String(b.username || "").toLowerCase().slice(0, 40),
        String(b.locationCity || "").slice(0, 120),
        String(b.avatarUrl || "").slice(0, 1000),
        Date.now(),
        Date.now()
      ).run();
      return jsonResponse(request, { ok: true }, 200, requestId);
    }

    if (path === "/v1/offers/sync" && request.method === "POST") {
      if (!env.DB) return jsonResponse(request, { ok: false }, 200, requestId);
      const b = await request.json();
      await env.DB.prepare(
        "INSERT OR REPLACE INTO offers_index (id, user_id, title, category, description, location_city, price_or_salary, author_name, status, payment_status, created_at_ms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'published', 'free', ?)"
      ).bind(
        String(b.id || crypto.randomUUID()),
        user.uid,
        String(b.title || "").slice(0, 160),
        String(b.category || "Services").slice(0, 80),
        String(b.description || "").slice(0, 2000),
        String(b.locationCity || "").slice(0, 120),
        String(b.priceOrSalary || "Gratuit").slice(0, 80),
        String(b.authorName || "").slice(0, 120),
        Date.now()
      ).run();
      return jsonResponse(request, { ok: true }, 200, requestId);
    }

    if (path === "/v1/search" && request.method === "GET") {
      if (!env.DB) return jsonResponse(request, { users: [], offers: [] }, 200, requestId);
      const q = (url.searchParams.get("q") || "").trim();
      const type = url.searchParams.get("type") || "all";
      const limit = Math.min(50, Math.max(1, Number(url.searchParams.get("limit") || "20")));
      const like = `%${q.replace(/^@/, "")}%`;
      let users = [];
      let offers = [];
      if (type === "all" || type === "users") {
        const res = await env.DB.prepare(
          "SELECT user_id AS userId, display_name AS displayName, username, location_city AS locationCity, avatar_url AS avatarUrl FROM users_index WHERE user_id != ? AND (display_name LIKE ? OR username LIKE ? OR location_city LIKE ?) LIMIT ?"
        ).bind(user.uid, like, like, like, limit).all();
        users = res.results || [];
      }
      if (type === "all" || type === "offers") {
        const res = await env.DB.prepare(
          "SELECT id, user_id AS userId, title, category, description, location_city AS locationCity, price_or_salary AS priceOrSalary, author_name AS authorName, status, payment_status AS paymentStatus FROM offers_index WHERE status = 'published' AND (title LIKE ? OR description LIKE ? OR location_city LIKE ?) ORDER BY created_at_ms DESC LIMIT ?"
        ).bind(like, like, like, limit).all();
        offers = res.results || [];
      }
      return jsonResponse(request, { users, offers }, 200, requestId);
    }

    if (path === "/v1/devices" && request.method === "POST") {
      if (env.DB) {
        const b = await request.json();
        await env.DB.prepare(
          "INSERT OR REPLACE INTO device_tokens (token, user_id, platform, updated_at_ms) VALUES (?, ?, ?, ?)"
        ).bind(String(b.token || ""), user.uid, String(b.platform || "android"), Date.now()).run();
      }
      return jsonResponse(request, { ok: true }, 200, requestId);
    }

    if (path === "/v1/devices" && request.method === "DELETE") {
      if (env.DB) {
        const b = await request.json();
        await env.DB.prepare("DELETE FROM device_tokens WHERE token = ? AND user_id = ?").bind(String(b.token || ""), user.uid).run();
      }
      return jsonResponse(request, { ok: true }, 200, requestId);
    }

    if (path === "/v1/presence" && request.method === "GET") {
      const raw = (url.searchParams.get("uids") || "").split(",").map((s) => s.trim()).filter(Boolean).slice(0, 100);
      if (!env.DB || raw.length === 0) return jsonResponse(request, { users: [] }, 200, requestId);
      const placeholders = raw.map(() => "?").join(",");
      const res = await env.DB.prepare(
        `SELECT user_id AS uid, online, last_seen_ms AS lastSeen FROM users_index WHERE user_id IN (${placeholders})`
      ).bind(...raw).all();
      return jsonResponse(request, {
        users: (res.results || []).map((r) => ({ uid: r.uid, online: Boolean(r.online), lastSeen: r.lastSeen || 0 }))
      }, 200, requestId);
    }

    if (path === "/v1/chat/notify" && request.method === "POST") {
      return jsonResponse(request, { ok: true }, 200, requestId);
    }

    return jsonResponse(request, { error: "NOT_FOUND", requestId }, 404, requestId);
  }
};

export class UserHub {
  constructor(state) {
    this.state = state;
    this.sockets = new Set();
  }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === "/internal/push" && request.method === "POST") {
      const payload = await request.text();
      for (const sock of this.sockets) {
        try { sock.send(payload); } catch { this.sockets.delete(sock); }
      }
      return new Response("ok", { status: 200 });
    }
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("Upgrade required", { status: 426 });
    }
    const uid = request.headers.get("X-Brav-Uid") || "";
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    server.accept();
    this.sockets.add(server);

    server.send(JSON.stringify({ type: "ready", uid, deviceId: "android", connections: this.sockets.size }));
    server.addEventListener("message", (ev) => {
      if (ev.data === "ping") {
        server.send("pong");
      }
    });
    server.addEventListener("close", () => this.sockets.delete(server));
    return new Response(null, { status: 101, webSocket: client, headers: { "Sec-WebSocket-Protocol": WS_SUBPROTOCOL } });
  }
}

export class CallRoom {
  constructor(state) {
    this.state = state;
    this.peers = new Map();
  }

  async fetch(request) {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("Upgrade required", { status: 426 });
    }
    const uid = request.headers.get("X-Brav-Uid") || crypto.randomUUID();
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    server.accept();
    this.peers.set(server, uid);

    server.send(JSON.stringify({ type: "room-ready", peers: this.peers.size }));
    for (const [peerSock] of this.peers.entries()) {
      if (peerSock !== server) {
        try { peerSock.send(JSON.stringify({ type: "peer-joined", uid })); } catch {}
      }
    }

    server.addEventListener("message", (ev) => {
      if (ev.data === "ping") {
        server.send("pong");
        return;
      }
      for (const [peerSock] of this.peers.entries()) {
        if (peerSock !== server) {
          try { peerSock.send(ev.data); } catch {}
        }
      }
    });

    const cleanup = () => {
      this.peers.delete(server);
      for (const [peerSock] of this.peers.entries()) {
        try { peerSock.send(JSON.stringify({ type: "peer-left", uid })); } catch {}
      }
    };
    server.addEventListener("close", cleanup);
    server.addEventListener("error", cleanup);

    return new Response(null, { status: 101, webSocket: client, headers: { "Sec-WebSocket-Protocol": WS_SUBPROTOCOL } });
  }
}
