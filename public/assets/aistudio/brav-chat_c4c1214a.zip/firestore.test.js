const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-bravchat-a59c08fd-d746-4b1b-82b9-b5b35a581a65";
const ALICE_UID = "alice_uid_1";
const BOB_UID = "bob_uid_2";
const EVE_UID = "eve_uid_3";
const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function ts(context) {
  return context.firestore().app ? new Date() : new Date();
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) await testEnv.cleanup();
});

beforeEach(async () => {
  if (testEnv) await testEnv.clearFirestore();
});

test("Unauthenticated user cannot read users, conversations, calls, statuses, or live_locations", async () => {
  const db = testEnv.unauthenticatedContext().firestore(DATABASE_ID);
  await assertFails(db.collection("users").get());
  await assertFails(db.collection("conversations").get());
  await assertFails(db.collection("calls").get());
  await assertFails(db.collection("statuses").get());
  await assertFails(db.collection("live_locations").get());
});

test("PII Isolation: Bob cannot read or write Alice's /users/{uid}/private/info or devices or prefs", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore(DATABASE_ID);
    await db.collection("users").doc(ALICE_UID).collection("private").doc("info").set({
      userId: ALICE_UID,
      email: "alice@example.com",
      phoneNumber: "+2250700000001",
      updatedAt: new Date(),
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("private").doc("info").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("devices").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("conversation_prefs").get());

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("info").get());
});

test("User cannot self-suspend or escalate role on create, and cannot modify isSuspended on update", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      isSuspended: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      role: "user",
      isSuspended: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isSuspended: true,
      updatedAt: new Date(),
    })
  );
});

test("Conversations and Messages: Participants only, Eve blocked, reactions allowed for participants", async () => {
  const convId = `conv_${ALICE_UID}_${BOB_UID}`;
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).set({
      participants: [ALICE_UID, BOB_UID],
      isGroup: false,
      lastMessage: "Salut",
      lastMessageSenderId: ALICE_UID,
      lastMessageType: "text",
      updatedAt: new Date(),
    })
  );

  await assertFails(eveDb.collection("conversations").doc(convId).get());
  await assertFails(
    eveDb.collection("conversations").doc(convId).collection("messages").doc("m1").set({
      conversationId: convId,
      senderId: EVE_UID,
      receiverId: ALICE_UID,
      content: "Intrusion",
      messageType: "text",
      status: "sent",
      timestamp: new Date(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("m1").set({
      conversationId: convId,
      senderId: ALICE_UID,
      receiverId: BOB_UID,
      content: "Bonjour Bob!",
      messageType: "text",
      status: "sent",
      timestamp: new Date(),
    })
  );

  // Bob can react and mark read
  await assertSucceeds(
    bobDb.collection("conversations").doc(convId).collection("messages").doc("m1").update({
      reactions: { heart_pulse: [BOB_UID] },
    })
  );
  await assertSucceeds(
    bobDb.collection("conversations").doc(convId).collection("messages").doc("m1").update({
      status: "read",
      readAt: new Date(),
    })
  );
});

test("Calls: Only participants can access, terminal status 'ended' locks further edits", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").set({
      callerId: ALICE_UID,
      callerName: "Alice",
      receiverId: BOB_UID,
      receiverName: "Bob",
      participantIds: [ALICE_UID, BOB_UID],
      callType: "video",
      status: "calling",
      createdAt: new Date(),
    })
  );

  await assertFails(eveDb.collection("calls").doc("call_1").get());
  await assertSucceeds(bobDb.collection("calls").where("receiverId", "==", BOB_UID).get());
  await assertSucceeds(aliceDb.collection("calls").where("participantIds", "array-contains", ALICE_UID).get());
  await assertFails(eveDb.collection("calls").where("participantIds", "array-contains", ALICE_UID).get());
  await assertSucceeds(bobDb.collection("calls").doc("call_1").update({ status: "accepted" }));
  await assertSucceeds(aliceDb.collection("calls").doc("call_1").update({ status: "ended", durationSeconds: 12 }));
  await assertFails(bobDb.collection("calls").doc("call_1").update({ status: "accepted" }));
});

test("Live Locations: Only owner and listed recipients can read encrypted location", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("live_locations").doc("loc_alice_1").set({
      ownerId: ALICE_UID,
      ownerName: "Alice",
      recipientUids: [BOB_UID],
      encryptedCoords: "base64cipher==",
      encryptionIv: "iv123",
      senderPublicKey: "pubKey",
      isEncrypted: true,
      active: true,
      expiresAtMs: Date.now() + 3600000,
      updatedAt: new Date(),
    })
  );

  await assertSucceeds(bobDb.collection("live_locations").doc("loc_alice_1").get());
  await assertFails(eveDb.collection("live_locations").doc("loc_alice_1").get());
});

test("Message 30s edit window: allowed <= 30s, blocked > 30s, deleteForAll allowed anytime", async () => {
  const convId = `conv_${ALICE_UID}_${BOB_UID}`;
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).set({
      participants: [ALICE_UID, BOB_UID],
      isGroup: false,
      lastMessage: "Salut",
      lastMessageSenderId: ALICE_UID,
      lastMessageType: "text",
      updatedAt: new Date(),
    })
  );

  // Recent message (within 30s) -> edit allowed
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("m_recent").set({
      conversationId: convId,
      senderId: ALICE_UID,
      receiverId: BOB_UID,
      content: "Original",
      messageType: "text",
      status: "sent",
      timestamp: new Date(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("m_recent").update({
      content: "Modifié < 30s",
      isEncrypted: false,
      encryptionIv: "",
      editedAt: new Date(),
    })
  );

  // Old message (35s ago) -> content edit MUST FAIL, deleteForAll MUST SUCCEED
  const oldTs = new Date(Date.now() - 35_000);
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("m_old").set({
      conversationId: convId,
      senderId: ALICE_UID,
      receiverId: BOB_UID,
      content: "Trop tard",
      messageType: "text",
      status: "sent",
      timestamp: oldTs,
    })
  );
  await assertFails(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("m_old").update({
      content: "Tentative tardive",
      isEncrypted: false,
      encryptionIv: "",
      editedAt: new Date(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("m_old").update({
      deletedForAll: true,
      content: "Ce message a été supprimé",
      isEncrypted: false,
      encryptionIv: "",
      editedAt: new Date(),
    })
  );
});

test("Conversation deletion: participant can delete messages and conversation, Eve blocked", async () => {
  const convId = `conv_${ALICE_UID}_${BOB_UID}`;
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).set({
      participants: [ALICE_UID, BOB_UID],
      isGroup: false,
      lastMessage: "Hello",
      lastMessageSenderId: ALICE_UID,
      lastMessageType: "text",
      updatedAt: new Date(),
    })
  );
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("m_del").set({
      conversationId: convId,
      senderId: ALICE_UID,
      receiverId: BOB_UID,
      content: "Msg",
      messageType: "text",
      status: "sent",
      timestamp: new Date(),
    })
  );

  await assertFails(eveDb.collection("conversations").doc(convId).collection("messages").doc("m_del").delete());
  await assertFails(eveDb.collection("conversations").doc(convId).delete());

  await assertSucceeds(bobDb.collection("conversations").doc(convId).collection("messages").doc("m_del").delete());
  await assertSucceeds(bobDb.collection("conversations").doc(convId).delete());
});

test("Free Offers: only published+free offers allowed, pending_payment rejected, owner-only delete", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);

  await assertFails(
    aliceDb.collection("offers").doc("off_paid_attempt").set({
      userId: ALICE_UID,
      authorName: "Alice",
      title: "Annonce payante",
      category: "Services",
      description: "Test",
      status: "pending_payment",
      paymentStatus: "pending",
      createdAt: new Date(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("offers").doc("off_free_1").set({
      userId: ALICE_UID,
      authorName: "Alice",
      title: "Cours de Kotlin gratuit",
      category: "Services",
      description: "Entraide développeurs",
      locationCity: "Abidjan",
      priceOrSalary: "Gratuit",
      status: "published",
      paymentStatus: "free",
      createdAt: new Date(),
    })
  );

  await assertFails(bobDb.collection("offers").doc("off_free_1").delete());
  await assertSucceeds(aliceDb.collection("offers").doc("off_free_1").delete());
});

test("Call WebRTC signals: only call participants can write/read SDP & ICE signals, Eve blocked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("calls").doc("call_webrtc_1").set({
      callerId: ALICE_UID,
      callerName: "Alice",
      receiverId: BOB_UID,
      receiverName: "Bob",
      participantIds: [ALICE_UID, BOB_UID],
      callType: "video",
      status: "calling",
      createdAt: new Date(),
    })
  );

  await assertSucceeds(
    aliceDb.collection("calls").doc("call_webrtc_1").collection("signals").doc("sig_offer_1").set({
      senderId: ALICE_UID,
      type: "offer",
      payload: JSON.stringify({ type: "offer", sdp: { sdp: "v=0..." } }),
      createdAt: new Date(),
    })
  );

  await assertSucceeds(
    bobDb.collection("calls").doc("call_webrtc_1").collection("signals").doc("sig_offer_1").get()
  );

  await assertFails(
    eveDb.collection("calls").doc("call_webrtc_1").collection("signals").doc("sig_offer_1").get()
  );
  await assertFails(
    eveDb.collection("calls").doc("call_webrtc_1").collection("signals").doc("sig_intrusion").set({
      senderId: EVE_UID,
      type: "offer",
      payload: "{}",
      createdAt: new Date(),
    })
  );
});

test("Call history deletion: participant can hide ended call via hiddenForUsers, Eve blocked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("calls").doc("call_hist_1").set({
      callerId: ALICE_UID,
      callerName: "Alice",
      receiverId: BOB_UID,
      receiverName: "Bob",
      participantIds: [ALICE_UID, BOB_UID],
      callType: "audio",
      status: "calling",
      hiddenForUsers: [],
      createdAt: new Date(),
    })
  );
  await assertSucceeds(aliceDb.collection("calls").doc("call_hist_1").update({ status: "ended", durationSeconds: 25 }));

  // Alice hides the call from her own history
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_hist_1").update({ hiddenForUsers: [ALICE_UID] })
  );
  // Bob cannot un-hide Alice (must preserve existing hiddenForUsers)
  await assertFails(
    bobDb.collection("calls").doc("call_hist_1").update({ hiddenForUsers: [BOB_UID] })
  );
  // Bob can append himself
  await assertSucceeds(
    bobDb.collection("calls").doc("call_hist_1").update({ hiddenForUsers: [ALICE_UID, BOB_UID] })
  );
  // Eve cannot touch it
  await assertFails(
    eveDb.collection("calls").doc("call_hist_1").update({ hiddenForUsers: [ALICE_UID, BOB_UID, EVE_UID] })
  );
});

test("Statuses: viewers can like, react with futuristic emojis, and comment; selected audience blocks Eve", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("statuses").doc("st_sel_1").set({
      userId: ALICE_UID,
      userName: "Alice",
      type: "text",
      text: "Statut futuriste privé!",
      audienceType: "selected",
      allowedUids: [BOB_UID],
      viewerIds: [],
      likedByUids: [],
      reactions: {},
      commentCount: 0,
      expiresAtMs: Date.now() + 86400000,
      createdAt: new Date(),
    })
  );

  // Bob is allowed: can like, react, and post emoji comment
  await assertSucceeds(
    bobDb.collection("statuses").doc("st_sel_1").update({
      likedByUids: [BOB_UID],
      reactions: { cyber_bot: [BOB_UID] },
    })
  );
  await assertSucceeds(
    bobDb.collection("statuses").doc("st_sel_1").collection("comments").doc("cmt_1").set({
      statusId: "st_sel_1",
      authorId: BOB_UID,
      authorName: "Bob",
      text: "Incroyable ce statut !",
      reactionKey: "rocket_turbo",
      createdAt: new Date(),
    })
  );
  // Emoji-only comment also allowed
  await assertSucceeds(
    bobDb.collection("statuses").doc("st_sel_1").collection("comments").doc("cmt_2").set({
      statusId: "st_sel_1",
      authorId: BOB_UID,
      authorName: "Bob",
      text: "",
      reactionKey: "clown_mode",
      createdAt: new Date(),
    })
  );

  // Eve is NOT in allowedUids -> denied read, like, and comment
  await assertFails(eveDb.collection("statuses").doc("st_sel_1").get());
  await assertFails(eveDb.collection("statuses").doc("st_sel_1").update({ likedByUids: [EVE_UID] }));
  await assertFails(
    eveDb.collection("statuses").doc("st_sel_1").collection("comments").doc("cmt_eve").set({
      statusId: "st_sel_1",
      authorId: EVE_UID,
      authorName: "Eve",
      text: "Intrusion",
      createdAt: new Date(),
    })
  );
});

test("Calls: caller/receiver avatars, on_hold/heldByUid, and hold/resume signals work for participants only", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DATABASE_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DATABASE_ID);
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore(DATABASE_ID);

  await assertSucceeds(
    aliceDb.collection("calls").doc("call_hold_1").set({
      callerId: ALICE_UID,
      callerName: "Alice",
      callerAvatar: "https://example.com/a.jpg",
      callerUsername: "alice",
      receiverId: BOB_UID,
      receiverName: "Bob",
      receiverAvatar: "https://example.com/b.jpg",
      receiverUsername: "bob",
      participantIds: [ALICE_UID, BOB_UID],
      callType: "audio",
      status: "calling",
      heldByUid: "",
      createdAt: new Date(),
    })
  );

  await assertSucceeds(bobDb.collection("calls").doc("call_hold_1").update({ status: "accepted" }));
  await assertSucceeds(aliceDb.collection("calls").doc("call_hold_1").update({ status: "on_hold", heldByUid: ALICE_UID }));
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_hold_1").collection("signals").doc("sig_hold").set({
      senderId: ALICE_UID,
      type: "hold",
      payload: JSON.stringify({ held: true }),
      createdAt: new Date(),
    })
  );
  await assertSucceeds(aliceDb.collection("calls").doc("call_hold_1").update({ status: "accepted", heldByUid: "" }));
  await assertFails(eveDb.collection("calls").doc("call_hold_1").update({ status: "on_hold", heldByUid: EVE_UID }));
});
